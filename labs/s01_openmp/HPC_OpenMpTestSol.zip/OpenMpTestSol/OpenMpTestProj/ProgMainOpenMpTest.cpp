#include <iostream>
#include <vector>
#include <omp.h>
using namespace std;

#include <time.h>

clock_t start, stop;

int main(int argc, char** argv)
{
	int nr_elements = 10000000, i = 0, nrThreads = 2;
	vector<int> v1(nr_elements, 1), v2(nr_elements, 2);
	vector<int> result(nr_elements, 0);

	//nrThreads = atoi(argv[1]);

	start = clock();
	for(i = 0; i < nr_elements; i++)
	{
		result[i] = v1[i] + v2[i];
	}
	stop = clock();
	
	cout<<"It took "<<(stop-start)<<" clicks ("<<(((float)(stop-start))/CLOCKS_PER_SEC)<<" seconds)."<<endl;

	nrThreads = 32;
	//a worksharing for construct to add vectors:
	omp_set_num_threads(nrThreads);

	start = clock();
	#pragma omp parallel for
	for(i = 0; i < nr_elements; i++)
	{
		result[i] = v1[i] + v2[i];
	}
	stop = clock();
	
	cout<<"It took "<<(stop-start)<<" clicks ("<<(((float)(stop-start))/CLOCKS_PER_SEC)<<" seconds)."<<endl;

	for(int j = 0; j < 20; j++)
		cout<<" , "<<result[j];

	return 0;
}

/*
#include <stdlib.h>
#include <stdio.h>
#include "omp.h"

int main()
{
	int nthreads, tid;
	omp_set_num_threads(3);
	int i;

	#pragma omp parallel private(tid) shared(i)
	{
		tid = omp_get_thread_num();
		printf("Hello world from (%d)\n", tid);

		#pragma omp for
		for(i = 0; i <= 4; i++)
		{
			printf(" Iteration %d by (%d) \n", i, tid);
		}
	} //all threads join master thread and terminate

	return 0;
}
*/

/*
#include <stdlib.h>
#include <stdio.h>
#include "omp.h"

int main()
{
	#pragma omp parallel
	{
		int ID=omp_get_thread_num();
		printf("Hello (%d)\n", ID);
		printf(" world (%d) \n", ID);
	}

	return 0;
}
*/