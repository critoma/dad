package ejbmessagedrivenbean;

import jakarta.ejb.ActivationConfigProperty;
import jakarta.ejb.MessageDriven;
import jakarta.jms.JMSException;
import jakarta.jms.Message;
import jakarta.jms.MessageListener;
import jakarta.jms.TextMessage;

/**
 * Message-Driven Bean implementation class for: MessageBean
 */
/*
@MessageDriven(
		activationConfig = {
		   @ActivationConfigProperty(propertyName = "destination", propertyValue = "jms/topic/test1"),
		   @ActivationConfigProperty(propertyName = "destinationType", propertyValue = "jakarta.jms.Topic") }, 
		mappedName = "jms/topic/test1", messageListenerInterface = MessageListener.class)
*/

@MessageDriven(
		activationConfig = { 
				@ActivationConfigProperty(propertyName = "destination", propertyValue = "jms/topic/test1"), 
				@ActivationConfigProperty(propertyName = "destinationType", propertyValue = "jakarta.jms.Topic")
		})
public class MessageBean implements MessageListener {

	/**
	 * Default constructor.
	 */
	public MessageBean() {
		System.out.println("Constructor EJB3 MDB");
	}

	/**
	 * @see MessageListener#onMessage(Message)
	 */
	public void onMessage(Message inMessage) {
		// System.out.println("MDB::onMessage()");
		TextMessage msg = null;
		try {
			if (inMessage instanceof TextMessage) {
				msg = (TextMessage) inMessage;
				System.out.println("MDB EJB3 - asynch received = " + msg.getText());
			} else {
				System.out.println("Message of wrong type");
			}
		} catch (JMSException jmse) {
			jmse.printStackTrace();
			throw new IllegalStateException(jmse);
		} catch (Throwable t) {
			t.printStackTrace();
		}
	}

}
