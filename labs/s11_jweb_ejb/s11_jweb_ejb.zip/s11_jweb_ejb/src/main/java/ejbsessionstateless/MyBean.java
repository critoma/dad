package ejbsessionstateless;

import jakarta.ejb.LocalBean;
import jakarta.ejb.Stateless;

/**
 * Session Bean implementation class MyBean
 */
@Stateless
@LocalBean
public class MyBean {

    public MyBean() {
    }

    public String doSomething() {
    	return "Hello from EJB";
    }
}
