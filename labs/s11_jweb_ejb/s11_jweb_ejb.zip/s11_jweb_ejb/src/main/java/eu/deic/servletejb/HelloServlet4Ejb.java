package eu.deic.servletejb;

import java.io.IOException;
import java.io.PrintWriter;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import jakarta.ejb.EJB;

import ejbsessionstateless.MyBean;
import ejbsessionstateless.Publisher;

@WebServlet("/HelloServlet4Ejb")
public class HelloServlet4Ejb extends HttpServlet {
	private static final long serialVersionUID = 1L;
    
	@EJB
	private MyBean ejbHelloBean;
	
	@EJB
	private Publisher pub;
	
    public HelloServlet4Ejb() {
        super();
    }

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		out.println("<html><body>");
		
		out.append("Served at: ").append(request.getContextPath()).append("\r\n");
		out.println("<h2>From here we will call EJB Session Stateless</h2>");
		out.println("<h3>EJB Response = " + ejbHelloBean.doSomething() + "</h3>");
		out.println("<h3>EJB Session Stateless publisher send msg = "+pub.publishNews()+"</h3>");
		
		out.println("</body></html>");
	}

}