0. Path
SET PATH=%PATH%;c:\Software\cygwin\bin

1. REM in cygwin window:
/bin/cygserver-config

2. REM in windows command prompt:
SET CYGWIN=server
net start cygserver
net stop cygserver