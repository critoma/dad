#include <stdio.h>
#include <sys/sem.h>
#include <sys/msg.h>

#include <sys/types.h>
#include <sys/ipc.h>

struct my_msgbuf {
	long mtype;
	char mtext[44];
};

int main(int argc, char** argv)
{
	struct sembuf sb;// = {0, -1, 0};  /* set to allocate resource */
	struct my_msgbuf buf;
	int msqid, semid;
	key_t keyq, keys;

	FILE* f=fopen("p1.txt","rt");

	if ((keyq = ftok("readme.txt", 'Q')) == -1) {
            perror("ftok");
            exit(1);
	}
      
	if ((msqid = msgget(keyq, 0644)) == -1) { /* connect to the queue */
            perror("msgget");
            exit(1);
	}

	if ((keys = ftok("readme.txt", 'S')) == -1) {
            perror("ftok");
            exit(1);
	}

	/* grab the semaphore set created by seminit.c: */
	if ((semid = semget(keys, 2, 0)) == -1) {
            perror("semget");
            exit(1);
	}
       int i = 1; buf.mtype = i;
       while(fgets(buf.mtext,4096,f), !feof(f)) {
          if (msgsnd(msqid, (struct msgbuf *)&buf, sizeof(buf), 0) == -1) {
                perror("msgsnd");
	    } else {
		printf("%d %s",i,buf.mtext);
		if(i % 15 == 0) {
			i = 1; buf.mtype = i;
			//sb = {0, -1, 0}; 
			sb.sem_num = 0; sb.sem_op = -1; sb.sem_flg = 0;
			printf("\n Finnished the bulk of 15 msgs \n");
			if (semop(semid, &(sb[0]), 1) == -1) {
		            perror("semop");
            		exit(1);
        		}			
		}else{
		i++; buf.mtype = i;}
	    }
       }

	return 0;
}



