#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>


int main(int argc, char** argv)
{
      int msqid;
      key_t keyq;

	if ((keyq = ftok("readme.txt", 'Q')) == -1) {
            perror("ftok");
            exit(1);
      }
	if ((msqid = msgget(keyq, 0666 | IPC_CREAT)) == -1) {
            perror("msgget");
            exit(1);
      }
      if (msgctl(msqid, IPC_RMID, NULL) == -1) {
           perror("msgctl");
           exit(1);
      }

	return 0;
}

