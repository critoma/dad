Fisier care nu trebuie sters
deorece se obtine numarul unic de
set semafoare si de coada mesaje sistem.

Se ruleaza:

1. ./qinit.exe
2. ./seminit.exe
3.

Consumatorii si producatorii

4. ./semrm.exe
5. ./qrm.exe