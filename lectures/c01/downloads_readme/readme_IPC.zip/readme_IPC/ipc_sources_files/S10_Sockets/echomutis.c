#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <malloc.h>
#include <pthread.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/un.h>

#define SOCK_PATH "echo_socket"
#define MAX_CLIENTS 3 

//pthread_mutex_t mutex1 = PTHREAD_MUTEX_INITIALIZER;

//int noCurrClients = 0;

void *resolve_client(void* arg) {
	int* s2 = (int*)arg;
	char str[100];
	int done, n;
	
	printf("Connected.\n");
            done = 0;
            do {
                n = recv(*s2, str, 100, 0);
                if (n <= 0) {
                    if (n < 0) perror("recv");
                    done = 1;
                }

                if (!done) 
                    if (send(*s2, str, n, 0) < 0) {
                        perror("send");
                        done = 1;
                    }
            } while (!done);

            close(*s2);
}

int main(void)
{
        int s, s2, t, len;
	  int* sclient = NULL;
        struct sockaddr_un local, remote;
        
	  //pthread_t threadv[MAX_CLIENTS];
	  //int retth[MAX_CLIENTS];
	   pthread_t th;
	   int retth;

        if ((s = socket(AF_UNIX, SOCK_STREAM, 0)) == -1) {
            perror("socket");
            exit(1);
        }

        local.sun_family = AF_UNIX;
        strcpy(local.sun_path, SOCK_PATH);
        unlink(local.sun_path);
        len = strlen(local.sun_path) + sizeof(local.sun_family);
        if (bind(s, (struct sockaddr *)&local, len) == -1) {
            perror("bind");
            exit(1);
        }

        if (listen(s, MAX_CLIENTS) == -1) {
            perror("listen");
            exit(1);
        }
	  
        for(;;) {
            
            printf("Waiting for a connection...\n");
            t = sizeof(remote);
		sclient = (int*)malloc(1*sizeof(int));
            //if ((s2 = accept(s, (struct sockaddr *)&remote, &t)) == -1) {
		if ((*sclient = accept(s, (struct sockaddr *)&remote, &t)) == -1) {
                perror("accept");
                exit(1);
            }
		//resolve_client(sclient);
		retth = pthread_create( &th, NULL, resolve_client, (void*) sclient);
            
        }

        return 0;
}
