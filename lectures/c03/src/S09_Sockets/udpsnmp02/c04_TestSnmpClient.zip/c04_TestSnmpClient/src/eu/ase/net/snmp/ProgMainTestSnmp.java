package eu.ase.net.snmp;

import java.net.DatagramSocket;
import java.net.DatagramPacket;
import java.net.InetAddress;

public class ProgMainTestSnmp {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		//put in running project the args[0] as IP of the machine with snmpd properly configured
		//please see in Ubuntu 12: ifconfig in terminal => 192.168.229.137
		//please start as root in Ubuntu the Wireshark utility program
		//see also the firewall in Windows and in Linux Ubuntu (sudo ufw status  # - should be inactive the un-complicated fire-wall and in windows the port 161 should be opened)
		DatagramSocket socket = null;
		try {
			socket = new DatagramSocket();
			byte[] kk = new byte[39];
			
	            kk[0] = 0x30;
	            kk[1]=0x25; //length of the sequence excluding the first 2 bytes
				kk[2]=0x02; //information that follows is an Integer Number
				kk[3]=0x01;	// length of data
				kk[4]=0x00; // zero is the actual value of data => version number 0
				kk[5]=0x04;	// follows an octet string
				kk[6]=0x06;	// with 6 bytes length
				kk[7]=(byte)'p';	
				kk[8]=(byte)'u';
				kk[9]=(byte)'b';
				kk[10]=(byte)'l';
				kk[11]=(byte)'i';
				kk[12]=(byte)'c';
				kk[13]=(byte)0xA1; //1010 0001 => When the first three bytes are 101,it means that the data to follow is Context Specific 
							 //i.e. you have to look up the documentation and look for it as it's context changes with every protocol. 
							 //The last four bits hold the number, which is 1 in this case. So it's Context Specific 1. This stands for Get Next Request in the documentation.
				kk[14]=0x18; //the length is 24 bytes
				kk[15]=2;	 //The next three bytes hold the Request ID, which we've set to one. Kk[15] is 0x02 which means that the data is an Integer. The next byte is the length and the data itself is 0x01.
				kk[16]=1;
				kk[17]=1;
				kk[18]=2;	 //The next three bytes contain the error status of the present connection. Since we've just begun talking, it is set to zero.
				kk[19]=1;
				kk[20]=0;
				kk[21]=2;	 //Right after that we have another three bytes which hold the error index. It too is set to zero.
				kk[22]=1;
				kk[23]=0;
				kk[24]=0x30; //Now, at kk[24] we have another structure (or sequence if you prefer) starting up. The byte after that is the length of the data that follows.
							 //Immediatly after the first structure, we have another one. 
							 //This format is maintained so that if you want to ask two questions at the same time, you can. Simply add another 0x30 after the end of this one and more data.
							 //After the length byte we have the byte 0x06 which stands for the Object data type. The byte after that is the length. 
				kk[25]=0x0D; //length
				kk[26]=0x30; // Sequence Structure
				kk[27]=0x0B; // length 11 bytes
				kk[28]=0x06; // Object Data Type - OID
				kk[29]=0x07; // the length of Object data type is 7 bytes
							 //Right at the top is the root, then comes the ISO (1), then org under ISO (1.3), then the Department of Defense or the dod under org (1.3.6). Right after that we have the Internet (1.3.6.1) under the Internet we have mgmt (1.3.6.1.2) and under mgmt we have MIB or the Management Information Database (1.3.6.1.2.1). 
							 //Since we're using SNMP which is used to manage a network system, we have system (1.3.6.1.2.1). 
							 //So the hierarchy path we're on is 1.3.6.1.2.1.1
				kk[30]=0x2B; //So the bytes from kk[30] to kk[36] hold the hierarchy of our query. What you may find a little confusing is that the first byte, kk[30], is 0x2b instead of 1.3 as it should be. Actually, this is the ISO being little clever (for once!). To save transmitting an extra byte, they decided to multiply the first 1 in 1.3.6.1.2.1.3 with 40 and add it to the second number i.e. 3. So we get 1*40+3=43 or 0x2b!! Confusing, but neat.
				kk[31]=0x06;
				kk[32]=0x01;
				kk[33]=0x02;
				kk[34]=0x01;
				kk[35]=0x01;
				kk[36]=0x03; //IMPORTANT => Value 3, in kk[36], is Sysuptime under System.
				kk[37]=0x05; //The last two bytes in the packet are 0x05 and 0x00 which collectively stand for a NULL value. This is because we can't have an answer in a query!
				kk[38]=0x00;
	     
			
			InetAddress address = InetAddress.getByName(args[0]);
			DatagramPacket packet = new DatagramPacket(kk, kk.length, address, 161);
			socket.send(packet);
			
			byte[] bufResp = new byte[256];
			packet = new DatagramPacket(bufResp, bufResp.length);
			socket.receive(packet);
			
			byte[] bufResp2 = packet.getData();
			String recvStr = new String(bufResp2);
			System.out.println("Client SNMP - receive = "+recvStr);
			System.out.println("Client SNMP - receive HEX = "+bytesToHex(bufResp2));
			
			if(bufResp == bufResp2)
				System.out.println("TRUE - sunt egale ca adresa");
			
			socket.close();
		} catch(Exception e) {
			e.printStackTrace();
		}

	}
	
	public static String bytesToHex(byte[] bytes) {
	    final char[] hexArray = {'0','1','2','3','4','5','6','7','8','9','A','B','C','D','E','F'};
	    char[] hexChars = new char[bytes.length * 2];
	    int v;
	    for ( int j = 0; j < bytes.length; j++ ) {
	        v = bytes[j] & 0xFF;
	        hexChars[j * 2] = hexArray[v >>> 4];
	        hexChars[j * 2 + 1] = hexArray[v & 0x0F];
	    }
	    return new String(hexChars);
	}


}
