package eu.deic.servlets;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

// cd /Users/critoma/eclipse-workspace-2023/c04_restapi_servlets/src/main/java/eu/deic/servlets
// curl https://raw.githubusercontent.com/critoma/dad/master/lectures/c04/src/S10_Servlets/S09/WEB-INF/classes/eu/ase/servlets/HelloWWW.java >> HelloWWW.java
// XOR
// wget https://raw.githubusercontent.com/critoma/dad/master/lectures/c04/src/S10_Servlets/S09/WEB-INF/classes/eu/ase/servlets/HelloWWW.java
// Export WAR in /Applications/Apache/apache-tomcat-10.1.5/webapps

@WebServlet("/HelloWWW")
public class HelloWWW extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private int accCount = 0;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public HelloWWW() {
        super();
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//response.getWriter().append("Served at: ").append(request.getContextPath());
		accCount++;
	    response.setContentType("text/html");
	    PrintWriter out = response.getWriter();
	    out.println("<!DOCTYPE HTML PUBLIC \"-//W3C//DTD HTML 4.0 " +
	                                        "Transitional//EN\">\n" +
	                "<HTML>\n" +
	                "<HEAD><TITLE>Hello WWW</TITLE></HEAD>\n" +
	                "<BODY>\n" +
	                "<H1>Hello WWW</H1>\n<P>" + accCount + 
	                "</P></BODY></HTML>");
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
