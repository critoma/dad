export NODE_HOME=/opt/software/node-v16.14.0-darwin-x64 
export PATH=.:$NODE_HOME/bin:$PATH

node --version
npm --version

#############################################################
cd webFrontAndWs
npm ls

npm install websocket

node ./websocket/websocket.js &
node serverHttp.js

# wireshark:
# http://127.0.0.1:3000/websocket/websocketHTML5.html
# http://127.0.0.1:3000/jsframeworks/angular/helloAngular1.html
# http://127.0.0.1:3000/jsframeworks/react/react01.html
# http://127.0.0.1:3000/jsframeworks/vuejs/vue03.html


#################################################
cd ../restExpressWeb
# node.js + Express for REST API with Files instead Database
# npm install express
node restServer.js

# http://127.0.0.1:8081/guiHTML5.html

# in Chromium, PostMAN plug-in do:
# curl http://127.0.0.1:8081/listUsers
# GET: http://127.0.0.1:8081/listUsers

# curl -X POST http://127.0.0.1:8081/addUser 
# POST: http://127.0.0.1:8081/addUser
# GET: http://127.0.0.1:8081/2
# DELETE: http://127.0.0.1:8081/deleteUser


######################################################
cd ../session
npm install express express-session cookie-parser
node serverHttpSession.js 
Node sessionH.js

http://127.0.0.1:4000
