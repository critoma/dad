var http=require('http');
var options = { 
    hostname: '127.0.0.1',
    port: '4000',
    path: '/',
    method: 'GET',
    headers: {'Cookie': 'connect.sid=s%3ASxBqvbJgsgwNhkD-vYnUxC-8N6WPe-8j.nE4JcZwBCCpF1RmtPS%2BZAth2nGL%2FLA5pmJx0kk2WNGY', },
};
var results = ''; 
var req = http.request(options, function(res) {
    res.on('data', function (chunk) {
        results = results + chunk;
        console.log(results);
    }); 
    res.on('end', function () {
        console.log('end response result');
    }); 
});

req.on('error', function(e) {
        console.log('error: ' + e);
});

req.end();