package eu.deic.rest;

import io.javalin.Javalin;

// A simple web framework for Java and Kotlin : https://javalin.io/
// https://github.com/javalin/javalin | https://javalin.io/documentation#getting-started
// https://javalin.io/download
// Sept 2023: https://repo1.maven.org/maven2/io/javalin/javalin/5.6.3/ | https://repo1.maven.org/maven2/org/slf4j/slf4j-simple/2.0.7/ | ...


public class TestRESTAPIWithJavalin {

	public static void main(String[] args) {
		// curl -X GET http://127.0.0.1:7000/api/javalin/greeting
		Javalin app = Javalin.create().start(7000);
        app.get("/api/javalin/greeting", 
        		ctx -> ctx.result("{'msg':'Hello World from Javalin for Java and Kotlin!'}\n")
        );
        
        // curl -X GET http://127.0.0.1:7000/api/javalin/hello/DJVasile
        app.get("/api/javalin/hello/{name}", ctx -> { 
        	// the {} syntax does not allow slashes ('/') as part of the parameter
            ctx.result("Hello: " + ctx.pathParam("name"));
        });
        // curl -X GET http://127.0.0.1:7000/api/javalin/hello/DJVasile/and/DJGuetta
        app.get("/api/javalin/hello/<name>", ctx -> { 
        	// the <> syntax allows slashes ('/') as part of the parameter
            ctx.result("Hello: " + ctx.pathParam("name"));
        });
        
        // curl -d '{"key1":"value1", "key2":"value2"}' -H "Content-Type: application/json" -X POST http://127.0.0.1:7000/api/javalin/inputJSONviaPOST	
        app.post("/api/javalin/inputJSONviaPOST", ctx -> {
            // some code
            ctx.status(201);
            ctx.contentType("application/json");
            String bodyStr = ctx.body();
            System.out.printf(bodyStr);
        });
        
	}

}

// #####################################################################

/*
//OLD - OBSOLETE ....

//https://happycoding.io/tutorials/java-server/rest-api
//https://www.educative.io/answers/how-to-make-a-rest-api-in-java
//http://sparkjava.com/download
//https://repo1.maven.org/maven2/com/sparkjava/spark-core/2.9.4/

//https://repo1.maven.org/maven2/org/slf4j/slf4j-simple/2.0.5/
//https://repo1.maven.org/maven2/org/slf4j/slf4j-api/2.0.5/

//https://www.baeldung.com/spark-framework-rest-api
//https://github.com/perwendel/spark

//import static spark.Spark.*;

public class TestAPIWithSpark {

	
	public static void main(String[] args) {
		
		port(4567);
		// curl -X GET http://127.0.0.1:4567/api/spark/greeting
		get("/api/spark/greeting", (req, res) -> "Hello World! from our Spark REST API");
		// curl -X GET http://127.0.0.1:4567/api/spark/hello/DJVasile
		get("/api/spark/hello/:name", (req, res) -> {
			return "Hello, " + req.params(":name");
		});

		// curl -d '{"key1":"value1", "key2":"value2"}' -H "Content-Type: application/json" -X POST http://127.0.0.1:4567/api/spark/testPOST
		spark.Spark.post("/api/spark/TestPOST", (req, resp) -> {
			resp.type("application/json");
			return req.body();
		});
		

	}

}
*/

