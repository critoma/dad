package eu.deic.rest;

import io.javalin.Javalin;
import io.javalin.http.staticfiles.Location;
import io.javalin.util.FileUtil;

//https://javalin.io/documentation
//https://github.com/javalin/javalin-samples

public class TestRESTAPIWithJavalinUploadFile {

	public static void main(String[] args) {
		Javalin app = Javalin.create(javalinConfig -> {
            //javalinConfig.staticFiles.add("/staticHTML");//add() accepts path to directory with static files 
			javalinConfig.staticFiles.add("./staticHTML", Location.EXTERNAL);
		}).start(7000);
		
		// In WebBrowser => HTTP GET: http://127.0.0.1:7000/fileExample 
		// -> will call from HTML form /upload HTTP POST route
		app.get("/fileExample", ctx -> ctx.redirect("/uploadFile.html"));		
		app.post("/upload", ctx -> {
		    ctx.uploadedFiles("files").forEach(uploadedFile ->
		        FileUtil.streamToFile(uploadedFile.content(), "upload/" + uploadedFile.filename()));
		    ctx.html("Your file has been uploaded!");
		});
	}

}
