package eu.deic.rest;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.stream.Collectors;

import io.javalin.Javalin;
import io.javalin.http.Handler;
import io.javalin.http.staticfiles.Location;

// https://javalin.io/documentation
// https://www.baeldung.com/javalin-rest-microservices
// https://github.com/javalin/javalin-samples

// https://gist.github.com/leefsmp/b4c089734852c793cf85

public class TestRESTMicroservicesWithJavalin {

	public static void main(String[] args) {
		// Javalin app = Javalin.create().start(7000);
		Javalin app = Javalin.create(javalinConfig -> {
            //javalinConfig.staticFiles.add("/staticHTML");//add() accepts path to directory with static files 
			javalinConfig.staticFiles.add("./staticHTML", Location.EXTERNAL);
		}).start(7000);
		
		// REST API - Micro-services
		// curl -X GET http://127.0.0.1:7000/hello
		app.get("/hello", ctx -> ctx.html("Hello, Javalin!"));
		
		// curl -X GET http://127.0.0.1:7000/listUsersNames
		app.get("/listUsersNames", UserController.fetchAllUsernames);
		// curl -X GET http://127.0.0.1:7000/users/1
		app.get("/users/<id>", UserController.fetchById);
		
		// curl -d '{"id":"5", "name":"DJGuetta"}' -H "Content-Type: application/json" -X POST http://127.0.0.1:7000/users/add
		// curl -X GET http://127.0.0.1:7000/users
		// curl -X GET http://127.0.0.1:7000/users/5
		app.post("/users/add", ctx -> {
			User userFromRESTReq = ctx.bodyAsClass(User.class);
			String bodyStr = ctx.body();
			System.out.printf("bodyStr = %s, id = %d, name = %s", bodyStr, userFromRESTReq.id, userFromRESTReq.name);
			((ArrayList<User>)UserDao.instance().getUsers()).add(userFromRESTReq);
		});
		
		
		// ################################
		// REST API handling from web front-end:
		// In WebBrowser/Mobile App/browser: 
		
		// http://127.0.0.1:7000/plainVanillaHTMLFrontEndJS 
		// -> will call from HTML form /upload HTTP POST route
		app.get("/plainVanillaHTMLFrontEndJS", ctx -> ctx.redirect("/guiHTML5.html"));
		
		// http://127.0.0.1:7000/angularHTMLFrontEnd 
		app.get("/angularHTMLFrontEnd", ctx -> ctx.redirect("/jsframeworks/angular/helloAngular1.html"));
		
		// http://127.0.0.1:7000/reactHTMLFrontEnd
		app.get("/reactHTMLFrontEnd", ctx -> ctx.redirect("/jsframeworks/react/react01.html"));
		
		// http://127.0.0.1:7000/vuejsHTMLFrontEnd01
		app.get("/vuejsHTMLFrontEnd01", ctx -> ctx.redirect("/jsframeworks/vuejs/vue01.html"));
		
		// http://127.0.0.1:7000/vuejsHTMLFrontEnd03
		app.get("/vuejsHTMLFrontEnd03", ctx -> ctx.redirect("/jsframeworks/vuejs/vue03.html"));
				
	} // end main

} // end class

class User implements Serializable {
    private static final long serialVersionUID = 1L;
	public int id;
    public String name;

    // constructors
    public User() {
    }
    
    public User(int id, String name) {
    	this.id = id;
    	this.name = name;
    }
    
    @Override
    public String toString() {
    	return "{'id':'"+this.id+"', 'name':'"+this.name+"'}";
    }
    
} // end class User

class UserDao {

//    private List<User> users = Arrays.asList(	
//      new User(0, "Steve Rogers"),
//      new User(1, "Tony Stark"),
//      new User(2, "Carol Danvers")
//    );
	
	private List<User> users;
    
    public List<User> getUsers() {
    	return users;
    }

    private static UserDao userDao = null;

    private UserDao() {
    	users = new ArrayList<>();
    	users.add(0, new User(0, "Steve Rogers"));
    	users.add(1, new User(1, "Tony Stark"));
    	users.add(2, new User(2, "Carol Danvers"));
    }

    static UserDao instance() {
        if (userDao == null) {
            userDao = new UserDao();
        }
        return userDao;
    }

    Optional<User> getUserById(int id) {
        return users.stream()
          .filter(u -> u.id == id)
          .findAny();
    }

    Iterable<String> getAllUsernames() {
        return users.stream()
          .map(user -> user.name)
          .collect(Collectors.toList());
    }
} // end class UserDao ... DAO = Data Access Objects

class UserController {
    public static Handler fetchAllUsernames = ctx -> {
        UserDao dao = UserDao.instance();
        Iterable<String> allUsers = dao.getAllUsernames();
        ctx.json(allUsers);
    };

    public static Handler fetchById = ctx -> {
        int id = Integer.parseInt(Objects.requireNonNull(ctx.pathParam("id")));
        UserDao dao = UserDao.instance();
        Optional<User> user = dao.getUserById(id);
        if (user.isPresent()) {
        	ctx.json(user);
            //ctx.json(user.get());
        } else {
            ctx.html("Not Found");
        }
    };
}
