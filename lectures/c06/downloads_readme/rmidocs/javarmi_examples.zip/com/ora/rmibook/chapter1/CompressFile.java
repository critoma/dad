package com.ora.rmibook.chapter1;


public class CompressFile {
    public static void main(String[] arguments) {
        (new CompressFileFrame()).show();
    }
}
