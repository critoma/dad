package com.ora.rmibook.chapter1;


import com.ora.rmibook.gui.*;

import java.io.*;
import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.util.zip.*;


public class CompressFileFrame extends ExitingFrame {
    private FileTextField _startingFileTextField;
    private FileTextField _destinationFileTextField;
    protected void buildGUI() {
        _startingFileTextField = new FileTextField("File to Compress");
        _destinationFileTextField = new FileTextField(new CompressFileAction(), "Destination File");
        JPanel newContentPane = new JPanel(new GridLayout(2, 1));

        newContentPane.add(_startingFileTextField);
        newContentPane.add(_destinationFileTextField);
        setContentPane(newContentPane);
        setSize(250, 300);
    }

    private class CompressFileAction extends AbstractAction {
        public CompressFileAction() {
            putValue(Action.NAME, "Compress");
            putValue(Action.SHORT_DESCRIPTION, "Copy and compress the file.");
        }

        public void actionPerformed(ActionEvent event) {
            InputStream source = _startingFileTextField.getFileInputStream();
            OutputStream destination = _destinationFileTextField.getFileOutputStream();

            if ((null != source) && (null != destination)) {
                try {
                    BufferedInputStream bufferedSource = new BufferedInputStream(source);
                    BufferedOutputStream bufferedDestination = new BufferedOutputStream(destination);
                    GZIPOutputStream zippedDestination = new GZIPOutputStream(bufferedDestination);

                    copy(bufferedSource, zippedDestination);
                    bufferedSource.close();
                    zippedDestination.close();
                } catch (IOException e) {
                }
            }
        }

        private int copy(InputStream source, OutputStream destination)
            throws IOException {
            int nextByte;
            int numberOfBytesCopied = 0;

            while (-1 != (nextByte = source.read())) {
                destination.write(nextByte);
                numberOfBytesCopied++;
            }
            destination.flush();
            return numberOfBytesCopied;
        }
    }
}
