package com.ora.rmibook.chapter1;


import java.io.*;


public class LoggingInputStream extends FilterInputStream {
    private Recorder _recorder;
    public LoggingInputStream(InputStream inputStream, String fileName) {
        this (inputStream, new Recorder(fileName));
    }

    public LoggingInputStream(InputStream inputStream, Recorder recorder) {
        super (inputStream);
        _recorder = recorder;
    }

    public int read()
        throws IOException {
        _recorder.incrementCounter(1);
        return super.read();
    }

    public int read(byte[] b)
        throws IOException {
        int numberOfBytes = super.read(b);

        _recorder.incrementCounter(numberOfBytes);
        return numberOfBytes;
    }

    public int read(byte[] b, int off, int len)
        throws IOException {
        int numberOfBytes = super.read(b, off, len);

        _recorder.incrementCounter(numberOfBytes);
        return numberOfBytes;
    }
}
