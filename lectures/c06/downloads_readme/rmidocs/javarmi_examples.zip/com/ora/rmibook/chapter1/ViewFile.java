package com.ora.rmibook.chapter1;


public class ViewFile {
    public static void main(String[] arguments) {
        (new ViewFileFrame()).show();
    }
}
