package com.ora.rmibook.chapter1;


import com.ora.rmibook.gui.*;

import java.io.*;
import javax.swing.*;
import java.awt.event.*;
import java.awt.*;


public class ViewFileFrame extends ExitingFrame {
    private FileTextField _fileTextField;
    private JTextArea _fileViewingArea;
    protected void buildGUI() {
        _fileTextField = new FileTextField(new ViewFileAction());
        _fileViewingArea = new JTextArea();
        JScrollPane scrollPaneAroundTextArea = new JScrollPane(_fileViewingArea);

        scrollPaneAroundTextArea.setBorder(BorderFactory.createLoweredBevelBorder());
        JPanel newContentPane = new JPanel(new BorderLayout());

        newContentPane.add(_fileTextField, BorderLayout.NORTH);
        newContentPane.add(scrollPaneAroundTextArea, BorderLayout.CENTER);
        setContentPane(newContentPane);
        setSize(250, 300);
    }

    private class ViewFileAction extends AbstractAction {
        public ViewFileAction() {
            putValue(Action.NAME, "View");
            putValue(Action.SHORT_DESCRIPTION, "View file contents in main text area.");
        }

        public void actionPerformed(ActionEvent event) {
            FileInputStream fileInputStream = _fileTextField.getFileInputStream();

            if (null == fileInputStream) {
                _fileViewingArea.setText("Invalid file name");
            } else {
                try {
                    copyStreamToViewingArea(fileInputStream);
                    fileInputStream.close();
                } catch (java.io.IOException ioException) {
                    _fileViewingArea.setText("\n Error occured while reading file");
                }
            }
        }

        private void copyStreamToViewingArea(InputStream fileInputStream)
            throws IOException {
            BufferedInputStream bufferedStream = new BufferedInputStream(fileInputStream);
            int nextByte;

            _fileViewingArea.setText("");
            StringBuffer localBuffer = new StringBuffer();

            while (-1 != (nextByte = bufferedStream.read())) {
                char nextChar = (char) nextByte;	// Works because we know we read a

                // byte. We're ignoring all sorts of
                // unicode and internationalization
                // issues though.

                localBuffer.append(nextChar);
            }
            _fileViewingArea.append(localBuffer.toString());
        }
    }
}
