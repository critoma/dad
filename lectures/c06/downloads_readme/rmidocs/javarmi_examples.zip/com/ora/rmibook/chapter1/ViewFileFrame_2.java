package com.ora.rmibook.chapter1;


import com.ora.rmibook.gui.*;

import java.io.*;
import javax.swing.*;
import java.awt.event.*;
import java.awt.*;


/*
 This is a better version of ViewFileFrame. It uses a FileReader
 and a BufferedReader in order to retrieve lines of text from the
 file. As part of doing so, unicode and internationalization
 issues are handled by the Javasoft libraries (seamlessly).

 Note that the way readers are used is exactly analagous to
 the way streams are used. 
 */

public class ViewFileFrame_2 extends ExitingFrame {
    private FileTextField _fileTextField;
    private JTextArea _fileViewingArea;
    protected void buildGUI() {
        _fileTextField = new FileTextField(new ViewFileAction());
        _fileViewingArea = new JTextArea();
        JScrollPane scrollPaneAroundTextArea = new JScrollPane(_fileViewingArea);

        scrollPaneAroundTextArea.setBorder(BorderFactory.createLoweredBevelBorder());
        JPanel newContentPane = new JPanel(new BorderLayout());

        newContentPane.add(_fileTextField, BorderLayout.NORTH);
        newContentPane.add(scrollPaneAroundTextArea, BorderLayout.CENTER);
        setContentPane(newContentPane);
        setSize(250, 300);
    }

    private class ViewFileAction extends AbstractAction {
        public ViewFileAction() {
            putValue(Action.NAME, "View");
            putValue(Action.SHORT_DESCRIPTION, "View file contents in main text area.");
        }

        public void actionPerformed(ActionEvent event) {
            FileReader fileReader = _fileTextField.getFileReader();

            if (null == fileReader) {
                _fileViewingArea.setText("Invalid file name");
            } else {
                try {
                    copyReaderToViewingArea(fileReader);
                    fileReader.close();
                } catch (java.io.IOException ioException) {
                    _fileViewingArea.setText("\n Error occured while reading file");
                }
            }
        }

        private void copyReaderToViewingArea(Reader reader)
            throws IOException {
            BufferedReader bufferedReader = new BufferedReader(reader);
            String nextLine;

            _fileViewingArea.setText("");
            while (null != (nextLine = bufferedReader.readLine())) {
                _fileViewingArea.append(nextLine + "\n");
            }
        }
    }
}
