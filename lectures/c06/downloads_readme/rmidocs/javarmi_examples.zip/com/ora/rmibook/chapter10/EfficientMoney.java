package com.ora.rmibook.chapter10;


import java.io.*;


public class EfficientMoney extends ValueObject implements Externalizable {
    public static final long serialVersionUID = 1;
    protected int _cents;

    public EfficientMoney(Integer cents) {
        this (cents.intValue());
    }

    public EfficientMoney(int cents) {
        super (cents + " cents.");
        _cents = cents;
    }

    public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
        _cents = in.readInt();
        _stringifiedRepresentation = _cents + " cents.";
    }

    public void writeExternal(ObjectOutput out) throws IOException {
        out.writeInt(_cents);
    }
}
