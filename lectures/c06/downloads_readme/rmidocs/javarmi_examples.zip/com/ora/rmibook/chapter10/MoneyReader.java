package com.ora.rmibook.chapter10;


import java.io.*;


public class MoneyReader {
    public static void main(String[] args) {
        try {
            FileInputStream fileInputStream = new FileInputStream("C:\\temp\\foo");
            ObjectInputStream objectInputStream = new ObjectInputStream(fileInputStream);

            objectInputStream.readObject();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
