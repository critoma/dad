package com.ora.rmibook.chapter10;


import java.io.*;


public class MoneyType implements Serializable {
    public String countryOfOrigin;
    public String currencyName;
}
