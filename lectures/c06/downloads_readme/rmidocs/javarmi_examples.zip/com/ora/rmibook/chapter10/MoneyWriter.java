package com.ora.rmibook.chapter10;


import java.io.*;
import java.util.*;


public class MoneyWriter {
    public static void main(String[] args) {
        writeOne();
        writeMany();
    }

    private static void writeOne() {
        try {
            System.out.println("Writing one instance");
            ReallyEfficientMoney money = new ReallyEfficientMoney(1000);

            writeObject("C:\\temp\\foo", money);
        } catch (Exception e) {
        }
    }

    private static void writeMany() {
        try {
            System.out.println("Writing many instances");
            ArrayList listOfMoney = new ArrayList();

            for (int i = 0; i < 10000; i++) {
                ReallyEfficientMoney money = new ReallyEfficientMoney(i * 100);

                listOfMoney.add(money);
            }
            writeObject("C:\\temp\\foo2", listOfMoney);
        } catch (Exception e) {
        }
    }

    private static void writeObject(String filename, Object object) throws Exception {
        FileOutputStream fileOutputStream = new FileOutputStream(filename);
        ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream);
        long startTime = System.currentTimeMillis();

        objectOutputStream.writeObject(object);
        objectOutputStream.flush();
        objectOutputStream.close();
        System.out.println("Time: " + (System.currentTimeMillis() - startTime));
    }
}
