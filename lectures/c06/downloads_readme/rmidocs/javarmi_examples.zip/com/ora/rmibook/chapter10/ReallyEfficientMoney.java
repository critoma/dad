package com.ora.rmibook.chapter10;


import java.io.*;


public class ReallyEfficientMoney implements Externalizable {
    public static final long serialVersionUID = 1;
    protected int _cents;
    protected String _stringifiedRepresentation;

    public ReallyEfficientMoney(Integer cents) {
        this (cents.intValue());
    }

    public ReallyEfficientMoney(int cents) {
        _cents = cents;
        _stringifiedRepresentation = _cents + " cents.";
    }

    public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
        _cents = in.readInt();
        _stringifiedRepresentation = _cents + " cents.";
    }

    public void writeExternal(ObjectOutput out) throws IOException {
        out.writeInt(_cents);
    }
}
