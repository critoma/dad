package com.ora.rmibook.chapter12.bank;


import com.ora.rmibook.chapter12.bank.valueobjects.*;
import java.rmi.*;
import java.rmi.server.*;


/*
 Has explicit lock management from client-side
 */

public class Account2_Impl extends UnicastRemoteObject implements Account2 {
    private Money _balance;
    private String _currentClient;

    public Account2_Impl(Money startingBalance)
        throws RemoteException {
        _balance = startingBalance;
    }

    public synchronized void getLock() throws RemoteException, LockedAccountException {
        if (false == becomeOwner()) {
            throw new LockedAccountException();
        }
        return;
    }

    public synchronized void releaseLock() throws RemoteException {
        String clientHost = wrapperAroundGetClientHost();

        if ((null != _currentClient) && (_currentClient.equals(clientHost))) {
            _currentClient = null;
        }
    }

    public synchronized Money getBalance()
        throws RemoteException, LockedAccountException {
        checkAccess();
        return _balance;
    }

    public synchronized void makeDeposit(Money amount)
        throws RemoteException, LockedAccountException, NegativeAmountException {
        checkAccess();
        checkForNegativeAmount(amount);
        _balance.add(amount);
        return;
    }

    public synchronized void makeWithdrawal(Money amount)
        throws RemoteException, OverdraftException, LockedAccountException, NegativeAmountException {
        checkAccess();
        checkForNegativeAmount(amount);
        checkForOverdraft(amount);
        _balance.subtract(amount);
        return;
    }

    private boolean becomeOwner() {
        String clientHost = wrapperAroundGetClientHost();

        if (null != _currentClient) {
            if (_currentClient.equals(clientHost)) {
                return true;
            }
        } else {
            _currentClient = clientHost;
            return true;
        }
        return false;
    }

    private void checkAccess() throws LockedAccountException {
        String clientHost = wrapperAroundGetClientHost();

        if ((null != _currentClient) && (_currentClient.equals(clientHost))) {
            return;
        }
        throw new LockedAccountException();
    }

    private String wrapperAroundGetClientHost() {
        String clientHost = null;

        try {
            clientHost = getClientHost();
        } catch (ServerNotActiveException ignored) {
        }
        return clientHost;
    }

    private void checkForNegativeAmount(Money amount)
        throws NegativeAmountException {
        int cents = amount.getCents();

        if (0 > cents) {
            throw new NegativeAmountException();
        }
    }

    private void checkForOverdraft(Money amount)
        throws OverdraftException {
        if (amount.greaterThan(_balance)) {
            throw new OverdraftException(false);
        }
        return;
    }
} 

