package com.ora.rmibook.chapter12.bank;


import com.ora.rmibook.chapter12.bank.valueobjects.*;
import java.rmi.*;


public interface Account3 extends Remote {
    public Money getBalance()
        throws RemoteException, LockedAccountException;
    public void makeDeposit(Money amount)
        throws RemoteException, NegativeAmountException, LockedAccountException;
    public void makeWithdrawal(Money amount)
        throws RemoteException, OverdraftException, LockedAccountException, NegativeAmountException;
}
