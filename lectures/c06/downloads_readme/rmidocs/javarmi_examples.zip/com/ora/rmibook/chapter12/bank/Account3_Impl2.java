package com.ora.rmibook.chapter12.bank;


import com.ora.rmibook.chapter12.bank.valueobjects.*;
import java.rmi.*;
import java.rmi.server.*;


/*
 Has timer-based lock management on server-side
 */

public class Account3_Impl2 extends UnicastRemoteObject implements Account3 {
    private static final int TIMER_DURATION = 120000;	// Two minutes

    private Money _balance;
    private String _currentClient;
    private int _timeLeftUntilLockIsReleased;

    public Account3_Impl2(Money startingBalance)
        throws RemoteException {
        _balance = startingBalance;
        _timeLeftUntilLockIsReleased = 0;
        (Account3_Impl2_LockThread.getSingleton()).addAccount(this);
        //	register with the lock-expiration thread
    }

    public synchronized Money getBalance()
        throws RemoteException, LockedAccountException {
        checkAccess();
        return _balance;
    }

    public synchronized void makeDeposit(Money amount)
        throws RemoteException, LockedAccountException, NegativeAmountException {
        checkAccess();
        checkForNegativeAmount(amount);
        _balance.add(amount);
        return;
    }

    public synchronized void makeWithdrawal(Money amount)
        throws RemoteException, OverdraftException, LockedAccountException, NegativeAmountException {
        checkAccess();
        checkForNegativeAmount(amount);
        checkForOverdraft(amount);
        _balance.subtract(amount);
        return;
    }

    private void checkAccess() throws LockedAccountException {
        String clientHost = wrapperAroundGetClientHost();

        if (null == _currentClient) {
            _currentClient = clientHost;
        } else {
            if (!_currentClient.equals(clientHost)) {
                throw new LockedAccountException();
            }
        }
        resetCounter();
        return;
    }

    private void resetCounter() {
        _timeLeftUntilLockIsReleased = TIMER_DURATION;
    }

    protected synchronized void decrementLockTimer(int amountToDecrement) {
        _timeLeftUntilLockIsReleased -= amountToDecrement;
        if (_timeLeftUntilLockIsReleased < 0) {
            _currentClient = null;
        }
    }

    private String wrapperAroundGetClientHost() {
        String clientHost = null;

        try {
            clientHost = getClientHost();
        } catch (ServerNotActiveException ignored) {
        }
        return clientHost;
    }

    private void checkForNegativeAmount(Money amount)
        throws NegativeAmountException {
        int cents = amount.getCents();

        if (0 > cents) {
            throw new NegativeAmountException();
        }
    }

    private void checkForOverdraft(Money amount)
        throws OverdraftException {
        if (amount.greaterThan(_balance)) {
            throw new OverdraftException(false);
        }
        return;
    }

}
