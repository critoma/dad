package com.ora.rmibook.chapter12.bank;


import java.util.*;


public class Account3_Impl2_LockThread extends Thread {
    private static final int THREAD_SLEEP_TIME = 10000;	// 10 seconds
    private static Account3_Impl2_LockThread _singleton;

    public synchronized static Account3_Impl2_LockThread getSingleton() {
        if (null == _singleton) {
            _singleton = new Account3_Impl2_LockThread();
            _singleton.start();
        }
        return _singleton;
    }

    private ArrayList _accounts;

    private Account3_Impl2_LockThread() {
        _accounts = new ArrayList();
    }

    public synchronized void addAccount(Account3 newAccount) {
        _accounts.add(newAccount);
    }

    public void run() {
        while (true) {
            try {
                Thread.sleep(THREAD_SLEEP_TIME);
            } catch (Exception ignored) {
            }
            decrementLockTimers();
        }
    }

    private synchronized void decrementLockTimers() {
        Iterator i = _accounts.iterator();

        while (i.hasNext()) {
            Account3_Impl2 nextAccount = (Account3_Impl2) i.next();

            nextAccount.decrementLockTimer(THREAD_SLEEP_TIME);
        }
    }
}
