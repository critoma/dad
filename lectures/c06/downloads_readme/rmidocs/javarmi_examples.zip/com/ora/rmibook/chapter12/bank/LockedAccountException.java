package com.ora.rmibook.chapter12.bank;


public class LockedAccountException extends Exception {
} 
