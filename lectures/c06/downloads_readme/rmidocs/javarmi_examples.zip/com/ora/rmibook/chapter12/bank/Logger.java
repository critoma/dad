package com.ora.rmibook.chapter12.bank;


import java.io.*;


public interface Logger {
    public void setOutputStream(PrintStream outputStream);
    public void logString(String string);
}
