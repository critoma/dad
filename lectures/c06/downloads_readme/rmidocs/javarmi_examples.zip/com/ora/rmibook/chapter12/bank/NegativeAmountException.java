package com.ora.rmibook.chapter12.bank;


public class NegativeAmountException extends Exception {
} 
