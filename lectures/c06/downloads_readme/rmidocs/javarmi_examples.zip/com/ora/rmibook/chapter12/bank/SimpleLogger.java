package com.ora.rmibook.chapter12.bank;


import java.io.*;


public class SimpleLogger implements Logger {
    private static SimpleLogger _singleton;
    public synchronized static SimpleLogger getSingleton() {
        if (null == _singleton) {
            _singleton = new SimpleLogger();
        }
        return _singleton;
    }

    private PrintStream _loggingStream;
    private SimpleLogger() {
        _loggingStream = System.err;
    }

    public void setOutputStream(PrintStream outputStream) {
        _loggingStream = outputStream;
    }
    
    public synchronized void logString(String string) {
        _loggingStream.println(string);
    }
} 

