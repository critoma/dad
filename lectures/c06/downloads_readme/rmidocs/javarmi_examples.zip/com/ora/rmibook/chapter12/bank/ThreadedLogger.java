package com.ora.rmibook.chapter12.bank;


import java.io.*;
import java.util.*;


public class ThreadedLogger implements Logger {
    private SimpleLogger _actualLogger;
    private ArrayList _logQueue;
    public ThreadedLogger(SimpleLogger actualLogger) {
        _logQueue = new ArrayList();
        (new BackgroundThread()).start();
    }

    public void setOutputStream(PrintStream outputStream) {
        _actualLogger.setOutputStream(outputStream);
    }

    public synchronized void logString(String string) {
        _logQueue.add(string);
    }

    private synchronized Collection getAndReplaceQueue() {
        ArrayList returnValue = _logQueue;

        _logQueue = new ArrayList();
        return returnValue;
    }

    private class BackgroundThread extends Thread {
        public void run() {
            while (true) {
                pause();
                logEntries();
            }
        }

        private void pause() {
            try {
                Thread.sleep(5000);
            } catch (Exception ignored) {
            }
        }

        private void logEntries() {
            Collection entries = getAndReplaceQueue();
            Iterator i = entries.iterator();

            while (i.hasNext()) {
                String nextString = (String) i.next();

                _actualLogger.logString(nextString);
            }
        }
    }
}
