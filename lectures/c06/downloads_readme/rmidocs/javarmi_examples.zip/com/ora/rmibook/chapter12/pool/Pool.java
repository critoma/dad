package com.ora.rmibook.chapter12.pool;


public interface Pool {
    public Object getObject();
    public void returnObject(Object object);
}
