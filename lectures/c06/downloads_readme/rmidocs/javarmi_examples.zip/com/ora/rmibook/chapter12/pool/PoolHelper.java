package com.ora.rmibook.chapter12.pool;


public interface PoolHelper {
    public Object create();
    public boolean dispose(Object object);
    public boolean isObjectStillValid(Object object);
}
