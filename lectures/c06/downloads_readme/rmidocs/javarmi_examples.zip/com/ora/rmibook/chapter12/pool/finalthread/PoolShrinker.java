package com.ora.rmibook.chapter12.pool.finalthread;


public class PoolShrinker implements Runnable {
    private static final int DEFAULT_TIME_TO_WAIT = 120000;
    private static final int DEFAULT_TIME_INTERVAL = 5000;
    private ThreadedPool_Final _owner;
    private int _timeLeftUntilWeShrinkThePool;
    private boolean _paused;
    public PoolShrinker(ThreadedPool_Final owner) {
        _owner = owner;
        _timeLeftUntilWeShrinkThePool = DEFAULT_TIME_TO_WAIT;
    }

    public synchronized void pause() {
        _paused = true;
    }

    public synchronized void resume() {
        _timeLeftUntilWeShrinkThePool = DEFAULT_TIME_TO_WAIT;
        _paused = false;
    }

    public void run() {
        while (true) {
            try {
                Thread.sleep(DEFAULT_TIME_INTERVAL);
            } catch (InterruptedException e) {/* ignored*/
            }
            if (!_paused) {
                decrementClock();
                if (0 == _timeLeftUntilWeShrinkThePool) {
                    _owner.removeAnObject();
                    resetClock();
                }
            }
        }
    }

    private synchronized void resetClock() {
        _timeLeftUntilWeShrinkThePool = DEFAULT_TIME_TO_WAIT;
    }

    private synchronized void decrementClock() {
        _timeLeftUntilWeShrinkThePool -= DEFAULT_TIME_INTERVAL;
        if (0 > _timeLeftUntilWeShrinkThePool) {
            _timeLeftUntilWeShrinkThePool = 0;
        }
    }
}
