package com.ora.rmibook.chapter12.pool.thread1;


import com.ora.rmibook.chapter12.pool.*;


public class ObjectCreator implements Runnable {
    private ThreadedPool1 _owner;
    private boolean _requestPending;
    public ObjectCreator(ThreadedPool1 owner) {
        _owner = owner;
    }

    public void run() {
        boolean needToCreate = false;

        while (true) {
            synchronized (this) {
                while (!_requestPending) {
                    try {
                        wait();
                    } catch (InterruptedException e) {/* ignored */
                    }
                }
                needToCreate = _requestPending;
                _requestPending = false;
            }
            if (needToCreate) {
                _owner.createAndAddObject();
            }
        }
    }

    public synchronized void askForObject() {
        _requestPending = true;
        notify();
    }
}
