package com.ora.rmibook.chapter12.pool.thread2;


import com.ora.rmibook.chapter12.pool.*;
import java.util.*;


public class ObjectReturner implements Runnable {
    private Vector _objectsToReturn;
    private ThreadedPool2 _owner;
    public ObjectReturner(ThreadedPool2 owner) {
        _owner = owner;
        _objectsToReturn = new Vector();
    }
    
    public void run() {
        while (true) {
            Object objectToReturn;

            while (0 == _objectsToReturn.size()) {
                synchronized (_objectsToReturn) {
                    try {
                        _objectsToReturn.wait();
                    } catch (InterruptedException e) {
                    }
                }
            }
            int lastIndex = _objectsToReturn.size() - 1;

            objectToReturn = _objectsToReturn.remove(lastIndex);
            _owner.returnObjectToPool(objectToReturn);
        }
    }

    public void validateAndReturn(Object object) {
        synchronized (_objectsToReturn) {
            _objectsToReturn.add(object);
            if (1 == _objectsToReturn.size()) {
                _objectsToReturn.notify();
            }
        }
    }
}
