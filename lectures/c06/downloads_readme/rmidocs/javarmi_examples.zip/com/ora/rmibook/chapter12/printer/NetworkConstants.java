package com.ora.rmibook.chapter12.printer;


public interface NetworkConstants {
    public static final String DEFAULT_PRINTER_NAME = "Default Printer";
}
