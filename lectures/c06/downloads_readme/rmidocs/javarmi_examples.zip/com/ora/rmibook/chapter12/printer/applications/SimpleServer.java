package com.ora.rmibook.chapter12.printer.applications;


import com.ora.rmibook.chapter12.printer.printers.*;
import com.ora.rmibook.chapter12.printer.*;
import java.io.*;
import java.rmi.*;
import java.rmi.server.*;


public class SimpleServer implements NetworkConstants {
    public static void main(String args[]) {
        try {
            File logfile = new File("C:\\temp\\serverLogfile");
            OutputStream outputStream = new FileOutputStream(logfile);
            Printer realPrinter = new NullPrinter(outputStream);
            Printer batchingPrinter = new BatchingPrinter(realPrinter);

            Naming.rebind(DEFAULT_PRINTER_NAME, batchingPrinter);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
} 

