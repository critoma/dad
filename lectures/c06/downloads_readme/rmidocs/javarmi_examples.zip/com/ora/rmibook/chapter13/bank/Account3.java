package com.ora.rmibook.chapter13.bank;


import com.ora.rmibook.chapter13.bank.valueobjects.*;
import java.rmi.*;


public interface Account3 extends Remote {
    public Money getBalance(String clientIDNumber)
        throws RemoteException, LockedAccountException;
    public void makeDeposit(String clientIDNumber, Money amount)
        throws RemoteException, NegativeAmountException, LockedAccountException;
    public void makeWithdrawal(String clientIDNumber, Money amount)
        throws RemoteException, OverdraftException, LockedAccountException, NegativeAmountException;
}
