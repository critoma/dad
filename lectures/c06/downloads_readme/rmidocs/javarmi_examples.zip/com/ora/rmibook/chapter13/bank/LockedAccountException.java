package com.ora.rmibook.chapter13.bank;


public class LockedAccountException extends Exception {
} 
