package com.ora.rmibook.chapter13.bank;


public class NegativeAmountException extends Exception {
} 
