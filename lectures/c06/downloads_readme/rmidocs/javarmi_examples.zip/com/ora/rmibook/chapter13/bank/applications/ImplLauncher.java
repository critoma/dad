package com.ora.rmibook.chapter13.bank.applications;


import com.ora.rmibook.chapter13.bank.*;
import com.ora.rmibook.chapter13.bank.valueobjects.*;
import java.util.*;
import java.rmi.*;


public class ImplLauncher {
    public static void main(String[] args) {
        int numberOfServers = (Integer.valueOf(args[0])).intValue();
        NameRepository nameRepository = new NameRepository(numberOfServers);
        Collection nameBalancePairs = getNameBalancePairs(nameRepository);
        Iterator i = nameBalancePairs.iterator();

        while (i.hasNext()) {
            NameBalancePair nextNameBalancePair = (NameBalancePair) i.next();

            launchServer(nextNameBalancePair);
        }
    }

    private static void launchServer(NameBalancePair serverDescription) {
        try {
            Account3_Impl2 newAccount = new Account3_Impl2(serverDescription.balance);

            Naming.rebind(serverDescription.name, newAccount);
            System.out.println("Account " + serverDescription.name + " successfully launched.");
        } catch (Exception e) {
        }
    }

    private static Collection getNameBalancePairs(NameRepository nameRepository) {
        ArrayList returnValue = new ArrayList();
        Iterator i = nameRepository.getAllNames();

        while (i.hasNext()) {
            NameBalancePair nextNameBalancePair = new NameBalancePair();

            nextNameBalancePair.name = (String) i.next();
            int cents = (int) (Math.random() * 100000);

            nextNameBalancePair.balance = new Money(cents);
            returnValue.add(nextNameBalancePair);
        }
        return returnValue;
    }

    private static class NameBalancePair {
        String name;
        Money balance;
    }
}
