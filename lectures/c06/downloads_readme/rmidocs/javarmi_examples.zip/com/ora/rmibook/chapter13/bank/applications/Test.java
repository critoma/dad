package com.ora.rmibook.chapter13.bank.applications;


import com.ora.rmibook.chapter13.bank.valueobjects.*;
import com.ora.rmibook.chapter13.bank.*;
import java.rmi.*;


public abstract class Test implements Comparable {
    public static final String UNABLE_TO_CONNECT = "Unable to connect";
    public static final String ACCOUNT_WAS_LOCKED = "Account was locked";
    public static final String REMOTE_EXCEPTION_THROWN = "A remote exception was thrown";
    public static final String FAILURE = "Operation completed with incorrect result";
    public static final String SUCCESS = "Everything was cool";

    public String status;
    public long duration;
    public long startTime;
    public String accountName;

    private NameRepository _nameRepository;
    private String _className;

    protected abstract String performActualTest(String idNumber, Account3 account);

    protected abstract String describeOperation();

    public Test(NameRepository nameRepository) {
        _nameRepository = nameRepository;
        _className = getClass().getName();
    }

    public void performTest(String idNumber) {
        Account3 account = getAccount();

        if (null == account) {
            status = UNABLE_TO_CONNECT;
            duration = 0;
            return;
        }
        startTime = System.currentTimeMillis();
        status = performActualTest(idNumber, account);
        duration = System.currentTimeMillis() - startTime;
        return;
    }

    public String describeOutcome() {
        return "Attempted to " + describeOperation() + " account " + accountName
            + " at " + startTime + ". \n\t The operation took " + duration 
            + " milliseconds and the result was : " + status + "\n";
    }

    public int compareTo(Object object) {
        // first sort is alphabetical, on class name.
        // second test is on account name
        // third test is by startTime.
        // fourth test uses hashcode

        Test otherTest = (Test) object;
        String otherClassName = (otherTest.getClass()).getName();
        int firstTest = _className.compareTo(otherClassName);

        if (0 != firstTest) {
            return firstTest;
        }
        int secondTest = accountName.compareTo(otherTest.accountName);

        if (0 != secondTest) {
            return secondTest;
        }
        if (startTime < otherTest.startTime) {
            return -1;
        } else {
            if (startTime > otherTest.startTime) {
                return +1;
            }
        }
        return hashCode() - otherTest.hashCode();
    }

    protected Money getRandomMoney() {

        /*
         Sometimes the money will be negative. But,
         most of the time, we'll send in positive amounts.
         */
        int cents = -2000 + (int) (Math.random() * 100000);

        return new Money(cents);
    }

    private Account3 getAccount() {
        accountName = _nameRepository.getAName();
        Account3 account = null;;
        try {
            account = (Account3) Naming.lookup(accountName);
        } catch (Exception e) {
        }
        return account;
    }
}
