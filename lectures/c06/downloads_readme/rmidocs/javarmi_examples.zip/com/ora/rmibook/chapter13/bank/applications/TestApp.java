package com.ora.rmibook.chapter13.bank.applications;


public class TestApp {
    public static void main(String args[]) {
        try {
            int numberOfServers = (Integer.valueOf(args[0])).intValue();

            (new TestAppFrame(numberOfServers)).show();
        } catch (Exception ignored) {
        }
    }
}
