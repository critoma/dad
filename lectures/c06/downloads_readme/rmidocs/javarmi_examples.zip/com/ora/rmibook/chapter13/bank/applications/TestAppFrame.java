package com.ora.rmibook.chapter13.bank.applications;


import com.ora.rmibook.gui.*;
import javax.swing.*;
import java.awt.event.*;
import java.util.*;
import java.awt.*;


public class TestAppFrame extends ExitingFrame {
    private static String ALL_ACCOUNTS = "Get Data For All Accounts";
    private TestResultHolder _testResultHolder;
    private NameRepository _nameRepository;
    private JTextField _numberOfThreadsField;
    private JTextField _numberOfOperationsField;
    private JButton _testButton;
    private JTextArea _resultsArea;
    private JComboBox _accountChooser;
    private int _numberOfFinishedThreads;
    private int _numberOfThreads;
    private ChooserListener _chooserListener;
    private Rectangle _upperLeftCorner;
    public TestAppFrame(int numberOfServers) {
        _nameRepository = new NameRepository(numberOfServers);
        _chooserListener = new ChooserListener();
        _upperLeftCorner = new Rectangle (0, 0, 1, 1);
    }
    
    protected void buildGUI() {
        setTitle("Chapter 12 Testing Application");
        JPanel mainPanel = new JPanel(new BorderLayout());

        mainPanel.add(buildConfigurationPanel(), BorderLayout.NORTH);
        mainPanel.add(buildResultsWindow(), BorderLayout.CENTER);
        setSize(600, 400);
        setContentPane(mainPanel);
    }

    private JComponent buildConfigurationPanel() {
        JPanel returnValue = new JPanel(new GridLayout(1, 5));

        _numberOfThreadsField = new JTextField();
        _numberOfOperationsField = new JTextField();
        _testButton = new JButton("Perform Test");
        _testButton.addActionListener(new TestLauncher());
        returnValue.add(new JLabel("Number of Clients"));
        returnValue.add(_numberOfThreadsField);
        returnValue.add(new JLabel("Number of Operations"));
        returnValue.add(_numberOfOperationsField);
        returnValue.add(_testButton);
        returnValue.setBorder(BorderFactory.createEtchedBorder());
        return returnValue;
    }

    private JComponent buildResultsWindow() {
        JPanel returnValue = new JPanel(new BorderLayout());

        _resultsArea = new JTextArea();
        _accountChooser = new JComboBox();
        returnValue.add(_accountChooser, BorderLayout.NORTH);
        returnValue.add(new JScrollPane(_resultsArea), BorderLayout.CENTER);
        return returnValue;
    }

    protected synchronized void testThreadFinished(TestThread testThread) {
        _numberOfFinishedThreads++;
    }

    protected synchronized boolean someThreadsNotFinished() {
        return _numberOfFinishedThreads < _numberOfThreads;
    }

    private void reset() {
        _testResultHolder = new TestResultHolder();
        _numberOfFinishedThreads = 0;
    }

    private void resetGUI() {
        _testResultHolder.sortResults();
        _accountChooser.removeActionListener(_chooserListener);
        _accountChooser.removeAllItems();
        _accountChooser.addItem(ALL_ACCOUNTS);
        Iterator i = (_testResultHolder.getAccountNames()).iterator();

        while (i.hasNext()) {
            _accountChooser.addItem(i.next());
        }
        _resultsArea.setText("");
        _accountChooser.addActionListener(_chooserListener);
        computeSummaryforAllAccounts();
    }

    private void summarize(ResultsSummary summaryObject, Collection tests, boolean addDescriptions) {
        Iterator i = tests.iterator();

        while (i.hasNext()) {
            Test nextTest = (Test) i.next();

            summaryObject.totalTime += nextTest.duration;
            summaryObject.numberOfTests++;
            if (addDescriptions) {
                summaryObject.resultsString += nextTest.describeOutcome();
            }
            if (summaryObject.longestTime < nextTest.duration) {
                summaryObject.longestTime = nextTest.duration;
            }
            if (nextTest.status == Test.FAILURE) {
                summaryObject.numberOfFailures++;
            }
            if (nextTest.status == Test.ACCOUNT_WAS_LOCKED) {
                summaryObject.numberOfLocks++;
            }
            if (nextTest.status == Test.REMOTE_EXCEPTION_THROWN) {
                summaryObject.numberOfRemoteExceptions++;
            }
            if (nextTest.status == Test.UNABLE_TO_CONNECT) {
                summaryObject.numberOfUnableToConnects++;
            }
            if (nextTest.status == Test.SUCCESS) {
                summaryObject.numberOfSuccesses++;
            }
        }
    }

    private void computeSummaryforAllAccounts() {
        ResultsSummary summaryObject = new ResultsSummary();
        Iterator i = (_testResultHolder.getAccountNames()).iterator();

        while (i.hasNext()) {
            String nextAccountName = (String) i.next();

            summarize(summaryObject, _testResultHolder.getResultsForAccount(nextAccountName), false);
        }
        displaySummary(summaryObject);
    }

    private void computeSummaryForChosenAccount(String accountName) {
        ResultsSummary summaryObject = new ResultsSummary();

        summarize(summaryObject, _testResultHolder.getResultsForAccount(accountName), true);
        displaySummary(summaryObject);
    }

    private void displaySummary(ResultsSummary summaryObject) {
        String partialString = "Number of operations : " + summaryObject.numberOfTests + "\n"
            + "\tAverage operation time: " + (summaryObject.totalTime / summaryObject.numberOfTests) + " milliseconds.\n"
            + "\tLongest operation time: " + summaryObject.longestTime + " milliseconds.\n"
            + "\tNumber of successes : " + summaryObject.numberOfSuccesses + ".\n"
            + "\tNumber of failures : " + summaryObject.numberOfFailures + ".\n"
            + "\tNumber of locks : " + summaryObject.numberOfLocks + ".\n"
            + "\tNumber of remote exceptions : " + summaryObject.numberOfRemoteExceptions + ".\n"
            + "\tNumber of unable to connects : " + summaryObject.numberOfUnableToConnects + ".\n";

        if (summaryObject.resultsString.equals("")) {
            summaryObject.resultsString = partialString;
        } else {
            summaryObject.resultsString = partialString
                    + "\n\n" + "Detailed Results \n ==================\n\n"
                    + summaryObject.resultsString;
        }
        _resultsArea.setText(summaryObject.resultsString);
        _resultsArea.scrollRectToVisible(_upperLeftCorner);
    }

    private class TestLauncher implements ActionListener {
        public void actionPerformed(ActionEvent event) {
            try {
                reset();
                _numberOfThreads = (Integer.valueOf(_numberOfThreadsField.getText())).intValue();
                int numberOfOperations = (Integer.valueOf(_numberOfOperationsField.getText())).intValue();
                int counter;

                for (counter = 0; counter < _numberOfThreads; counter++) {
                    TestThread nextThread = new TestThread(_nameRepository, numberOfOperations,
                            _testResultHolder, TestAppFrame.this);

                    nextThread.start();
                    Thread.sleep(100);	// wait a little bit to spread out the load
                }
                while (someThreadsNotFinished()) {
                    Thread.sleep(10000); 	// 10 seconds. It's not bad
                }
            } catch (Exception exception) {
            } finally {
                resetGUI();
            }
        }
    }


    private class ChooserListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            String accountName = (String) _accountChooser.getSelectedItem();

            if (accountName == ALL_ACCOUNTS) {
                computeSummaryforAllAccounts();
            } else {
                computeSummaryForChosenAccount(accountName);
            }
        }
    }


    private class ResultsSummary {
        public String resultsString = "";
        public long totalTime = 0;
        public long longestTime = 0;
        public int numberOfTests = 0;
        public int numberOfFailures = 0;
        public int numberOfLocks = 0;
        public int numberOfRemoteExceptions = 0;
        public int numberOfSuccesses = 0;
        public int numberOfUnableToConnects = 0;
    }
}
