package com.ora.rmibook.chapter13.bank.applications;


import java.util.*;


public class TestResultHolder {
    private Hashtable _resultsTable;
    private Vector _accountNames;
    public TestResultHolder() {
        _resultsTable = new Hashtable();
        _accountNames = new Vector();
    }

    public void addResult(Test test) {
        Vector resultsVector = (Vector) _resultsTable.get(test.accountName);

        if (null == resultsVector) {
            resultsVector = new Vector();
            _resultsTable.put(test.accountName, resultsVector);
            _accountNames.add(test.accountName);
        }
        resultsVector.add(test);
    }

    public void sortResults() {
        Collections.sort(_accountNames);
        Iterator valueVectors = (_resultsTable.values()).iterator();

        while (valueVectors.hasNext()) {
            Vector nextVector = (Vector) valueVectors.next();

            Collections.sort(nextVector);
        }
        return;
    }

    public Collection getAccountNames() {
        return _accountNames;
    }

    public Collection getResultsForAccount(String accountName) {
        return (Collection) _resultsTable.get(accountName);
    }

}
