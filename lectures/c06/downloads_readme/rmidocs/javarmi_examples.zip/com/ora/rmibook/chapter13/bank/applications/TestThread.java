package com.ora.rmibook.chapter13.bank.applications;


import com.ora.rmibook.chapter13.bank.applications.tests.*;


public class TestThread extends Thread {
    //	private static final int MILLISECONDS_TO_PAUSE = 240000;
    private static final int MILLISECONDS_TO_PAUSE = 2000;
    private static int _idNumberCounter;
    private NameRepository _nameRepository;
    private TestResultHolder _testResultHolder;
    private int _numberOfOperationsLeft;
    private TestAppFrame _owner;
    private String _idNumber;

    public TestThread(NameRepository nameRepository, int numberOfOperations,
        TestResultHolder testResultHolder, TestAppFrame owner) {
        _testResultHolder = testResultHolder;
        _nameRepository = nameRepository;
        _numberOfOperationsLeft = numberOfOperations;
        _owner = owner;
        _idNumber = String.valueOf(_idNumberCounter++);
    }

    public void run() {
        while (_numberOfOperationsLeft > 0) {
            Test testToPerform = getRandomTest();

            testToPerform.performTest(_idNumber);
            _testResultHolder.addResult(testToPerform);
            try {
                Thread.sleep(MILLISECONDS_TO_PAUSE);
            } catch (Exception ignored) {
            }
            _numberOfOperationsLeft--;
        }
        _owner.testThreadFinished(this);
    }

    private Test getRandomTest() {
        double choice = Math.random();

        if (choice < .1) {
            return new GetBalance(_nameRepository);
        }
        if (choice < .6) {
            return new MakeDeposit(_nameRepository);
        }
        return new MakeWithdrawal(_nameRepository);
    }
} 

