package com.ora.rmibook.chapter13.bank.applications;


public interface TestThreadOwner {
    public void testThreadFinished(TestThread testThread);
}
