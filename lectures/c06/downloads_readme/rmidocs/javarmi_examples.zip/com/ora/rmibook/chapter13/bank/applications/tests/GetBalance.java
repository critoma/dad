package com.ora.rmibook.chapter13.bank.applications.tests;


import com.ora.rmibook.chapter13.bank.applications.*;
import com.ora.rmibook.chapter13.bank.*;
import java.rmi.*;


public class GetBalance extends Test {
    public GetBalance(NameRepository nameRepository) {
        super (nameRepository);
    }

    protected String describeOperation() {
        return "get the balance from";
    }

    protected String performActualTest(String idNumber, Account3 account) {
        try {
            account.getBalance(idNumber);
        } catch (RemoteException remoteException) {
            return REMOTE_EXCEPTION_THROWN;
        } catch (LockedAccountException lockedAccountException) {
            return ACCOUNT_WAS_LOCKED;
        }
        return SUCCESS;
    }

}
