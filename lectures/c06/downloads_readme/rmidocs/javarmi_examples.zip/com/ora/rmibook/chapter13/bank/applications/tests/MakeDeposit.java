package com.ora.rmibook.chapter13.bank.applications.tests;


import com.ora.rmibook.chapter13.bank.applications.*;
import com.ora.rmibook.chapter13.bank.valueobjects.*;
import com.ora.rmibook.chapter13.bank.*;
import java.rmi.*;


public class MakeDeposit extends Test {
    public MakeDeposit(NameRepository nameRepository) {
        super (nameRepository);
    }

    protected String describeOperation() {
        return "make a deposit to ";
    }

    protected String performActualTest(String idNumber, Account3 account) {
        Money balance;
        Money amountToDeposit = getRandomMoney();
        Money correctResult;
        Money actualResultingBalance;

        try {
            balance = account.getBalance(idNumber);
            correctResult = balance.add(amountToDeposit);
            account.makeDeposit(idNumber, amountToDeposit);
            actualResultingBalance = account.getBalance(idNumber);
        } catch (RemoteException remoteException) {
            return REMOTE_EXCEPTION_THROWN;
        } catch (LockedAccountException lockedAccountException) {
            return ACCOUNT_WAS_LOCKED;
        } catch (NegativeAmountException negativeAmountException) {
            if (amountToDeposit.isNegative()) {
                return SUCCESS;
            } else {
                return FAILURE;
            }
        }
        if (amountToDeposit.isNegative()) {
            return FAILURE;
        }
        if (correctResult.equals(actualResultingBalance)) {
            return SUCCESS;
        } else {
            return FAILURE;
        }
    }
}
