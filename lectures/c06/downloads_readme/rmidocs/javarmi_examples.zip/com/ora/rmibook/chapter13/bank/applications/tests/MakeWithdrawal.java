package com.ora.rmibook.chapter13.bank.applications.tests;


import com.ora.rmibook.chapter13.bank.applications.*;
import com.ora.rmibook.chapter13.bank.valueobjects.*;
import com.ora.rmibook.chapter13.bank.*;
import java.rmi.*;


public class MakeWithdrawal extends Test {
    public MakeWithdrawal(NameRepository nameRepository) {
        super (nameRepository);
    }

    protected String describeOperation() {
        return "make a widthdrawal from ";
    }
    
    protected String performActualTest(String idNumber, Account3 account) {
        Money balance = null;
        Money amountToWithdraw = getRandomMoney();
        Money correctResult;
        Money actualResultingBalance;

        try {
            balance = account.getBalance(idNumber);
            correctResult = balance.subtract(amountToWithdraw);
            account.makeWithdrawal(idNumber, amountToWithdraw);
            actualResultingBalance = account.getBalance(idNumber);
        } catch (RemoteException remoteException) {
            return REMOTE_EXCEPTION_THROWN;
        } catch (OverdraftException overdraftException) {
            if (amountToWithdraw.greaterThan(balance)) {
                return SUCCESS;
            } else {
                return FAILURE;
            }
        } catch (LockedAccountException lockedAccountException) {
            return ACCOUNT_WAS_LOCKED;
        } catch (NegativeAmountException negativeAmountException) {
            if (amountToWithdraw.isNegative()) {
                return SUCCESS;
            } else {
                return FAILURE;
            }
        }
        if (amountToWithdraw.greaterThan(balance)) {
            return FAILURE;
        }
        if (amountToWithdraw.isNegative()) {
            return FAILURE;
        }
        if (correctResult.equals(actualResultingBalance)) {
            return SUCCESS;
        } else {
            return FAILURE;
        }
    }
}
