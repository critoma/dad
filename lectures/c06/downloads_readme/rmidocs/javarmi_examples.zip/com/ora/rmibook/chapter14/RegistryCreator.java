/*
 Simple example of how to create a registry
 */
package com.ora.rmibook.chapter14;


import java.rmi.*;
import java.rmi.registry.*;


public class RegistryCreator {
    public static final int OUR_PORT = 3400;
    public static void main(String[] args) {
        try {
            Registry ourRegistry = LocateRegistry.createRegistry(OUR_PORT);
            Registry preexistingRegistry = LocateRegistry.getRegistry(1099);

            preexistingRegistry.rebind("secondary registry", ourRegistry);
        } catch (RemoteException ignored) {
        }
    }
}
