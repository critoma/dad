package com.ora.rmibook.chapter14;


public class RegistryExplorer {
    public static void main(String[] args) {
        (new RegistryExplorerFrame()).show();
    }
}
