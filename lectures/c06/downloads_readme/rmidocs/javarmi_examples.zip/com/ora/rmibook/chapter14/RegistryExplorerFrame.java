package com.ora.rmibook.chapter14;


import java.util.*;
import java.rmi.*;
import javax.swing.*;
import java.awt.event.*;
import java.awt.*;


public class RegistryExplorerFrame extends JFrame {
    private JTextArea _resultsArea;
    private JTextField _portTextField;
    private JButton _queryRegistryButton;

    public RegistryExplorerFrame() {
        buildGUI();
        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        addWindowListener(new ExitOnClose());
    }

    private void buildGUI() {
        JPanel mainPanel = new JPanel(new BorderLayout());

        _resultsArea = new JTextArea();
        mainPanel.add(new JScrollPane(_resultsArea), BorderLayout.CENTER);
        _queryRegistryButton = new JButton("Check Registry Contents");
        _queryRegistryButton.addActionListener(new QueryRegistry());
        mainPanel.add(_queryRegistryButton, BorderLayout.SOUTH);
        getContentPane().add(mainPanel);
        setSize(250, 200);
    }

    private void displayInformationForName(String name) throws Exception {
        Object value = Naming.lookup(name);

        if (null == value) {
            _resultsArea.append("Server named " + name + " is not in registry\n");
            return;
        }
        Collection interfaces = getRemoteInterfacesForObject(value);

        if (null == interfaces) {
            _resultsArea.append("Object named " + name + " is not a server\n");
            return;
        }
        _resultsArea.append("Server named " + name + " implements the following remote interfaces\n");
        Iterator i = interfaces.iterator();

        while (i.hasNext()) {
            _resultsArea.append("\t" + i.next() + "\n");
        }
        return;
    }
    
    private Collection getRemoteInterfacesForObject(Object object) {
        Class objectType = object.getClass();
        Class[] interfaces = objectType.getInterfaces();
        Class remoteInterface = Remote.class;

        if ((null == interfaces) || (0 == interfaces.length)) {
            return null;
        }
        ArrayList returnValue = new ArrayList();
        int counter;

        for (counter = 0; counter < interfaces.length; counter++) {
            if (remoteInterface.isAssignableFrom(interfaces[counter])) {
                returnValue.add(interfaces[counter]);
            }
        }
        return returnValue;
    }

    private class QueryRegistry implements ActionListener {
        public void actionPerformed(ActionEvent event) {
            try {
                String[] names = Naming.list("//localhost:1099");

                if ((null == names) || (0 == names.length)) {
                    _resultsArea.setText("The Registry is Empty");
                    return;
                }
                _resultsArea.setText("");
                int counter;

                for (counter = 0; counter < names.length; counter++) {
                    displayInformationForName(names[counter]);
                }
            } catch (Exception exception) {
                System.out.println(exception);
                exception.printStackTrace();
            }
        }
    }


    private class ExitOnClose extends WindowAdapter {
        public void windowClosed(WindowEvent event) {
            System.exit(0);
        }
    }
} 

