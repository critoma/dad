package com.ora.rmibook.chapter15;


import com.ora.rmibook.chapter15.exceptions.*;
import java.rmi.*;


public interface Context extends Remote {
    // Basic binding functionality

    public void bind(Path path, String name, AttributeSet attributes, Remote server)
        throws RemoteException, NamingException;
    public void rebind(Path path, String name, AttributeSet attributes, Remote server)
        throws RemoteException, NamingException;
    public void unbind(Path path, String name, AttributeSet attributes)
        throws RemoteException, NamingException;

    // Basic querying functionality

    public Remote lookup(Path path, String name, AttributeSet attributes)
        throws RemoteException, NamingException;
    public Remote[] list()
        throws RemoteException, NamingException;
    public Remote[] list(AttributeSet attributes)
        throws RemoteException, NamingException;
    public Remote[] list(String name, AttributeSet attributes)
        throws RemoteException, NamingException;
    public Remote[] list(Path path, String name, AttributeSet attributes)
        throws RemoteException, NamingException;

    // Context-level API

    public Context lookupSubContext(Path path, String name)
        throws RemoteException, NamingException;
    public ContextList listSubContexts() throws RemoteException, NamingException;
    public ContextList listSubContexts(Path path)
        throws RemoteException, NamingException;

    public Context createSubContext(Path path, String name)
        throws RemoteException, NamingException;
    public void bindSubContext(Path path, String name, Context context)
        throws RemoteException, NamingException;
    public void rebindSubContext(Path path, String name, Context context)
        throws RemoteException, NamingException;
    public void unbindSubContext(Path path, String name)
        throws RemoteException, NamingException;
}
