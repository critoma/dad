package com.ora.rmibook.chapter15;


import java.util.*;
import java.io.*;


public class ContextList extends SerializableList {
    private ContextList() {/* here so we can deserialize */
    }

    public ContextList(Collection components) {
        super (components);
    }

    protected boolean containerIsOfSameType(Object object) {
        return (object instanceof ContextList);
    }

    protected boolean equalObjects(Object firstObject, Object secondObject) {
        Context firstContext = (Context) firstObject;
        Context secondContext = (Context) secondObject;

        return firstContext.equals(secondContext);
    }
}
