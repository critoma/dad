package com.ora.rmibook.chapter15;


import java.io.*;
import java.util.*;


public class Path extends SerializableList {
    public static Path buildPath(String[] components) {
        ArrayList arrayList = new ArrayList(components.length);

        for (int i = 0; i < components.length; i++) {
            if ((null != components[i]) && (0 != components[i].length())) {
                arrayList.add(components[i]);
            }
        }
        return new Path(arrayList);
    }

    private Path() {/* here so we can deserialize */
    }

    public Path(List components) {
        super (components);
    }

    public synchronized String getFirstComponent() {
        if (_containedObjects.size() == 0) {
            return null;
        }
        return (String) _containedObjects.get(0);
    }

    public synchronized Path getSubPath() {
        if (_containedObjects.size() == 0) {
            return null;
        }
        ArrayList subPathComponents = new ArrayList(_containedObjects);

        subPathComponents.remove(0);
        return new Path(subPathComponents);
    }

    public synchronized boolean isEmpty() {
        return (0 == getSize());
    }

    protected boolean containerIsOfSameType(Object object) {
        return (object instanceof Path);
    }

    protected boolean equalObjects(Object firstObject, Object secondObject) {
        String firstString = (String) firstObject;
        String secondString = (String) secondObject;

        return firstString.equals(secondString);
    }

    protected int compareObjects(Object firstObject, Object secondObject) {
        String firstString = (String) firstObject;
        String secondString = (String) secondObject;

        return firstString.compareTo(secondString);
    }
}
