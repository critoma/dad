package com.ora.rmibook.chapter15;


import java.io.*;
import java.util.*;


public abstract class SerializableList implements Serializable {
    protected ArrayList _containedObjects;
    public SerializableList() {/* here so we can deserialize */
    }

    public SerializableList(Collection objects) {
        _containedObjects = new ArrayList(objects.size());
        Iterator i = objects.iterator();

        while (i.hasNext()) {
            _containedObjects.add(i.next());
        }
    }

    public synchronized int getSize() {
        return _containedObjects.size();
    }

    public synchronized Object get(int index) {
        return _containedObjects.get(index);
    }

    public synchronized boolean equals(Object otherObject) {
        if (false == (containerIsOfSameType(otherObject))) {
            return false;
        }
        SerializableList otherComparableList = (SerializableList) otherObject;
        int size = _containedObjects.size();

        if (size != otherComparableList.getSize()) {
            return false;
        }
        for (int i = 0; i < size; i++) {
            if (false == equalObjects(_containedObjects.get(i), otherComparableList.get(i))) {
                return false;
            }
        }
        return true;
    }

    protected abstract boolean containerIsOfSameType(Object object);

    protected abstract boolean equalObjects(Object firstObject, Object secondObject);
}
