package com.ora.rmibook.chapter15.bank;


import com.ora.rmibook.chapter15.bank.valueobjects.*;
import java.rmi.*;


public interface Account extends Remote {
    public Money getBalance(String clientIDNumber)
        throws RemoteException, LockedAccountException;
    public void makeDeposit(String clientIDNumber, Money amount)
        throws RemoteException, NegativeAmountException, LockedAccountException;
    public void makeWithdrawal(String clientIDNumber, Money amount)
        throws RemoteException, OverdraftException, LockedAccountException, NegativeAmountException;
}
