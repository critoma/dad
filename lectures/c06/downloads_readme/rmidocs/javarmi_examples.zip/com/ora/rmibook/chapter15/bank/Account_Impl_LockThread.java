package com.ora.rmibook.chapter15.bank;


import java.util.*;


public class Account_Impl_LockThread extends Thread {
    private static final int THREAD_SLEEP_TIME = 5000;	// 10 seconds
    private static Account_Impl_LockThread _singleton;

    public synchronized static Account_Impl_LockThread getSingleton() {
        if (null == _singleton) {
            _singleton = new Account_Impl_LockThread();
            _singleton.start();
        }
        return _singleton;
    }

    private ArrayList _accounts;

    private Account_Impl_LockThread() {
        _accounts = new ArrayList();
    }

    public synchronized void addAccount(Account newAccount) {
        _accounts.add(newAccount);
    }

    public void run() {
        while (true) {
            try {
                Thread.sleep(THREAD_SLEEP_TIME);
            } catch (Exception ignored) {
            }
            decrementLockTimers();
        }
    }

    private synchronized void decrementLockTimers() {
        Iterator i = _accounts.iterator();

        while (i.hasNext()) {
            Account_Impl nextAccount = (Account_Impl) i.next();

            nextAccount.decrementLockTimer(THREAD_SLEEP_TIME);
        }
    }
}
