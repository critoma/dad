package com.ora.rmibook.chapter15.bank;


public class LockedAccountException extends Exception {
} 
