package com.ora.rmibook.chapter15.bank;


public class NegativeAmountException extends Exception {
} 
