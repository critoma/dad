package com.ora.rmibook.chapter15.bank.applications;


import com.ora.rmibook.chapter15.bank.*;
import com.ora.rmibook.chapter15.bank.valueobjects.*;
import com.ora.rmibook.chapter15.*;
import com.ora.rmibook.chapter15.impl.*;
import java.rmi.*;
import java.rmi.server.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import com.ora.rmibook.gui.*;


public class BankClientFrame extends ExitingFrame {
    private JTextField _accountNameField;
    private JTextField _balanceTextField;
    private JTextField _withdrawalTextField;
    private JTextField _depositTextField;
    private JTextField _contextTextField;
    private Account _account;

    String idNumber = "TestID";

    protected void buildGUI() {
        JPanel contentPane = new JPanel(new BorderLayout());

        contentPane.add(buildMainPanel(), BorderLayout.CENTER);
        setContentPane(contentPane);
        setSize(250, 300);
    }

    private void resetBalanceField() {
        try {
            Money balance = _account.getBalance(idNumber);

            _balanceTextField.setText("Balance: " + balance.toString());
        } catch (Exception e) {
            System.out.println("Error occurred while getting account balance\n" + e);
        }
    }

    private JPanel buildMainPanel() {
        JPanel actionPanel = new JPanel(new GridLayout(7, 2));

        actionPanel.add(new JLabel("Account Name:"));
        _accountNameField = new JTextField();
        actionPanel.add(_accountNameField);

        actionPanel.add(new JLabel("Context Name:"));
        _contextTextField = new JTextField();
        actionPanel.add(_contextTextField);

        actionPanel.add(new JLabel("Withdraw:"));
        _withdrawalTextField = new JTextField();
        actionPanel.add(_withdrawalTextField);

        actionPanel.add(new JLabel("Deposit:"));
        _depositTextField = new JTextField();
        actionPanel.add(_depositTextField);

        actionPanel.add(new JLabel("Balance:"));
        _balanceTextField = new JTextField();
        _balanceTextField.setEnabled(false);
        actionPanel.add(_balanceTextField);

        JButton getBalanceButton = new JButton("Get Balance");

        getBalanceButton.addActionListener(new GetBalanceAction());
        actionPanel.add(getBalanceButton);

        JButton withdrawalButton = new JButton("Make WithDrawal");

        withdrawalButton.addActionListener(new WithdrawAction());
        actionPanel.add(withdrawalButton);

        JButton depositButton = new JButton("Make Deposit");

        depositButton.addActionListener(new DepositAction());
        actionPanel.add(depositButton);

        return actionPanel;
    }

    private void getAccount() {
        try {
            Context baseContext = BaseContextImpl.getStubFromServer("127.0.0.1");
            Path path = Path.buildPath(new String[] {_contextTextField.getText()}
                );

            _account = (Account) baseContext.lookup(path, _accountNameField.getText(), null);
        } catch (Exception e) {
            System.out.println("Couldn't find account. Error was \n " + e);
            e.printStackTrace();
        }
        return;
    }

    private void releaseAccount() {
        _account = null;
    }

    private Money readTextField(JTextField moneyField) {
        try {
            Float floatValue = new Float(moneyField.getText());
            float actualValue = floatValue.floatValue();
            int cents = (int) (actualValue * 100);

            return new PositiveMoney(cents);
        } catch (Exception e) {
            System.out.println("Field doesn't contain a valid value");
        }
        return null;
    }

    private class GetBalanceAction implements ActionListener {
        public void actionPerformed(ActionEvent event) {
            try {
                getAccount();
                resetBalanceField();
                releaseAccount();
            } catch (Exception exception) {
                System.out.println("Couldn't talk to account. Error was \n " + exception);
                exception.printStackTrace();
            }
        }
    }


    private class WithdrawAction implements ActionListener {
        public void actionPerformed(ActionEvent event) {
            try {
                getAccount();
                Money withdrawalAmount = readTextField(_withdrawalTextField);

                _account.makeWithdrawal(idNumber, withdrawalAmount);
                _withdrawalTextField.setText("");
                resetBalanceField();
                releaseAccount();
            } catch (Exception exception) {
                System.out.println("Couldn't talk to account. Error was \n " + exception);
                exception.printStackTrace();
            }
        }
    }


    private class DepositAction implements ActionListener {
        public void actionPerformed(ActionEvent event) {
            try {
                getAccount();
                Money depositAmount = readTextField(_depositTextField);

                _account.makeDeposit(idNumber, depositAmount);
                _depositTextField.setText("");
                resetBalanceField();
                releaseAccount();
            } catch (Exception exception) {
                System.out.println("Couldn't talk to account. Error was \n " + exception);
                exception.printStackTrace();
            }
        }
    }
}
