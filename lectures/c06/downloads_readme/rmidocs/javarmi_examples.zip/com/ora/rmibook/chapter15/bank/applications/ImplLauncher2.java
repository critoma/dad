package com.ora.rmibook.chapter15.bank.applications;


import com.ora.rmibook.chapter15.bank.valueobjects.*;
import com.ora.rmibook.chapter15.bank.*;
import com.ora.rmibook.chapter15.exceptions.*;
import com.ora.rmibook.chapter15.impl.*;
import com.ora.rmibook.chapter15.*;
import java.util.*;
import java.rmi.*;


public class ImplLauncher2 {
    private static Context baseContext;
    public static void main(String[] args) {
        int numberOfServers = (Integer.valueOf(args[0])).intValue();
        NameRepository nameRepository = new NameRepository(numberOfServers);
        Collection accountDescriptions = getAccountDescriptions(nameRepository);
        Iterator i = accountDescriptions.iterator();

        while (i.hasNext()) {
            AccountDescription nextAccountDescription = (AccountDescription) i.next();

            launchServer(nextAccountDescription);
        }
    }

    private static void launchServer(AccountDescription serverDescription) {
        try {
            Account_Impl newAccount = new Account_Impl(serverDescription.balance);

            if (null == baseContext) {
                getContext();
            }
            baseContext.bind(null, serverDescription.name, serverDescription.attributeSet, newAccount);
            System.out.println("Account " + serverDescription.name + " successfully launched.");
        } catch (NamingException e) {
            System.out.println(e.getDescription());
            e.printStackTrace();
        } catch (Exception ee) {
            ee.printStackTrace();
        }
    }

    private static void getContext() {
        try {
            baseContext = BaseContextImpl.getStubFromServer("127.0.0.1");
        } catch (Exception e) {
            System.out.println("Couldn't find base context");
            e.printStackTrace();
        }
    }

    private static Collection getAccountDescriptions(NameRepository nameRepository) {
        ArrayList returnValue = new ArrayList();
        Iterator i = nameRepository.getAllNames();
        boolean checking = false;

        while (i.hasNext()) {
            AccountDescription accountDescription = new AccountDescription();

            accountDescription.name = (String) i.next();
            int cents = (int) (Math.random() * 100000);

            accountDescription.balance = new Money(cents);
            accountDescription.attributeSet = new AttributeSet();;
            if (checking) {
                accountDescription.attributeSet.add("type", "checking");
            } else {
                accountDescription.attributeSet.add("type", "savings");
            }
            checking = !checking;
            returnValue.add(accountDescription);
        }
        return returnValue;
    }

    private static class AccountDescription {
        String name;
        Money balance;
        String contextName;
        AttributeSet attributeSet;
    }
}
