package com.ora.rmibook.chapter15.bank.applications;


import java.util.*;


public class NameRepository {
    private Vector _names; // it's sta
    private int _numberOfNames;

    public NameRepository(int numberOfNames) {
        _numberOfNames = numberOfNames;
        _names = new Vector(_numberOfNames);
        for (int counter = 0; counter < _numberOfNames; counter++) {
            _names.add("Customer number " + counter);
        }
    }

    public Iterator getAllNames() {
        synchronized (_names) {
            return _names.iterator();
        }
    }

    public String getAName() {
        int index = (int) (Math.random() * _numberOfNames);

        return (String) _names.get(index);
    }
} 

