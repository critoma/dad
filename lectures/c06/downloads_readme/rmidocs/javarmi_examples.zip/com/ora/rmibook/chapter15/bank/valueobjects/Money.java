package com.ora.rmibook.chapter15.bank.valueobjects;


import java.io.*;


public class Money extends ValueObject {
    protected int _cents;

    public Money(Integer cents) {
        this (cents.intValue());
    }

    public Money(int cents) {
        super (cents + " cents.");
        _cents = cents;
    }

    public int getCents() {
        return _cents;
    }

    public Money add(Money otherMoney) {
        return new Money(_cents + otherMoney.getCents());
    }

    public Money subtract(Money otherMoney) {
        return new Money(_cents - otherMoney.getCents());
    }

    public boolean greaterThan(Money otherMoney) {
        if (_cents > otherMoney.getCents()) {
            return true;
        }
        return false;
    }

    public boolean isNegative() {
        return _cents < 0;
    }

    public boolean equals(Object object) {
        if (object instanceof Money) {
            Money otherMoney = (Money) object;

            return (_cents == otherMoney.getCents());
        }
        return false;
    }
}
