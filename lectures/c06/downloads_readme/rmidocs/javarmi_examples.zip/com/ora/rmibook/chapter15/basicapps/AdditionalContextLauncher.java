package com.ora.rmibook.chapter15.basicapps;


import com.ora.rmibook.chapter15.impl.*;
import com.ora.rmibook.chapter15.exceptions.*;
import com.ora.rmibook.chapter15.*;
import java.util.*;


/*
 Connects to the default context and
 adds some new ones in.

 arguments are of the form

 x/y/z

 the z is the name, x and y are contexts along the way.
 */

public class AdditionalContextLauncher {
    public static void main(String[] args) {
        for (int i = 0; i < args.length; i++) {
            launchContext(args[0], args[i]);
        }
    }

    private static void launchContext(String baseContextMachine, String pathPlusName) {
        StringTokenizer tokenizer = new StringTokenizer(pathPlusName, "/", false);
        int numberOfPathTokens = tokenizer.countTokens() - 1;
        Path path = null;

        if (0 != numberOfPathTokens) {
            String[] pathComponents = new String[numberOfPathTokens];

            for (int counter = 0; counter < numberOfPathTokens; counter++) {
                pathComponents[counter] = tokenizer.nextToken();
            }
            path = Path.buildPath(pathComponents);
        }
        String name = tokenizer.nextToken();

        try {
            ContextImpl newContext = new ContextImpl();
            Context startingContext = BaseContextImpl.getStubFromServer(baseContextMachine);

            startingContext.bindSubContext(path, name, newContext);
        } catch (NamingException e) {
            System.out.println("Failed to launched context " + pathPlusName);
            System.out.println(e.getDescription());
            e.printStackTrace();
        } catch (Exception ee) {
            ee.printStackTrace();
        }
    }
}
