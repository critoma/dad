package com.ora.rmibook.chapter15.basicapps;


public class NamingServiceExplorer {
    public static void main(String[] args) {
        (new NamingServiceExplorerFrame()).show();
    }
}
