package com.ora.rmibook.chapter15.basicapps;


import com.ora.rmibook.chapter15.exceptions.*;
import com.ora.rmibook.chapter15.impl.*;
import com.ora.rmibook.chapter15.*;
import java.util.*;
import java.rmi.*;
import javax.swing.*;
import java.awt.event.*;
import java.awt.*;


public class NamingServiceExplorerFrame extends JFrame {
    private JTextArea _resultsArea;
    private JTextField _pathField;
    private JTextField _attributeNameField;
    private JTextField _attributeValueField;
    private JButton _queryNamingServiceButton;
    public NamingServiceExplorerFrame() {
        buildGUI();
        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        addWindowListener(new ExitOnClose());
    }

    private void buildGUI() {
        JPanel mainPanel = new JPanel(new BorderLayout());

        _resultsArea = new JTextArea();
        mainPanel.add(new JScrollPane(_resultsArea), BorderLayout.CENTER);
        _queryNamingServiceButton = new JButton("Check Naming Service Contents");
        _queryNamingServiceButton.addActionListener(new QueryRegistry());
        _pathField = new JTextField();
        _attributeNameField = new JTextField();
        _attributeValueField = new JTextField();
        JPanel bottomPanel = new JPanel(new GridLayout(4, 2));

        bottomPanel.add(new JLabel("Attribute Name"));
        bottomPanel.add(_attributeNameField);
        bottomPanel.add(new JLabel("AttributeValue"));
        bottomPanel.add(_attributeValueField);
        bottomPanel.add(new JLabel("Context"));
        bottomPanel.add(_pathField);
        bottomPanel.add(_queryNamingServiceButton);
        mainPanel.add(bottomPanel, BorderLayout.SOUTH);
        getContentPane().add(mainPanel);
        setSize(250, 200);
    }

    private void displayInformationForRemote(Remote remoteObject) throws Exception {
        if (null == remoteObject) {
            return;
        }
        Collection interfaces = getRemoteInterfacesForObject(remoteObject);

        if (null == interfaces) {
            return;
        }
        _resultsArea.append("Server implements the following remote interfaces\n");
        Iterator i = interfaces.iterator();

        while (i.hasNext()) {
            _resultsArea.append("\t" + i.next() + "\n");
        }
        return;
    }
    
    private Collection getRemoteInterfacesForObject(Object object) {
        Class objectType = object.getClass();
        Class[] interfaces = objectType.getInterfaces();
        Class remoteInterface = Remote.class;

        if ((null == interfaces) || (0 == interfaces.length)) {
            return null;
        }
        ArrayList returnValue = new ArrayList();
        int counter;

        for (counter = 0; counter < interfaces.length; counter++) {
            if (remoteInterface.isAssignableFrom(interfaces[counter])) {
                returnValue.add(interfaces[counter]);
            }
        }
        return returnValue;
    }

    private class QueryRegistry implements ActionListener {
        public void actionPerformed(ActionEvent event) {
            try {
                Context baseContext = BaseContextImpl.getStubFromServer("127.0.0.1");
                Remote[] remotebjects = baseContext.list(getPath(), null, getAttribute());

                if ((null == remotebjects) || (0 == remotebjects.length)) {
                    _resultsArea.setText("The Naming Service is Empty");
                    return;
                }
                _resultsArea.setText("");
                int counter;

                for (counter = 0; counter < remotebjects.length; counter++) {
                    displayInformationForRemote(remotebjects[counter]);
                }
            } catch (NamingException namingException) {
                System.out.println(namingException.getDescription());
                namingException.printStackTrace();
            } catch (Exception exception) {
                exception.printStackTrace();
            }
        }

        private Path getPath() {
            String pathPlusName = _pathField.getText();

            if ((null == pathPlusName) || (0 == pathPlusName.length())) {
                return null;
            }
            StringTokenizer tokenizer = new StringTokenizer(pathPlusName, "/", false);
            int numberOfPathTokens = tokenizer.countTokens();

            if (numberOfPathTokens == 0) {
                return null;
            }
            String[] pathComponents = new String[numberOfPathTokens];

            for (int counter = 0; counter < numberOfPathTokens; counter++) {
                pathComponents[counter] = tokenizer.nextToken();
            }
            return Path.buildPath(pathComponents);
        }

        private AttributeSet getAttribute() {
            String name = _attributeNameField.getText();

            if ((null == name) || (0 == name.length())) {
                return null;
            }
            String value = _attributeValueField.getText();

            if ((null == value) || (0 == value.length())) {
                return null;
            }
            AttributeSet returnValue = new AttributeSet();

            returnValue.add(name, value);
            return returnValue;
        }
    }


    private class ExitOnClose extends WindowAdapter {
        public void windowClosed(WindowEvent event) {
            System.exit(0);
        }
    }
} 

