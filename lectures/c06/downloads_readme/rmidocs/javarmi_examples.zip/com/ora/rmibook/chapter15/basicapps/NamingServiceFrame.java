package com.ora.rmibook.chapter15.basicapps;


import com.ora.rmibook.chapter15.impl.*;
import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.rmi.*;


public class NamingServiceFrame extends JFrame {
    public NamingServiceFrame() {
        buildGUI();
        startBaseContext();
        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        addWindowListener(new ExitOnClose());
    }

    private void startBaseContext() {
        try {
            BaseContextImpl baseContext = new BaseContextImpl();

            baseContext.vendStubViaSocket();
        } catch (RemoteException e) {
            System.out.println("Couldn't Create Base Context.");
            System.out.println("Error was " + e);
            e.printStackTrace();
        }
    }
    
    private void buildGUI() {
        JPanel mainPanel = new JPanel(new BorderLayout());
        JTextArea messageArea = new JTextArea("Close this window to shut down the naming service");

        mainPanel.add(messageArea, BorderLayout.CENTER);
        getContentPane().add(mainPanel);
        setSize(250, 100);
    }
    private class ExitOnClose extends WindowAdapter {
        public void windowClosed(WindowEvent event) {
            System.exit(0);
        }
    }
} 

