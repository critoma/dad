package com.ora.rmibook.chapter15.exceptions;


public class BindingException extends NamingException {
    public BindingException(String description) {
        super (description);
    }
}
