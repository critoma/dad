package com.ora.rmibook.chapter15.exceptions;


public class InvalidNameException extends NamingException {
    public InvalidNameException(String description) {
        super (description);
    }

    public InvalidNameException() {
        super ("Name isn't valid");
    }
}
