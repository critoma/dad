package com.ora.rmibook.chapter15.exceptions;


public class InvalidPathException extends NamingException {
    public InvalidPathException(String description) {
        super (description);
    }

    public InvalidPathException() {
        super ("Path doesn't exist");
    }
}
