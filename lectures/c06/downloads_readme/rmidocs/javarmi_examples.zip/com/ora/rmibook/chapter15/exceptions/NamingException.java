package com.ora.rmibook.chapter15.exceptions;


public class NamingException extends Exception {
    private String _description;
    public NamingException(String description) {
        _description = description;
    }

    public String getDescription() {
        return _description;
    }
} 

