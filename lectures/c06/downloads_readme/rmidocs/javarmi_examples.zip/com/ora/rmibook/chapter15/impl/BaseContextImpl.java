package com.ora.rmibook.chapter15.impl;


import com.ora.rmibook.chapter15.exceptions.*;
import com.ora.rmibook.chapter15.*;

import java.rmi.server.*;
import java.rmi.*;
import java.io.*;
import java.util.*;
import java.net.*;


// "implements Context" needed in order to generate a stub

public class BaseContextImpl extends ContextImpl implements Context {
    // 	Two constructors and a pair of static bootstrap method

    public static final int BOOTSTRAP_PORT_NUMBER = 1066;
    public static final int DEFAULT_PORT_NUMBER = 1967;

    public static Context getStubFromServer(String serverName) {
        return getStubFromServer(serverName, BOOTSTRAP_PORT_NUMBER);
    }

    public static Context getStubFromServer(String serverName, int portNumber) {
        Context returnValue = null;

        try {
            Socket socket = new Socket(serverName, portNumber);
            ObjectInputStream objectInputStream = new ObjectInputStream(socket.getInputStream());

            returnValue = (Context) objectInputStream.readObject();
        } catch (Exception e) {
            System.out.println("Stub note available");
            e.printStackTrace();
        }
        return returnValue;
    }

    public BaseContextImpl(int port) throws RemoteException {
        super (port);
    }

    public BaseContextImpl() throws RemoteException {
        this (DEFAULT_PORT_NUMBER);
    }

    public void vendStubViaSocket() {
        vendStubViaSocket(BOOTSTRAP_PORT_NUMBER);
    }

    public void vendStubViaSocket(int portNumber) {
        StubSender stubSender = new StubSender(this);
        Thread stubSenderThread = new Thread(stubSender);

        stubSenderThread.setName("Stub sender thread");
        stubSenderThread.start();
        StubSocketListener socketListener = new StubSocketListener(portNumber, stubSender);
        Thread socketListenerThread = new Thread(socketListener);

        socketListenerThread.setName("Socket Listener thread");
        socketListenerThread.start();
    }
}
