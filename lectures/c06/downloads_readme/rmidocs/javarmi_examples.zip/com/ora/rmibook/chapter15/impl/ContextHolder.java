package com.ora.rmibook.chapter15.impl;


import com.ora.rmibook.chapter15.exceptions.*;
import com.ora.rmibook.chapter15.*;
import java.rmi.*;
import java.util.*;


/*
 Basically a wrapper around a Hashmap and an Arraylist.
 One bit of special casing-- a null argument returns the owner;
 
 Note that this object is highly synchronized.
 */

public class ContextHolder {
    private HashMap _namesToContexts;
 
    public ContextHolder() {
        _namesToContexts = new HashMap();
    }

    public synchronized void bind(String name, Context context) throws BindingException {
        if ((null == name) || (null == context)) {
            return;
        }
        Object priorValue = _namesToContexts.get(name);

        if (null != priorValue) {
            throw new BindingException("Attempt to bind context to an already bound name.");
        }
        _namesToContexts.put(name, context);
        return;
    }
    
    public synchronized void rebind(String name, Context context) {
        if (null == name) {
            return;
        }
        if (null == context) {
            _namesToContexts.remove(name);
            return;
        }
        _namesToContexts.put(name, context);
        return;
    }

    public synchronized void unbind(String name) {
        if (null == name) {
            return;
        }
        _namesToContexts.remove(name);
        return;
    }

    public synchronized Context lookup(String name) {
        if (null == name) {
            return null;
        }
        return (Context) _namesToContexts.get(name);
    }

    public synchronized ContextList list() {
        return new ContextList(_namesToContexts.values());
    }
}
