package com.ora.rmibook.chapter15.impl;


import com.ora.rmibook.chapter15.exceptions.*;
import com.ora.rmibook.chapter15.*;
import java.rmi.*;
import java.rmi.server.*;
import java.util.*;


/*
 The basic implementation of Context.
 */

public class ContextImpl extends UnicastRemoteObject implements Context {
    private RemoteHolder _remoteHolder;
    private ContextHolder _contextHolder;

    private ContextHolder _subContextHolder; {
        _remoteHolder = new RemoteHolder();
        _contextHolder = new ContextHolder();
    }

    public ContextImpl(int portNumber) throws RemoteException {
        super (portNumber);
    }

    public ContextImpl() throws RemoteException {
        super ();
    }

    // Basic binding functionality

    public void bind(Path path, String name, AttributeSet attributes, Remote server)
        throws RemoteException, NamingException {
        checkNameForBindingOperation(name);
        if ((null == path) || (path.isEmpty())) {
            _remoteHolder.bind(name, attributes, server);
        } else {
            String firstPathComponent = path.getFirstComponent();
            Context subContext = _contextHolder.lookup(firstPathComponent);

            if (null == subContext) {
                throw new InvalidPathException("The specified path in the naming hierarchy does not exist. In particular "
                        + firstPathComponent + " is not a valid context name.");
            }
            subContext.bind(path.getSubPath(), name, attributes, server);
        }
    }

    public void rebind(Path path, String name, AttributeSet attributes, Remote server)
        throws RemoteException, NamingException {
        checkNameForBindingOperation(name);
        if ((null == path) || (path.isEmpty())) {
            _remoteHolder.rebind(name, attributes, server);
        } else {
            String firstPathComponent = path.getFirstComponent();
            Context subContext = _contextHolder.lookup(firstPathComponent);

            if (null == subContext) {
                throw new InvalidPathException("The specified path in the naming hierarchy does not exist. In particular "
                        + firstPathComponent + " is not a valid context name.");
            }
            subContext.rebind(path.getSubPath(), name, attributes, server);
        }
    }

    public void unbind(Path path, String name, AttributeSet attributes)
        throws RemoteException, NamingException {
        checkNameForBindingOperation(name);
        if ((null == path) || (path.isEmpty())) {
            _remoteHolder.unbind(name, attributes);
        } else {
            String firstPathComponent = path.getFirstComponent();
            Context subContext = _contextHolder.lookup(firstPathComponent);

            if (null == subContext) {
                throw new InvalidPathException("The specified path in the naming hierarchy does not exist. In particular "
                        + firstPathComponent + " is not a valid context name.");
            }
            subContext.unbind(path.getSubPath(), name, attributes);
        }
    }

    // Basic querying functionality

    public Remote lookup(Path path, String name, AttributeSet attributes) throws RemoteException, NamingException {
        if ((null == path) || (path.isEmpty())) {
            return _remoteHolder.lookup(name, attributes);
        }
        String firstPathComponent = path.getFirstComponent();
        Context subContext = _contextHolder.lookup(firstPathComponent);

        if (null == subContext) {
            throw new InvalidPathException("The specified path in the naming hierarchy does not exist. In particular "
                    + name + " is not a valid context name.");
        }
        return subContext.lookup(path.getSubPath(), name, attributes);
    }
    
    public Remote[] list() throws RemoteException, NamingException {
        return _remoteHolder.list();
    }

    public Remote[] list(AttributeSet attributes) throws RemoteException, NamingException {
        return _remoteHolder.list(attributes);
    }

    public Remote[] list(String name, AttributeSet attributes) throws RemoteException, NamingException {
        return _remoteHolder.list(name, attributes);
    }
    
    public Remote[] list(Path path, String name, AttributeSet attributes) throws RemoteException, NamingException {
        if ((null == path) || (path.isEmpty())) {
            return _remoteHolder.list(name, attributes);
        }
        String firstPathComponent = path.getFirstComponent();
        Context subContext = _contextHolder.lookup(firstPathComponent);

        if (null == subContext) {
            throw new InvalidPathException("The specified path in the naming hierarchy does not exist. In particular "
                    + name + " is not a valid context name.");
        }
        return subContext.list(path.getSubPath(), name, attributes);
    }

    // Context-level API

    public Context lookupSubContext(Path path, String name) throws RemoteException, NamingException {
        if ((null == path) || (path.isEmpty())) {
            return _contextHolder.lookup(name);
        }
        String firstPathComponent = path.getFirstComponent();
        Context subContext = _contextHolder.lookup(firstPathComponent);

        return subContext.lookupSubContext(path.getSubPath(), name);
    }

    public ContextList listSubContexts() throws RemoteException, NamingException {
        return _contextHolder.list();
    }

    public ContextList listSubContexts(Path path) throws RemoteException, NamingException {
        if ((null == path) || (path.isEmpty())) {
            return _contextHolder.list();
        }
        String name = path.getFirstComponent();
        Context subContext = _contextHolder.lookup(name);

        if (null == subContext) {
            throw new InvalidPathException("The specified path in the naming hierarchy does not exist. In particular "
                    + name + " is not a valid context name.");
        }
        return subContext.listSubContexts(path.getSubPath());
    }

    public Context createSubContext(Path path, String name) throws RemoteException, NamingException {
        checkNameForBindingOperation(name);
        Context newSubContext = new ContextImpl();

        bindSubContext(path, name, newSubContext);
        return newSubContext;
    }

    public void bindSubContext(Path path, String name, Context context) throws RemoteException, NamingException {
        checkNameForBindingOperation(name);
        if ((null == path) || (path.isEmpty())) {
            _contextHolder.bind(name, context);
            return;
        }
        String firstPathComponent = path.getFirstComponent();
        Context subContext = _contextHolder.lookup(firstPathComponent);

        if (null == subContext) {
            throw new InvalidPathException("The specified path in the naming hierarchy does not exist. In particular "
                    + name + " is not a valid context name.");
        }
        subContext.bindSubContext(path.getSubPath(), name, context);
        return;
    }

    public void rebindSubContext(Path path, String name, Context context) throws RemoteException, NamingException {
        checkNameForBindingOperation(name);
        if ((null == path) || (path.isEmpty())) {
            _contextHolder.rebind(name, context);
            return;
        }
        String firstPathComponent = path.getFirstComponent();
        Context subContext = _contextHolder.lookup(firstPathComponent);

        if (null == subContext) {
            throw new InvalidPathException("The specified path in the naming hierarchy does not exist. In particular "
                    + name + " is not a valid context name.");
        }
        subContext.rebindSubContext(path.getSubPath(), name, context);
        return;
    }

    public void unbindSubContext(Path path, String name) throws RemoteException, NamingException {
        checkNameForBindingOperation(name);
        if ((null == path) || (path.isEmpty())) {
            _contextHolder.unbind(name);
            return;
        }
        String firstPathComponent = path.getFirstComponent();
        Context subContext = _contextHolder.lookup(firstPathComponent);

        if (null == subContext) {
            throw new InvalidPathException("The specified path in the naming hierarchy does not exist. In particular "
                    + name + " is not a valid context name.");
        }
        subContext.unbindSubContext(path.getSubPath(), name);
        return;
    }

    private void checkNameForBindingOperation(String name) throws InvalidNameException {
        if ((null == name) || (name.equals(""))) {
            throw new InvalidNameException("Name cannot be null");
        }
    }
}
