/*
 What's an NameAttributeSetPair ?
 It's three things:
 A name.
 A set of attributes.
 A stub to a remote object.

 It can be compared to other entries and it is used to hold
 spots in our naming service.
 */

package com.ora.rmibook.chapter15.impl;


import com.ora.rmibook.chapter15.*;
import java.rmi.*;
import java.util.*;


public class NameAttributeSetPair implements Comparable {
    private String _name;
    private AttributeSet _attributes;

    public NameAttributeSetPair(String name, AttributeSet attributes) {
        _name = name;
        _attributes = attributes;
    }

    protected String getName() {
        return _name;
    }

    protected AttributeSet getAttributes() {
        return _attributes;
    }

    public boolean matchesQueryObject(NameAttributeSetPair query) {
        String otherName = query.getName();

        if ((null != otherName) && (false == otherName.equals(_name))) {
            return false;
        }
        AttributeSet otherAttributes = query.getAttributes();

        if (null != otherAttributes) {
            return otherAttributes.subsetOf(_attributes);
        }
        return true;
    }

    public boolean equals(Object object) {
        if (false == (object instanceof NameAttributeSetPair)) {
            return false;
        }
        NameAttributeSetPair otherNameAttributePair = (NameAttributeSetPair) object;

        if (0 != compareTo(otherNameAttributePair.getName())) {
            return false;
        }
        AttributeSet otherAttributes = otherNameAttributePair.getAttributes();

        return (0 == compare(_attributes, otherAttributes));
    }

    public int compareTo(Object object) {
        NameAttributeSetPair otherNameAttributePair = (NameAttributeSetPair) object;
        int returnValue;

        returnValue = compare(_name, otherNameAttributePair.getName());
        if (0 != returnValue) {
            return returnValue;
        }
        return compare(_attributes, otherNameAttributePair.getAttributes());
    }

    private int compare(Comparable comparable1, Comparable comparable2) {
        if (null == comparable1) {
            if (null == comparable2) {
                return 0;
            }
            return -1; // null is less than non-null
        }
        if (null == comparable2) {
            return 1;
        }
        return comparable1.compareTo(comparable2);
    }
}
