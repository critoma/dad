package com.ora.rmibook.chapter15.impl;


import com.ora.rmibook.chapter15.exceptions.*;
import com.ora.rmibook.chapter15.*;
import java.rmi.*;
import java.util.*;


/*
 A very concrete class that stores (and indexes) the local
 information.

 Note that this object is highly synchronized.
 */

public class RemoteHolder {
    private TreeMap _ourTree;
    public RemoteHolder() {
        _ourTree = new TreeMap();
    }

    protected synchronized void bind(String name, AttributeSet attributes, Remote server) throws BindingException {
        NameAttributeSetPair nameAttributePair = new NameAttributeSetPair (name, attributes);
        Object alreadyBoundObject = _ourTree.get(nameAttributePair);

        if (null != alreadyBoundObject) {
            throw new BindingException("Object already bound to " + name);
        }
        _ourTree.put(nameAttributePair, server);
    }

    protected synchronized void rebind(String name, AttributeSet attributes, Remote server) throws BindingException {
        NameAttributeSetPair nameAttributePair = new NameAttributeSetPair (name, attributes);

        _ourTree.remove(nameAttributePair);
        _ourTree.put(nameAttributePair, server);
    }

    protected synchronized void unbind(String name, AttributeSet attributes) {
        NameAttributeSetPair nameAttributePair = new NameAttributeSetPair (name, attributes);

        _ourTree.remove(nameAttributePair);
    }

    protected synchronized Remote lookup(String name, AttributeSet attributes) throws NamingException {
        NameAttributeSetPair nameAttributePair = new NameAttributeSetPair (name, attributes);

        return (Remote) _ourTree.get(nameAttributePair);
    }

    /*
     The list methods are a little expensive.
     C'est la vie. 
     */
    protected synchronized Remote[] list() throws RemoteException, NamingException {
        return convertCollectionToRemoteArray(_ourTree.values());
    }

    protected synchronized Remote[] list(AttributeSet attributes) throws RemoteException, NamingException {
        return list(null, attributes);
    }

    protected synchronized Remote[] list(String name, AttributeSet attributes) throws RemoteException, NamingException {
        NameAttributeSetPair queryObject = new NameAttributeSetPair (name, attributes);
        ArrayList returnValues = new ArrayList();
        Iterator i = _ourTree.keySet().iterator();

        while (i.hasNext()) {
            NameAttributeSetPair next = (NameAttributeSetPair) i.next();

            if (next.matchesQueryObject(queryObject)) {
                returnValues.add(_ourTree.get(next));
            }
        }
        return convertCollectionToRemoteArray(returnValues);
    }

    private Remote[] convertCollectionToRemoteArray(Collection remotes) {
        Iterator iterator = remotes.iterator();
        Remote[] returnValue = new Remote[remotes.size()];
        int counter = 0;

        while (iterator.hasNext()) {
            returnValue[counter] = (Remote) iterator.next();;
            counter++;
        }
        return returnValue;
    }
}
