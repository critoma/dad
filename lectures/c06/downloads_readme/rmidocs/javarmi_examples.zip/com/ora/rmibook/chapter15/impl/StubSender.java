package com.ora.rmibook.chapter15.impl;


import java.util.*;
import java.net.*;
import java.io.*;
import java.rmi.*;
import java.rmi.server.*;


public class StubSender implements Runnable {
    private ArrayList _customers = new ArrayList();
    private BaseContextImpl _server;
    public StubSender(BaseContextImpl server) {
        _server = server;
    }

    public void run() {
        while (true) {
            sendStub();
        }
    }

    public synchronized void add(Socket socket) {
        _customers.add(socket);
        notifyAll();
    }

    private synchronized Socket getNextSocket() {
        int size = _customers.size();

        if (0 == size) {
            return null;
        }
        size--;
        Socket returnValue = (Socket) _customers.remove(size);

        return returnValue;
    }

    public void sendStub() {
        Socket nextSocket = getNextSocket();

        if (null == nextSocket) {
            waitForSocket();
            return;
        } else {
            try {
                RemoteStub stub = (RemoteStub) RemoteStub.toStub(_server);
                OutputStream output = nextSocket.getOutputStream();
                ObjectOutputStream objectOutputStream = new ObjectOutputStream(output);

                objectOutputStream.writeObject(stub);
                objectOutputStream.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private synchronized void waitForSocket() {
        if (0 == _customers.size()) {
            try {
                wait();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }
}
