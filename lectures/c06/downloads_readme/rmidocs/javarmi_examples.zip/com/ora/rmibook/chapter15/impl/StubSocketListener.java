package com.ora.rmibook.chapter15.impl;


import java.io.*;
import java.net.*;


public class StubSocketListener implements Runnable {
    private int _port;
    private StubSender _sender;
    public StubSocketListener(int portNumber, StubSender sender) {
        _port = portNumber;
        _sender = sender;
    }

    public void run() {
        ServerSocket serverSocket;

        try {
            serverSocket = new ServerSocket(_port);
        } catch (Exception e) {
            System.out.println("Unable to vend on port " + _port);
            return;
        }
        while (true) {
            try {
                Socket socket = serverSocket.accept();

                _sender.add(socket);
            } catch (Exception ee) {
                ee.printStackTrace();
            }
        }
    }
}
