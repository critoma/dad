package com.ora.rmibook.chapter15.jndiaccounts;


public class NegativeAmountException extends Exception {
} 
