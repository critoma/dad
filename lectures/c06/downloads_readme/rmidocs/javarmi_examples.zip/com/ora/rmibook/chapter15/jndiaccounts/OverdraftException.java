package com.ora.rmibook.chapter15.jndiaccounts;


public class OverdraftException extends Exception {
    public boolean _withdrawalSucceeded;
    public OverdraftException(boolean withdrawalSucceeded) {
        _withdrawalSucceeded = withdrawalSucceeded;
    }

    public boolean isWithdrawalSucceeded() {
        return _withdrawalSucceeded;
    }
}
