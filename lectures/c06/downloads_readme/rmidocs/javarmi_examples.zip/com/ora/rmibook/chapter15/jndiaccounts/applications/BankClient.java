package com.ora.rmibook.chapter15.jndiaccounts.applications;


public class BankClient {
    public static void main(String[] args) {
        (new BankClientFrame()).show();
    }
}
