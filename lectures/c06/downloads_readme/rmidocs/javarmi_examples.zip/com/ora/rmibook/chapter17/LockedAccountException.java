package com.ora.rmibook.chapter17;


public class LockedAccountException extends Exception {
} 
