package com.ora.rmibook.chapter17;


public class LockingAccount_Impl {
    public LockingAccount_Impl() {
    }
} 

