package com.ora.rmibook.chapter17.activation;


public class NegativeAmountException extends Exception {
} 
