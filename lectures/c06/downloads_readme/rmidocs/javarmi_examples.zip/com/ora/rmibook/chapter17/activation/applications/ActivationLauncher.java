package com.ora.rmibook.chapter17.activation.applications;


import com.ora.rmibook.chapter17.activation.*;
import com.ora.rmibook.chapter17.activation.valueobjects.*;
import java.util.*;
import java.io.*;
import java.rmi.*;
import java.rmi.server.*;
import java.rmi.activation.*;


public class ActivationLauncher {
    public static void main(String[] args) {
        try {
            ActivationGroup activationGroup = createActivationGroup();
        } catch (Exception e) {
            System.out.println("Utter Failure.");
            e.printStackTrace();
            System.exit(0);
        }
        createBankAccounts();
        System.exit(0);
    }

    private static void createBankAccounts() {
        createBankAccount("Bob", getRandomMoney());
        createBankAccount("Tom", getRandomMoney());
        createBankAccount("Hans", getRandomMoney());
        createBankAccount("Bill", getRandomMoney());
        createBankAccount("Yolanda", getRandomMoney());
        createBankAccount("Dave", getRandomMoney());
    }

    private static Money getRandomMoney() {
        int cents = (int) (Math.random() * 100000);

        return new Money(cents);
    }

    private static void createBankAccount(String owner, Money money) {
        try {
            ActivationDesc aD = createActivationDesc(owner, money);
            Account account = (Account) Account_Impl.register(aD);

            Naming.rebind(owner, account);
        } catch (Exception e) {
            System.out.println("Failed to create account for " + owner);
            e.printStackTrace();
        }
    }

    private static ActivationGroup createActivationGroup()
        throws ActivationException, RemoteException {
        Properties pList = new Properties();

        pList.put("java.security.policy", "d:\\java.policy");
        ActivationGroupDesc.CommandEnvironment configInfo = null;
        ActivationGroupDesc description = new ActivationGroupDesc(pList, configInfo);
        ActivationGroupID id = (ActivationGroup.getSystem()).registerGroup(description);

        return ActivationGroup.createGroup(id, description, 0);
    }

    private static ActivationDesc createActivationDesc(String owner, Money moneyToStart)
        throws ActivationException, RemoteException, IOException {
        return new ActivationDesc("com.ora.rmibook.chapter17.activation.Account_Impl", "file:/D:/Classes/",
                new MarshalledObject(moneyToStart));
    }
}

