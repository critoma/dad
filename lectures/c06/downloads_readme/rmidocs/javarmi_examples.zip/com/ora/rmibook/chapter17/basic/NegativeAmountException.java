package com.ora.rmibook.chapter17.basic;


public class NegativeAmountException extends Exception {
} 
