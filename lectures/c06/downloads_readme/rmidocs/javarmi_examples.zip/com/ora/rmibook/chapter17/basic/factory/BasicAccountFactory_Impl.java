package com.ora.rmibook.chapter17.basic.factory;


import com.ora.rmibook.chapter17.basic.valueobjects.*;
import com.ora.rmibook.chapter17.basic.*;
import java.rmi.server.*;
import java.rmi.*;
import java.util.*;


public class BasicAccountFactory_Impl extends BasicFactory_Impl {
    public BasicAccountFactory_Impl() throws RemoteException {
    }

    protected HashMap createServers() {
        HashMap returnValue = new HashMap();

        returnValue.put("Bob", getAccount("Bob", 10000));
        returnValue.put("Alex", getAccount("Alex", 8400));
        returnValue.put("Trish", getAccount("Trish", 18700));
        returnValue.put("Pat", getAccount("Pat", 122100));
        returnValue.put("David", getAccount("David", 3100));
        returnValue.put("Mary", getAccount("Mary", 95200));
        return returnValue;
    }

    private Account getAccount(String name, int cents) {
        try {
            return new Account_Impl(new Money(cents));
        } catch (Exception e) {
            System.out.println(e);
        }
        return null;
    }
} 

