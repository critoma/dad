package com.ora.rmibook.chapter17.basic.factory;


import com.ora.rmibook.chapter17.basic.valueobjects.*;
import com.ora.rmibook.chapter17.basic.*;
import java.rmi.*;


public interface BasicFactory extends Remote {
    public Remote getAccount(String accountName) throws RemoteException;
    public void doneWithAccount(String accountName) throws RemoteException;
}
