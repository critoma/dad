package com.ora.rmibook.chapter17.basic.factory;


import com.ora.rmibook.chapter17.basic.valueobjects.*;
import com.ora.rmibook.chapter17.basic.*;
import java.rmi.server.*;
import java.rmi.*;
import java.util.*;


public abstract class BasicFactory_Impl extends UnicastRemoteObject implements BasicFactory {
    protected abstract HashMap createServers();

    private HashMap _namesToServers;
    private HashMap _serversToSupport;
    private Integer _one = new Integer(1);
    
    public BasicFactory_Impl() throws RemoteException {
        _namesToServers = createServers();
        _serversToSupport = new HashMap();
    }

    public Remote getAccount(String accountName) throws RemoteException {
        Remote server = (Remote) _namesToServers.get(accountName);

        if (null == server) {
            return null;
        }
        Integer support = (Integer) _serversToSupport.get(server);

        if (null == support) {
            try {
                RemoteStub stub = (RemoteStub) UnicastRemoteObject.exportObject(server);

                System.out.println("Server " + accountName + " successfully exported.");
                support = _one;
            } catch (Exception e) {
                System.out.println(e);
                return null;
            }
        } else {
            support = new Integer(support.intValue() + 1);
        }
        _serversToSupport.put(server, support);
        return server;
    }

    public void doneWithAccount(String accountName) throws RemoteException {
        Remote server = (Account) _namesToServers.get(accountName);

        if (null == server) {
            return;
        }
        Integer support = (Integer) _serversToSupport.get(server);

        if (null == support) {
            System.out.println("Attempt to unexport non-supported account");
            return;
        }
        int newSupportValue = support.intValue() - 1;

        if (newSupportValue > 0) {
            _serversToSupport.put(server, new Integer(newSupportValue));
            return;
        }
        try {
            UnicastRemoteObject.unexportObject(server, true);
            _serversToSupport.remove(server);
            System.out.println("Server " + accountName + " successfully unexported.");
        } catch (Exception e) {
            System.out.println(e);
        }
    }

}
