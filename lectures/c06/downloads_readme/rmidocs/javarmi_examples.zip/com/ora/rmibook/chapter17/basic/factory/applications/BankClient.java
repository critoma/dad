package com.ora.rmibook.chapter17.basic.factory.applications;


import com.ora.rmibook.chapter17.basic.*;
import java.rmi.*;
import java.rmi.server.*;


public class BankClient {
    public static void main(String[] args) {
        (new BankClientFrame()).show();
    }
}
