package com.ora.rmibook.chapter17.basic.factory.applications;


import com.ora.rmibook.chapter17.basic.factory.*;
import com.ora.rmibook.chapter17.basic.*;
import com.ora.rmibook.chapter17.basic.valueobjects.*;
import java.util.*;
import java.rmi.*;
import java.rmi.server.*;


public class BasicFactoryLauncher implements Constants {
    public static void main(String[] args) {
        try {
            BasicAccountFactory_Impl factory = new BasicAccountFactory_Impl();

            Naming.rebind(ACCOUNT_FACTORY_NAME, factory);
            System.out.println("Factory successfully launched.");
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}
