package com.ora.rmibook.chapter17.basic.factory.applications;


public interface Constants {
    public static final String ACCOUNT_FACTORY_NAME = "Account Factory";
}
