package com.ora.rmibook.chapter17.better;


import com.ora.rmibook.chapter17.better.valueobjects.*;
import java.rmi.*;


public interface Account extends Remote {
    public Money getBalance() throws RemoteException;
    public void makeDeposit(Money amount) throws RemoteException, NegativeAmountException;
    public void makeWithdrawal(Money amount)
        throws RemoteException, OverdraftException, NegativeAmountException;
    public void setFactory(LockingFactory factory) throws RemoteException;
}
