package com.ora.rmibook.chapter17.better;


import com.ora.rmibook.chapter17.better.valueobjects.*;
import java.rmi.*;
import java.rmi.server.*;


public class Account_Impl extends UnicastRemoteObject implements Account, Unreferenced {
    private Money _balance;
    private LockingFactory _factory;
    private String _accountName;

    public Account_Impl(Money startingBalance, String accountName) throws RemoteException {
        _balance = startingBalance;
        _accountName = accountName;
    }

    public synchronized Money getBalance() throws RemoteException {
        return _balance;
    }

    public synchronized void makeDeposit(Money amount)
        throws RemoteException, NegativeAmountException {
        checkForNegativeAmount(amount);
        _balance.add(amount);
        return;
    }

    public synchronized void makeWithdrawal(Money amount)
        throws RemoteException, OverdraftException, NegativeAmountException {
        checkForNegativeAmount(amount);
        checkForOverdraft(amount);
        _balance.subtract(amount);
        return;
    }

    public void setFactory(LockingFactory factory) throws RemoteException {
        _factory = factory;
    }

    private void checkForNegativeAmount(Money amount)
        throws NegativeAmountException {
        int cents = amount.getCents();

        if (0 > cents) {
            throw new NegativeAmountException();
        }
    }

    private void checkForOverdraft(Money amount)
        throws OverdraftException {
        if (amount.greaterThan(_balance)) {
            throw new OverdraftException(false);
        }
        return;
    }

    public void unreferenced() {
        if (null == _factory) {
            return;
        }
        try {
            _factory.serverNoLongerActive(_accountName);
        } catch (RemoteException e) {/* Factory is having issues*/
        }
        _factory = null;
    }

}
