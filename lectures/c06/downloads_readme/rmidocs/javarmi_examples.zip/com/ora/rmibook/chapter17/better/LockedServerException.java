package com.ora.rmibook.chapter17.better;


public class LockedServerException extends Exception {
    public LockedServerException(String serverName) {
        super ("Server named " + serverName + "is not available.");
    }
} 
