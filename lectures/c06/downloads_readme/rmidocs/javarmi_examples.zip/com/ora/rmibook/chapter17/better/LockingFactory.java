package com.ora.rmibook.chapter17.better;


import com.ora.rmibook.chapter17.better.valueobjects.*;
import com.ora.rmibook.chapter17.better.*;
import java.rmi.*;


public interface LockingFactory {
    public Remote getServer(String serverName) throws RemoteException, LockedServerException;
    public Remote[] getServers(String[] serverName) throws RemoteException, LockedServerException;
    public void serverNoLongerActive(String serverName) throws RemoteException;
}
