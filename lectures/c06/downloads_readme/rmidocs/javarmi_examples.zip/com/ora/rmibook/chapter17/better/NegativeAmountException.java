package com.ora.rmibook.chapter17.better;


public class NegativeAmountException extends Exception {
} 
