package com.ora.rmibook.chapter17.better.factory;


import com.ora.rmibook.chapter17.better.valueobjects.*;
import com.ora.rmibook.chapter17.better.*;
import java.rmi.server.*;
import java.rmi.*;
import java.util.*;


public class LockingAccountFactory_Impl extends LockingFactory_Impl {
    public LockingAccountFactory_Impl()  throws RemoteException {
    }

    protected Remote _getServer(String serverName) {
        try {
            Account returnValue = new Account_Impl(getRandomMoney(), serverName);

            returnValue.setFactory(this);
            return returnValue;
        } catch (Exception ignored) {/* Creation of a local object should never fail*/
        }
        return null;
    }

    private Money getRandomMoney() {
        int cents = (int) (Math.random() * 100000);

        return new Money(cents);
    }
} 
