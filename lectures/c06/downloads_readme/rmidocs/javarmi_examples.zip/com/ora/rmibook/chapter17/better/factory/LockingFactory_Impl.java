package com.ora.rmibook.chapter17.better.factory;


import com.ora.rmibook.chapter17.better.valueobjects.*;
import com.ora.rmibook.chapter17.better.*;
import java.rmi.server.*;
import java.rmi.*;
import java.util.*;


public abstract class LockingFactory_Impl extends UnicastRemoteObject implements LockingFactory {
    protected abstract Remote _getServer(String serverName);

    private HashMap _lockedServerNames;

    public LockingFactory_Impl() throws RemoteException {
        _lockedServerNames = new HashMap();
    }

    public synchronized Remote getServer(String serverName) throws RemoteException, LockedServerException {
        Remote returnValue = _getServer(serverName);

        _lockedServerNames.put(serverName, serverName);
        return returnValue;
    }

    public synchronized Remote[] getServers(String[] serverNames) throws RemoteException, LockedServerException {
        Remote[] returnValue = new Remote[serverNames.length];
        int counter;

        for (counter = 0; counter < serverNames.length; counter++) {
            try {
                checkLock(serverNames[counter]);
                Remote nextServer = getServer(serverNames[counter]);

                returnValue[counter] = nextServer;
            } catch (LockedServerException serverLocked) {
                int returnCounter;

                for (returnCounter = 0; returnCounter < counter; returnCounter++) {
                    serverNoLongerActive(serverNames[returnCounter]);
                }
                throw serverLocked;
            }
        }
        return returnValue;
    }

    public synchronized void serverNoLongerActive(String serverName) throws RemoteException {
        _lockedServerNames.remove(serverName);
    }

    private synchronized void checkLock(String serverName) throws LockedServerException {
        if (null != _lockedServerNames.get(serverName)) {
            throw new LockedServerException(serverName);
        }
        return;
    }
}
