package com.ora.rmibook.chapter17.better.factory.applications;


import com.ora.rmibook.chapter17.better.factory.*;
import com.ora.rmibook.chapter17.better.*;
import com.ora.rmibook.chapter17.better.valueobjects.*;
import java.util.*;
import java.rmi.*;
import java.rmi.server.*;


public class LockingFactoryLauncher implements Constants {
    public static void main(String[] args) {
        try {
            LockingFactory_Impl factory = new LockingAccountFactory_Impl();

            Naming.rebind(ACCOUNT_FACTORY_NAME, factory);
            System.out.println("Factory successfully launched.");
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}
