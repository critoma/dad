package com.ora.rmibook.chapter17.better.valueobjects;


import java.io.*;


public class ServerList implements Serializable {
    public ServerList() {
    }
} 

