package com.ora.rmibook.chapter18.activation;


import com.ora.rmibook.chapter18.activation.valueobjects.*;
import com.ora.rmibook.chapter18.activation.*;
import com.ora.rmibook.chapter18.sockets.*;
import java.rmi.*;
import java.rmi.activation.*;
import java.rmi.server.*;


public class Account_Impl extends Activatable implements Account {
    private Money _balance;
    public Account_Impl(ActivationID id, MarshalledObject data)
        throws RemoteException {
        super (id, 0, new PropertyBasedMonitoringSocket_RMIClientSocketFactory(),
            new PropertyBasedMonitoringSocket_RMIServerSocketFactory());
        try {
            _balance = (Money) data.get();
        } catch (Exception e) {

            /* Both ClassNotFoundException and IOException can
             be thrown.*/
        }
    }

    public Money getBalance()
        throws RemoteException {
        return _balance;
    }

    public void makeDeposit(Money amount)
        throws RemoteException, NegativeAmountException {
        checkForNegativeAmount(amount);
        _balance.add(amount);
        return;
    }

    public void makeWithdrawal(Money amount)
        throws RemoteException, OverdraftException, NegativeAmountException {
        checkForNegativeAmount(amount);
        checkForOverdraft(amount);
        _balance.subtract(amount);
        return;
    }

    public boolean equals(Object object) {
        // three cases. Either it's us, or it's our stub, or it's
        // not equal.

        if (object instanceof Account_Impl) {
            return (object == this);
        }
        if (object instanceof RemoteStub) {
            try {
                RemoteStub ourStub = (RemoteStub) RemoteObject.toStub(this);

                return ourStub.equals(object);
            } catch (NoSuchObjectException e) {
                // we're not listening on a port, therefore it's not our
                // stub
            }
        }
        return false;
    }

    public int hashCode() {
        try {
            Remote ourStub = RemoteObject.toStub(this);

            return ourStub.hashCode();
        } catch (NoSuchObjectException e) {
        }
        return super.hashCode();
    }
    
    private void checkForNegativeAmount(Money amount)
        throws NegativeAmountException {
        int cents = amount.getCents();

        if (0 > cents) {
            throw new NegativeAmountException();
        }
    }

    private void checkForOverdraft(Money amount)
        throws OverdraftException {
        if (amount.greaterThan(_balance)) {
            throw new OverdraftException(false);
        }
        return;
    }
} 

