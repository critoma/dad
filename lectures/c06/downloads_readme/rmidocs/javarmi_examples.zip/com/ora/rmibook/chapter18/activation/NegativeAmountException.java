package com.ora.rmibook.chapter18.activation;


public class NegativeAmountException extends Exception {
} 
