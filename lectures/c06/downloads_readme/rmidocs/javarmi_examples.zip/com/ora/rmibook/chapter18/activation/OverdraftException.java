package com.ora.rmibook.chapter18.activation;


public class OverdraftException extends Exception {
    public boolean _withdrawalSucceeded;
    public OverdraftException(boolean withdrawalSucceeded) {
        _withdrawalSucceeded = withdrawalSucceeded;
    }

    public boolean isWithdrawalSucceeded() {
        return _withdrawalSucceeded;
    }
}
