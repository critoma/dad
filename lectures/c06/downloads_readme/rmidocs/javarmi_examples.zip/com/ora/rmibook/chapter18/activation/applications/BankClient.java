package com.ora.rmibook.chapter18.activation.applications;


import com.ora.rmibook.chapter18.activation.*;
import java.rmi.*;
import java.rmi.server.*;


public class BankClient {
    public static void main(String[] args) {
        new RMISecurityManager();
        (new BankClientFrame()).show();
    }
}
