package com.ora.rmibook.chapter18.activation.applications;


import com.ora.rmibook.chapter18.activation.*;
import com.ora.rmibook.chapter18.activation.valueobjects.*;
import java.util.*;
import java.io.*;
import java.rmi.*;
import java.rmi.server.*;
import java.rmi.activation.*;


public class FirstLauncher {
    private static final String USE_MONITORING_SOCKETS_PROPERTY = "com.ora.rmibook.useMonitoringSockets";
    private static final String USE_MONITORING_SOCKETS_VALUE = "true";
    public static void main(String[] args) {
        try {
            createBankAccounts();
        } catch (Exception e) {
            System.out.println("Launch Failure.");
            e.printStackTrace();
        }
        System.exit(0);
    }

    private static void createBankAccounts() throws RemoteException, ActivationException {
        createActivationGroup();
        createBankAccount("Erik", getRandomMoney());
        createBankAccount("Eugene", getRandomMoney());
        createBankAccount("Earle", getRandomMoney());
    }

    private static Money getRandomMoney() {
        int cents = (int) (Math.random() * 100000);

        return new Money(cents);
    }

    private static void createBankAccount(String owner, Money money) {
        try {
            ActivationDesc aD = createActivationDesc(owner, money);
            Account account = (Account) Account_Impl.register(aD);

            Naming.rebind(owner, account);
        } catch (Exception e) {
            System.out.println("Failed to create account for " + owner);
            e.printStackTrace();
        }
    }

    private static void createActivationGroup()
        throws ActivationException, RemoteException {
        ActivationGroupID oldID = ActivationGroup.currentGroupID();
        Properties pList = new Properties();

        pList.put("java.security.policy", "d:\\java.policy");
        pList.put("sun.rmi.transport.connectionTimeout", "30000");
        pList.put(USE_MONITORING_SOCKETS_PROPERTY, USE_MONITORING_SOCKETS_VALUE);
        ActivationGroupDesc.CommandEnvironment configInfo = null;
        ActivationGroupDesc description = new ActivationGroupDesc(pList, configInfo);
        ActivationGroupID id = (ActivationGroup.getSystem()).registerGroup(description);

        ActivationGroup.createGroup(id, description, 0);
        return;
    }

    private static ActivationDesc createActivationDesc(String owner, Money moneyToStart)
        throws ActivationException, RemoteException, IOException {
        return new ActivationDesc("com.ora.rmibook.chapter18.activation.Account_Impl", "file:/D:/Classes/",
                new MarshalledObject(moneyToStart));
    }
}

