package com.ora.rmibook.chapter18.bank;


import com.ora.rmibook.chapter18.bank.valueobjects.*;
import com.ora.rmibook.chapter18.sockets.*;
import java.rmi.*;
import java.rmi.server.*;


public class Account_Impl extends UnicastRemoteObject implements Account {
    private Money _balance;

    public Account_Impl(Money startingBalance)
        throws RemoteException {
        super (0, new SSLSocket_RMIClientSocketFactory(),
            new SSLSocket_RMIServerSocketFactory());
        _balance = startingBalance;
    }

    public Money getBalance()
        throws RemoteException {
        return _balance;
    }

    public void makeDeposit(Money amount)
        throws RemoteException, NegativeAmountException {
        checkForNegativeAmount(amount);
        _balance.add(amount);
        return;
    }

    public void makeWithdrawal(Money amount)
        throws RemoteException, OverdraftException, NegativeAmountException {
        checkForNegativeAmount(amount);
        checkForOverdraft(amount);
        _balance.subtract(amount);
        return;
    }

    private void checkForNegativeAmount(Money amount)
        throws NegativeAmountException {
        int cents = amount.getCents();

        if (0 > cents) {
            throw new NegativeAmountException();
        }
    }

    private void checkForOverdraft(Money amount)
        throws OverdraftException {
        if (amount.greaterThan(_balance)) {
            throw new OverdraftException(false);
        }
        return;
    }
} 

