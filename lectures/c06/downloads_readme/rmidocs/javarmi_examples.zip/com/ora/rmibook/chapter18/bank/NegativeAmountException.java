package com.ora.rmibook.chapter18.bank;


public class NegativeAmountException extends Exception {
} 
