package com.ora.rmibook.chapter18.bank.applications;


import java.rmi.*;
import java.rmi.server.*;


public class BankClient {
    public static void main(String[] args) {
        (new BankClientFrame()).show();
    }
}
