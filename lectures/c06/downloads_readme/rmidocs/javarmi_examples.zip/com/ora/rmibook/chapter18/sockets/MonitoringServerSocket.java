package com.ora.rmibook.chapter18.sockets;


import java.net.*;
import java.io.*;


public class MonitoringServerSocket extends ServerSocket {
    private static int _numberOfOpenSockets = 0;

    private static void _incrementNumberOfOpenSockets() {
        _numberOfOpenSockets++;
    }

    public MonitoringServerSocket(int port)
        throws IOException {
        super (port);
        _incrementNumberOfOpenSockets();
    }

    public Socket accept()	throws IOException {
        Socket returnValue = new MonitoringSocket();

        implAccept(returnValue);
        return returnValue;
    }

    public void setSoTimeout(int timeout) throws SocketException {
        super.setSoTimeout(timeout);
        printMonitoringServerSocketStatus();
    }

    private synchronized void printMonitoringServerSocketStatus() {
        System.out.println("There are currently " + _numberOfOpenSockets + " open MonitoringServerSockets");
        try {
            System.out.println("\t getSoTimeout() returns " + getSoTimeout());
        } catch (IOException e) {
            System.out.println("\t getSoTimeout() is currently throwing an exception ");
        }
    }

    public void finalize() {
        decrementNumberOfOpenSockets();
    }

    private static void decrementNumberOfOpenSockets() {
        _numberOfOpenSockets--;
    }

}
