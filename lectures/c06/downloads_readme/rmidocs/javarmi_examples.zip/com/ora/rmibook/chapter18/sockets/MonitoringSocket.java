package com.ora.rmibook.chapter18.sockets;


import java.io.*;
import java.net.*;


public class MonitoringSocket extends Socket {
    private static int _numberOfOpenSockets = 0;
 
    private synchronized static void incrementNumberOfOpenSockets() {
        _numberOfOpenSockets++;
    }

    public MonitoringSocket() throws IOException {
        incrementNumberOfOpenSockets();
        printMonitoringSocketStatus();
    }

    public MonitoringSocket(String host, int port) throws IOException {
        super (host, port);
        incrementNumberOfOpenSockets();
        printMonitoringSocketStatus();
    }

    public void close() throws IOException {
        super.close();
        decrementNumberOfOpenSockets();
        printMonitoringSocketStatus();
    }

    public synchronized void setSoTimeout(int timeout) throws SocketException {
        System.out.println("Set timeout called");
        super.setSoTimeout(timeout);
    }

    private static synchronized void printMonitoringSocketStatus() {
        System.out.println("There are currently " + _numberOfOpenSockets + " open MonitoringSockets");
    }

    private synchronized static void decrementNumberOfOpenSockets() {
        _numberOfOpenSockets--;
    }
}
