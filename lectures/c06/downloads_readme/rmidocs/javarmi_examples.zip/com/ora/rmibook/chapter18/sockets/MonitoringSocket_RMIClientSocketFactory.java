package com.ora.rmibook.chapter18.sockets;


import java.rmi.server.*;
import java.io.*;
import java.net.*;


public class MonitoringSocket_RMIClientSocketFactory
    implements RMIClientSocketFactory, Serializable {
    private int _hashCode = "MonitoringSocket_RMIClientSocketFactory".hashCode();
    public Socket createSocket(String host, int port) {
        try {
            return new MonitoringSocket(host, port);
        } catch (IOException e) {
        }
        return null;
    }

    public boolean equals(Object object) {
        if (object instanceof MonitoringSocket_RMIClientSocketFactory) {
            return true;
        }
        return false;
    }

    public int hashCode() {
        return _hashCode;
    }
}
