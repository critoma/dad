package com.ora.rmibook.chapter18.sockets;


import java.rmi.server.*;
import java.net.*;
import java.io.*;


public class MonitoringSocket_RMIServerSocketFactory
    implements RMIServerSocketFactory {
    private int _hashCode = "MonitoringSocket_RMIServerSocketFactory".hashCode();
    public ServerSocket createServerSocket(int port) {
        try {
            return new MonitoringServerSocket(port);
        } catch (IOException e) {
        }
        return null;
    }

    public boolean equals(Object object) {
        if (object instanceof MonitoringSocket_RMIServerSocketFactory) {
            return true;
        }
        return false;
    }

    public int hashCode() {
        return _hashCode;
    }
}
