package com.ora.rmibook.chapter18.sockets;


import java.rmi.server.*;
import java.io.*;
import java.net.*;


public class PropertyBasedMonitoringSocket_RMIClientSocketFactory
    implements RMIClientSocketFactory, Serializable {
    private static final String USE_MONITORING_SOCKETS_PROPERTY = "com.ora.rmibook.useMonitoringSockets";
    private static final String TRUE = "true";

    private int _hashCode = "PropertyBasedMonitoringSocket_RMIClientSocketFactory".hashCode();
    private boolean _isMonitoringOn;

    public PropertyBasedMonitoringSocket_RMIClientSocketFactory() {
        String monitoringProperty = System.getProperty(USE_MONITORING_SOCKETS_PROPERTY);

        if ((null != monitoringProperty) && (monitoringProperty.equalsIgnoreCase(TRUE))) {
            _isMonitoringOn = true;
            _hashCode++;
        } else {
            _isMonitoringOn = false;
        }
        return;
    }

    public Socket createSocket(String host, int port) {
        try {
            if (_isMonitoringOn) {
                return new MonitoringSocket(host, port);
            } else {
                return new Socket(host, port);
            }
        } catch (IOException e) {
        }
        return null;
    }

    public boolean equals(Object object) {
        if (object instanceof PropertyBasedMonitoringSocket_RMIClientSocketFactory) {
            return true;
        }
        return false;
    }

    public int hashCode() {
        return _hashCode;
    }
}
