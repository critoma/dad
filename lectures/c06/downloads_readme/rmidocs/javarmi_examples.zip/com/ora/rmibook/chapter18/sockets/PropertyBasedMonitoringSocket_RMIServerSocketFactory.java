package com.ora.rmibook.chapter18.sockets;


import java.rmi.server.*;
import java.net.*;
import java.io.*;


public class PropertyBasedMonitoringSocket_RMIServerSocketFactory
    implements RMIServerSocketFactory {
    private static final String USE_MONITORING_SOCKETS_PROPERTY = "com.ora.rmibook.useMonitoringSockets";
    private static final String TRUE = "true";

    private int _hashCode = "PropertyBasedMonitoringSocket_RMIServerSocketFactory".hashCode();
    private boolean _isMonitoringOn;

    public PropertyBasedMonitoringSocket_RMIServerSocketFactory() {
        String compressionProperty = System.getProperty(USE_MONITORING_SOCKETS_PROPERTY);

        if ((null != compressionProperty) && (compressionProperty.equalsIgnoreCase(TRUE))) {
            _isMonitoringOn = true;
            _hashCode++;
        } else {
            _isMonitoringOn = false;
        }
        return;
    }

    public ServerSocket createServerSocket(int port) {
        try {
            if (_isMonitoringOn) {
                return new MonitoringServerSocket(port);
            } else {
                return new ServerSocket(port);
            }
        } catch (IOException e) {
        }
        return null;
    }

    public boolean equals(Object object) {
        if (object instanceof PropertyBasedMonitoringSocket_RMIServerSocketFactory) {
            return true;
        }
        return false;
    }

    public int hashCode() {
        return _hashCode;
    }
}
