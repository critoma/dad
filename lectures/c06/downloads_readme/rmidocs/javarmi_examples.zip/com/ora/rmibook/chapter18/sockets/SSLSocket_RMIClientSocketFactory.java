package com.ora.rmibook.chapter18.sockets;


import java.rmi.server.*;
import java.io.*;
import java.net.*;
import javax.net.ssl.*;


/*
 Redirects to the standard SSL Socket factory found in JSSE.
 */

public class SSLSocket_RMIClientSocketFactory implements RMIClientSocketFactory, Serializable {
    public static String ANON_CIPHER = "SSL_DH_anon_WITH_RC4_128_MD5";
    public static String[] CIPHERS = {ANON_CIPHER};
    private int _hashCode = "SSLSocket_RMIClientSocketFactory".hashCode();
    public Socket createSocket(String host, int port) {
        try {
            java.security.Security.addProvider(new com.sun.net.ssl.internal.ssl.Provider());
            SSLSocketFactory socketFactory = (SSLSocketFactory) SSLSocketFactory.getDefault();
            SSLSocket returnValue = (SSLSocket) socketFactory.createSocket(host, port);

            returnValue.setEnabledCipherSuites(CIPHERS);
            return returnValue;
        } catch (Exception ignored) {
            ignored.printStackTrace();
        }
        return null;
    }

    public boolean equals(Object object) {
        if (object instanceof SSLSocket_RMIClientSocketFactory) {
            return true;
        }
        return false;
    }

    public int hashCode() {
        return _hashCode;
    }
}
