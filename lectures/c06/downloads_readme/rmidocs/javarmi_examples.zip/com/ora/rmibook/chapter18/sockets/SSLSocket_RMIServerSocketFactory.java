package com.ora.rmibook.chapter18.sockets;


import java.rmi.server.*;
import java.net.*;
import java.io.*;
import javax.net.ssl.*;


public class SSLSocket_RMIServerSocketFactory implements RMIServerSocketFactory {
    public static String ANON_CIPHER = "SSL_DH_anon_WITH_RC4_128_MD5";
    public static String[] CIPHERS = {ANON_CIPHER};
    private int _hashCode = "SSLSocket_RMIServerSocketFactory".hashCode();

    public ServerSocket createServerSocket(int port) {
        try {
            java.security.Security.addProvider(new com.sun.net.ssl.internal.ssl.Provider());
            SSLServerSocketFactory socketFactory = (SSLServerSocketFactory) SSLServerSocketFactory.getDefault();
            SSLServerSocket returnValue = (SSLServerSocket) socketFactory.createServerSocket(port);

            returnValue.setEnabledCipherSuites(CIPHERS);
            returnValue.setNeedClientAuth(false);
            return returnValue;
        } catch (Exception ignored) {
            ignored.printStackTrace();
        }
        return null;
    }

    public boolean equals(Object object) {
        if (object instanceof MonitoringSocket_RMIServerSocketFactory) {
            return true;
        }
        return false;
    }

    public int hashCode() {
        return _hashCode;
    }
}
