package com.ora.rmibook.chapter2;


public class WebBrowser {
    public static void main(String[] args) {
        (new WebBrowserFrame()).show();
    }
}
