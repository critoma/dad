package com.ora.rmibook.chapter2;


import com.ora.rmibook.gui.*;
import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import java.io.*;
import java.net.*;


public class WebBrowserFrame extends ExitingFrame {
    private JTextArea _displayArea;
    private JTextField _url;
    private JButton _fetchButton;

    protected void buildGUI() {
        JPanel newContentPane = new JPanel(new BorderLayout());

        newContentPane.add(buildButtonBar(), BorderLayout.SOUTH);
        newContentPane.add(buildMainPanel(), BorderLayout.CENTER);
        setContentPane(newContentPane);
        setSize(250, 300);
    }

    private JComponent buildButtonBar() {
        JPanel topPanel = new JPanel(new GridLayout(1, 2));

        _url = new JTextField(40);
        _fetchButton = new ActionButton(new FetchURL());
        topPanel.add(_url);
        topPanel.add(_fetchButton);
        return topPanel;
    }

    private JComponent buildMainPanel() {
        _displayArea = new JTextArea();
        _displayArea.setLineWrap(true);
        JScrollPane scrollPane = new JScrollPane(_displayArea);

        scrollPane.setBorder(new EtchedBorder());
        return scrollPane;
    }

    private void askForPage(Socket webServer) throws IOException {
        BufferedWriter request;

        request = new BufferedWriter(new OutputStreamWriter(webServer.getOutputStream()));
        request.write("GET / HTTP/1.0\n\n");
        request.flush();
    }

    private void receivePage(Socket webServer) throws IOException {
        BufferedReader webPage = null;

        webPage = new BufferedReader(new InputStreamReader(webServer.getInputStream()));
        String nextLine;

        while (null != (nextLine = webPage.readLine())) {
            _displayArea.append(nextLine + "\n");
        }
        return;
    }

    private class FetchURL extends AbstractAction {
        public FetchURL() {
            putValue(Action.NAME, "Fetch");
            putValue(Action.SHORT_DESCRIPTION, "Retrieve the indicated URL");
        }

        public void actionPerformed(ActionEvent e) {
            String url = _url.getText();
            Socket webServer;

            try {
                webServer = new Socket(url, 80);
            } catch (Exception invalidURL) {
                _displayArea.setText("URL " + url + " is not valid.");
                return;
            }
            try {
                askForPage(webServer);
                receivePage(webServer);
                webServer.close();
            } catch (IOException whoReallyCares) {
                _displayArea.append("\n Error in talking to the web server.");
            }
        }
    }
}
