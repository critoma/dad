package com.ora.rmibook.chapter2;


public class WebServer {
    public static void main(String[] args) {
        WebServerFrame webServer = new WebServerFrame();

        webServer.show();
        webServer.startListening();
    }
}
