package com.ora.rmibook.chapter2;


import com.ora.rmibook.gui.*;
import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import java.io.*;
import java.net.*;


public class WebServerFrame extends ExitingFrame {
    private JTextArea _displayArea;

    public void startListening() {
        ServerSocket serverSocket;

        try {
            serverSocket = new ServerSocket(80);
        } catch (IOException e) {
            return;
        }
        while (true) {
            try {
                Socket client = serverSocket.accept(); // wait here

                processClientRequest(client);
                //bad design-- should  handle requests in separate threads
                // and immediately resume listening for connections            	client.close();
            } catch (IOException e) {
            }
        }
    }

    private void processClientRequest(Socket client) throws IOException {
        _displayArea.append("Client connected from port " +
            client.getPort() + " on machine " + client.getInetAddress() + "\n");
        _displayArea.append("Request is: \n");
        readRequest(client);
        sendResponse(client);
        client.close();
    }

    private void readRequest(Socket client) throws IOException {
        BufferedReader request = null;

        request = new BufferedReader(new InputStreamReader(client.getInputStream()));
        String nextLine;

        while (null != (nextLine = request.readLine())) {
            // Ideally, we'd do something. But this is a very
            // simple web server.
            if (nextLine.equals("")) {
                break;
            } else {
                _displayArea.append("\t" + nextLine + "\n");
            }
        }
        _displayArea.append("---------------------------------------\n");
        return;
    }

    private void sendResponse(Socket client) throws IOException {
        BufferedWriter response;

        response = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));
        response.write(_mainPage);
        response.flush();
    }

    protected void buildGUI() {
        JPanel newContentPane = new JPanel(new BorderLayout());

        newContentPane.add(buildMainPanel(), BorderLayout.CENTER);
        setContentPane(newContentPane);
        setSize(250, 300);
    }

    private JComponent buildMainPanel() {
        _displayArea = new JTextArea();
        _displayArea.setLineWrap(true);
        JScrollPane scrollPane = new JScrollPane(_displayArea);

        scrollPane.setBorder(new EtchedBorder());
        return scrollPane;
    }

    private static final String _mainPage =
        "HTTP/1.0 200 OK\n" +
        "Content-type: text/html\n" +
        "Connection: close\n" +
        "\n<HTML>\n" +
        "<HEAD>\n" +
        "<TITLE>Hello World</TITLE>\n" +
        "</HEAD>\n" +
        "<BODY> <a href = \"localhost\"> Hello World </a></BODY>\n" +
        "</HTML> \n\n";
}
