package com.ora.rmibook.chapter2.sockets;


import java.net.*;
import java.io.*;
import java.util.zip.*;


public class CompressingInputStream extends InputStream {
    private InputStream _actualInputStream;
    private GZIPInputStream _delegate;

    public CompressingInputStream(InputStream actualInputStream) {
        _actualInputStream = actualInputStream;
    }

    public int read() throws IOException {
        if (null == _delegate) {
            _delegate = new GZIPInputStream(_actualInputStream);
        }
        return _delegate.read();
    }

    public void close() throws IOException {
        if (null != _delegate) {
            _delegate.close();
        } else {
            _actualInputStream.close();
        }
    }
}

