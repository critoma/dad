package com.ora.rmibook.chapter2.sockets;


import java.io.*;
import java.net.*;
import java.util.zip.*;


public class CompressingOutputStream extends OutputStream {
    private OutputStream _actualOutputStream;
    private GZIPOutputStream _delegate;

    public CompressingOutputStream(OutputStream actualOutputStream) {
        _actualOutputStream = actualOutputStream;
    }

    public void write(int arg) throws IOException {
        if (null == _delegate) {
            _delegate = new  GZIPOutputStream(_actualOutputStream);
        }
        _delegate.write(arg);
        return;
    }

    public void close() throws IOException {
        if (null != _delegate) {
            _delegate.close();
        } else {
            _actualOutputStream.close();
        }
    }

    public void flush() throws IOException {
        if (null != _delegate) {
            _delegate.finish();
        }
    }
}
