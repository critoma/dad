package com.ora.rmibook.chapter2.sockets;


import java.net.*;
import java.io.*;


public class CompressingServerSocket extends ServerSocket {
    public CompressingServerSocket(int port)
        throws IOException {
        super (port);
    }

    public Socket accept()
        throws IOException {
        Socket returnValue = new CompressingSocket();

        implAccept(returnValue);
        return returnValue;
    }
}
