package com.ora.rmibook.chapter2.sockets;


import java.net.*;
import java.io.*;
import java.util.zip.*;


public class CompressingSocket extends Socket {
    private InputStream _compressingInputStream;
    private OutputStream _compressingOutputStream;

    public CompressingSocket()
        throws IOException {
    }

    public CompressingSocket(String host, int port)
        throws IOException {
        super (host, port);
    }

    public InputStream getInputStream()
        throws IOException {
        if (null == _compressingInputStream) {
            InputStream originalInputStream = super.getInputStream();

            _compressingInputStream = new CompressingInputStream(originalInputStream);
        }
        return _compressingInputStream;
    }

    public OutputStream getOutputStream()
        throws IOException {
        if (null == _compressingOutputStream) {
            OutputStream originalOutputStream = super.getOutputStream();

            _compressingOutputStream = new CompressingOutputStream(originalOutputStream);
        }
        return _compressingOutputStream;
    }

    public synchronized void close()
        throws IOException {
        if (null != _compressingOutputStream) {
            _compressingOutputStream.flush();
            _compressingOutputStream.close();
        }
        if (null != _compressingInputStream) {
            _compressingInputStream.close();
        }
    }
}
