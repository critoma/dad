package com.ora.rmibook.chapter2.sockets;


import java.io.*;


public class LoggingOutputStream extends FilterOutputStream {
    private Recorder _recorder;
    public LoggingOutputStream(OutputStream outputStream, String fileName) {
        this (outputStream, new Recorder(fileName));
    }

    public LoggingOutputStream(OutputStream outputStream, Recorder recorder) {
        super (outputStream);
        _recorder = recorder;
    }

    public void write(int b)
        throws IOException {
        _recorder.incrementCounter(1);
        super.write(b);
    }

    public void write(byte[] b)
        throws IOException {
        super.write(b);
        _recorder.incrementCounter(b.length);
    }

    public void write(byte[] b, int off, int len)
        throws IOException {
        super.write(b, off, len);
        _recorder.incrementCounter(len);
    }
}
