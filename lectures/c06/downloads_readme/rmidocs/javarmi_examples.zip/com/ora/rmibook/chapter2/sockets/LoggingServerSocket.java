package com.ora.rmibook.chapter2.sockets;


import java.net.*;
import java.io.*;


public class LoggingServerSocket extends ServerSocket {
    private String _fileNamePrefix;
    private int _fileIndex;
    public LoggingServerSocket(int port, String fileNamePrefix)
        throws IOException {
        super (port);
        _fileNamePrefix = fileNamePrefix;
        _fileIndex = 0;
    }

    public Socket accept()
        throws IOException {
        Socket returnValue = new LoggingSocket(_fileNamePrefix + "SocketNumber" + _fileIndex);

        _fileIndex++;
        implAccept(returnValue);
        return returnValue;
    }
}
