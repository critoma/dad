package com.ora.rmibook.chapter2.sockets;


import java.io.*;
import java.net.*;


public class LoggingSocket extends Socket {
    private LoggingInputStream _loggingInputStream;
    private LoggingOutputStream _loggingOutputStream;
    private String _fileName;

    public LoggingSocket(String fileName)
        throws IOException {
        _fileName = fileName;
    }

    public LoggingSocket(String host, int port, String fileName)
        throws IOException {
        super (host, port);
        _fileName = fileName;
    }

    public InputStream getInputStream()
        throws IOException {
        if (null == _loggingInputStream) {
            _loggingInputStream = new LoggingInputStream(super.getInputStream(), _fileName);
        }
        return _loggingInputStream;
    }

    public OutputStream getOutputStream() throws IOException {
        if (null == _loggingOutputStream) {
            _loggingOutputStream = new LoggingOutputStream(super.getOutputStream(), _fileName);
        }
        return _loggingOutputStream;
    }

    public synchronized void close() throws IOException {
        if (null != _loggingOutputStream) {
            _loggingOutputStream.flush();
            _loggingOutputStream.close();
        }
        if (null != _loggingInputStream) {
            _loggingInputStream.close();
        }
    }
}
