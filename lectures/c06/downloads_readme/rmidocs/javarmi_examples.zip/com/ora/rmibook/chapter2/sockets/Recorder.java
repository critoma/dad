package com.ora.rmibook.chapter2.sockets;


import java.io.*;


public class Recorder {
    public static final int DEFAULT_WRITE_GAP = 1024;
    private int _numberOfBytes;
    private int _lastRecordedNumberOfBytes;
    private int _recordingDifferential;
    private String _fileName;

    public Recorder(String fileName) {
        this (fileName, DEFAULT_WRITE_GAP);
    }

    public Recorder(String fileName, int recordingDifferential) {
        _recordingDifferential = recordingDifferential;
        _numberOfBytes = 0;
        _lastRecordedNumberOfBytes = 0;
        _fileName = fileName;
    }

    public void incrementCounter(int numberOfbytes) {
        _numberOfBytes += numberOfbytes;
        if (_recordingDifferential < (_numberOfBytes - _lastRecordedNumberOfBytes)) {
            flush();
        }
    }

    public void flush() {
        log();
        _lastRecordedNumberOfBytes = _numberOfBytes;
    }

    private void log() {
        try {
            OutputStream outputStream = new FileOutputStream(_fileName);
            PrintWriter writer = new PrintWriter(outputStream);

            writer.println(_numberOfBytes + " have been sent through the stream");
        } catch (Exception e) {
            System.out.println("Log failure with exception\n" + e);
            e.printStackTrace();
        }
    }
} 

