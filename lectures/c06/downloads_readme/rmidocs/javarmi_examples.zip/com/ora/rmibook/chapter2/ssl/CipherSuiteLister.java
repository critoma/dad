package com.ora.rmibook.chapter2.ssl;


import java.net.*;
import java.io.*;
import javax.net.ssl.*;


public class CipherSuiteLister {
    public static void main(String args[]) {
        try {
            java.security.Security.addProvider(new com.sun.net.ssl.internal.ssl.Provider());
            SSLServerSocketFactory socketFactory = (SSLServerSocketFactory) SSLServerSocketFactory.getDefault();
            String[] suites = socketFactory.getSupportedCipherSuites();

            System.out.println("Supported cipher suites:");
            for (int counter = 0; counter < suites.length; counter++) {
                System.out.println("\t" + suites[counter]);
            }
        } catch (Exception ignored) {
            ignored.printStackTrace();
        }
    }
}
