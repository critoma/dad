package com.ora.rmibook.chapter2.ssl;


public class SSLWebServer {
    public static void main(String[] args) {
        SSLWebServerFrame webServer = new SSLWebServerFrame();

        webServer.show();
        webServer.startListening();
    }
}
