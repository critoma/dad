package com.ora.rmibook.chapter2.ssl;


import com.ora.rmibook.gui.*;
import java.util.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;
import java.io.*;
import java.net.*;
import javax.net.ssl.*;


/*
 This isn't quite good enough because web browsers insist on
 authenticating servers.
 */

public class SSLWebServerFrame extends ExitingFrame {
    private static String ANON_CIPHER_1 = "SSL_DH_anon_WITH_DES_CBC_SHA";
    private static String ANON_CIPHER_2 = "SSL_DH_anon_WITH_3DES_EDE_CBC_SHA";
    private static String ANON_CIPHER_3 = "SSL_DH_anon_EXPORT_WITH_DES40_CBC_SHA";
    private static String ANON_CIPHER_4 = "SSL_DH_anon_WITH_RC4_128_MD5";
    private static String ANON_CIPHER_5 = "SSL_DH_anon_EXPORT_WITH_RC4_40_MD5";
    private static String[] CIPHERS = {ANON_CIPHER_1, ANON_CIPHER_2, ANON_CIPHER_3,
            ANON_CIPHER_4, ANON_CIPHER_5};
    static {
        java.security.Security.addProvider(new com.sun.net.ssl.internal.ssl.Provider());
    }
    private JTextArea _displayArea;

    public void startListening() {
        ServerSocket serverSocket;

        try {
            serverSocket = getSSLServerSocket(443);
        } catch (IOException e) {
            return;
        }
        while (true) {
            try {
                Socket client = serverSocket.accept(); // wait here

                processClientRequest(client);
                //bad design-- should  handle requests in separate threads
                // and immediately resume listening for connections            	client.close();
            } catch (IOException e) {
            }
        }
    }

    private void processClientRequest(Socket client) throws IOException {
        _displayArea.append("Client connected from port " +
            client.getPort() + " on machine " + client.getInetAddress() + "\n");
        _displayArea.append("Request is: \n");
        readRequest(client);
        sendResponse(client);
        client.close();
    }

    private void readRequest(Socket client) throws IOException {
        BufferedReader request = null;

        request = new BufferedReader(new InputStreamReader(client.getInputStream()));
        String nextLine;

        while (null != (nextLine = request.readLine())) {
            // Ideally, we'd do something. But this is a very
            // simple web server.
            if (nextLine.equals("")) {
                break;
            } else {
                _displayArea.append("\t" + nextLine + "\n");
            }
        }
        _displayArea.append("---------------------------------------\n");
        return;
    }

    private void sendResponse(Socket client) throws IOException {
        BufferedWriter response;

        response = new BufferedWriter(new OutputStreamWriter(client.getOutputStream()));
        response.write(_mainPage);
        response.flush();
    }

    protected void buildGUI() {
        JPanel newContentPane = new JPanel(new BorderLayout());

        newContentPane.add(buildMainPanel(), BorderLayout.CENTER);
        setContentPane(newContentPane);
        setSize(250, 300);
    }

    private JComponent buildMainPanel() {
        _displayArea = new JTextArea();
        _displayArea.setLineWrap(true);
        JScrollPane scrollPane = new JScrollPane(_displayArea);

        scrollPane.setBorder(new EtchedBorder());
        return scrollPane;
    }

    private ServerSocket getSSLServerSocket(int port) throws IOException {
        SSLServerSocketFactory socketFactory = (SSLServerSocketFactory) SSLServerSocketFactory.getDefault();
        SSLServerSocket returnValue = (SSLServerSocket) socketFactory.createServerSocket(port);

        returnValue.setEnabledCipherSuites(CIPHERS);
        returnValue.setNeedClientAuth(false);
        returnValue.setEnableSessionCreation(true);
        return returnValue;
    }

    private static final String _mainPage =
        "HTTP/1.0 200 OK\n" +
        "Content-type: text/html\n" +
        "Connection: close\n" +
        "\n<HTML>\n" +
        "<HEAD>\n" +
        "<TITLE>Hello World</TITLE>\n" +
        "</HEAD>\n" +
        "<BODY> <a href = \"localhost\"> Hello World </a></BODY>\n" +
        "</HTML> \n\n";
}
