package com.ora.rmibook.chapter21.bank;


import java.rmi.*;


public interface AccountIterator extends Remote {
    public int getNumberOfRemainingAccounts() throws RemoteException;
    public AccountList getNext(int numberToFetch) throws RemoteException;
}

