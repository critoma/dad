package com.ora.rmibook.chapter21.bank;


import java.util.*;
import java.io.*;


public class AccountList implements Serializable {
    public int numberOfAccountsRequested;
    public int numberOfAccountsReturned;
    public boolean areThereMoreAccountsToFetch;
    public ArrayList accounts;
}

