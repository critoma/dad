package com.ora.rmibook.chapter21.bank;


import java.net.*;
import java.io.*;
import java.rmi.*;
import java.rmi.server.*;
import java.util.*;


public abstract class AskServer implements Runnable {
    private AccountIterator _accountIterator;
    private String _salesHelperName;
    private Money _threshhold;
    private AccountList _currentAccounts;
    private int _fetchSize;

    protected abstract void handleResponseSet(ArrayList nextSetOfResponses);

    public AskServer(String salesHelperName, Money threshhold, int fetchSize) {
        _salesHelperName = salesHelperName;
        _threshhold = threshhold;
        _fetchSize = fetchSize;
    }

    public void performQuery() {
        try {
            makeInitialRequest();
        } catch (Exception e) {
            System.out.println("Error in connecting to server");
            e.printStackTrace();
            return;
        }
        new Thread(this).start();
    }

    public void run() {
        while (_currentAccounts.areThereMoreAccountsToFetch) {
            try {
                _currentAccounts = _accountIterator.getNext(_fetchSize);
                handleResponseSet(_currentAccounts.accounts);
            } catch (RemoteException e) {
                // insert exception handling here
            }
        }
    }

    private void makeInitialRequest() throws Exception {
        SalesHelper salesHelper = (SalesHelper) Naming.lookup(_salesHelperName);
        QueryResponse queryResponse = salesHelper.getAllAccountsWithBalanceOver(_threshhold);

        _currentAccounts = queryResponse;
        _accountIterator = queryResponse.accountIterator;
        handleResponseSet(_currentAccounts.accounts);
    }
}
