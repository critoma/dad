package com.ora.rmibook.chapter21.bank;


import java.util.*;
import java.io.*;


public class QueryResponse extends AccountList {
    public AccountIterator accountIterator;
}

