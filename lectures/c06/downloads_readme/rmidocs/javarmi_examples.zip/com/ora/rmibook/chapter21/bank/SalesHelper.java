package com.ora.rmibook.chapter21.bank;


import java.rmi.*;


public interface SalesHelper extends Remote {
    public QueryResponse getAllAccountsWithBalanceOver(Money amount) throws RemoteException;
}

