package com.ora.rmibook.chapter21.printer;


import java.rmi.*;


public interface CallbackClient extends Remote {
    public void documentIsDone() throws RemoteException;
    public void documentFailedToPrint(String reason) throws RemoteException;
}

