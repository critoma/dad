package com.ora.rmibook.chapter21.printer;


import java.rmi.*;


public interface CallbackPrinter extends PrinterConstants, Remote {
    public void printDocument(CallbackClient clientMakingRequest, DocumentDescription document)
        throws RemoteException, PrinterException;
}

