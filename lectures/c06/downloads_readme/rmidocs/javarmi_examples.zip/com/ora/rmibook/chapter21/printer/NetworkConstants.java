package com.ora.rmibook.chapter21.printer;


public interface NetworkConstants {
    public static final String DEFAULT_PRINTER_NAME = "Default Printer";
}
