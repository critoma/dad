package com.ora.rmibook.chapter21.printer;


import java.rmi.*;


public interface PollingPrinter extends PrinterConstants, Remote {
    public boolean printerAvailable()
        throws RemoteException;
    public String printDocument(DocumentDescription document)
        throws RemoteException, PrinterException;
    public boolean isDocumentDone(String documentKey)
        throws RemoteException, PrinterException;
}

