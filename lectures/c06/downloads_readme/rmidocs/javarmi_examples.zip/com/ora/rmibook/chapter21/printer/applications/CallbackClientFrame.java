package com.ora.rmibook.chapter21.printer.applications;


import com.ora.rmibook.chapter21.printer.*;
import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.net.*;
import java.io.*;
import java.rmi.*;
import java.rmi.server.*;


public class CallbackClientFrame extends JFrame implements NetworkConstants {
    private JTextArea _messageBox;
    private JButton _chooseFileButton;
    private JButton _printFileButton;
    private JFileChooser _fileChooser;

    public CallbackClientFrame() {
        buildGUI();
        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        addWindowListener(new ExitOnClose());
        setSize(250, 200);
    }

    private void buildGUI() {
        JPanel mainPanel = new JPanel(new BorderLayout());

        _messageBox = new JTextArea();
        mainPanel.add(new JScrollPane(_messageBox), BorderLayout.CENTER);
        createButtons();
        JPanel buttonHolder = new JPanel(new GridLayout(1, 2));

        buttonHolder.add(_chooseFileButton);
        buttonHolder.add(_printFileButton);
        mainPanel.add(buttonHolder, BorderLayout.SOUTH);
        getContentPane().add(mainPanel);
    }

    private void createButtons() {
        _chooseFileButton = new JButton("Choose File");
        _chooseFileButton.addActionListener(new FindFile());
        _printFileButton = new JButton("Print File");
        _printFileButton.addActionListener(new PrintFile());
    }

    private class ExitOnClose extends WindowAdapter {
        public void windowClosed(WindowEvent event) {
            System.exit(0);
        }
    }


    private class FindFile implements ActionListener {
        public void actionPerformed(ActionEvent event) {
            if (null == _fileChooser) {
                _fileChooser = new JFileChooser();
            }
            if (JFileChooser.APPROVE_OPTION == _fileChooser.showOpenDialog(CallbackClientFrame.this)) {
                _messageBox.setText((_fileChooser.getSelectedFile()).getAbsolutePath());
            }
        }
    }


    private class PrintFile implements ActionListener {
        private CallbackPrinter _printer;
        public void actionPerformed(ActionEvent event) {
            try {
                File fileToPrint = _fileChooser.getSelectedFile();
                FileInputStream documentStream = new FileInputStream(fileToPrint);
                DocumentDescription documentDescription = new DocumentDescription(documentStream);

                _printer = (CallbackPrinter) Naming.lookup(DEFAULT_PRINTER_NAME);
                CallbackClient callbackClient = new  CallbackClient_DialogImpl(fileToPrint.getName());
                _printer.printDocument(callbackClient, documentDescription);
            } catch (Exception exception) {
                SwingUtilities.invokeLater(new ExceptionMessage(exception));
                return;
            }
        }
    }


    private class ExceptionMessage implements Runnable {
        private Exception _exception;
        public ExceptionMessage(Exception exception) {
            _exception = exception;
        }

        public void run() {
            JOptionPane.showMessageDialog(CallbackClientFrame.this,
                "Print failed", "Error in printing", JOptionPane.INFORMATION_MESSAGE);
            _messageBox.setText("Exception attempting to print " + (_fileChooser.getSelectedFile()).getAbsolutePath() +
                "\n\t Error was: " + _exception.toString());
            _exception.printStackTrace();
        }
    }
}

