package com.ora.rmibook.chapter21.printer.applications;


import com.ora.rmibook.chapter21.printer.*;
import java.rmi.*;
import java.rmi.server.*;
import javax.swing.*;


public class CallbackClient_DialogImpl extends UnicastRemoteObject implements CallbackClient {
    private static final String SUCCESS_WINDOW_TITLE = "Success!";
    private static final String FAILURE_WINDOW_TITLE = "Failure!";
    private String _documentName;
    public CallbackClient_DialogImpl(String documentName) throws RemoteException {
        _documentName = documentName;
    }

    public void documentIsDone() throws RemoteException {
        reportResultOfPrintRequest(SUCCESS_WINDOW_TITLE, _documentName + " is done printing.");
        ceaseBeingAServer();
    }

    public void documentFailedToPrint(String reason) throws RemoteException {
        reportResultOfPrintRequest(FAILURE_WINDOW_TITLE, _documentName + " failed to print because " + reason);
    }

    private void reportResultOfPrintRequest(String windowTitle, String message) {
        SwingUtilities.invokeLater(new SendMessageToUser(windowTitle, message));
    }

    private void ceaseBeingAServer() {
        try {
            unexportObject(this, true);
        } catch (NoSuchObjectException e) {
            // Not much to do. The RMI runtime thinks we're not a server.
        }
    }
    private class SendMessageToUser implements Runnable {
        private String _windowTitle;
        private String _message;
        public SendMessageToUser(String windowTitle, String message) {
            _windowTitle = windowTitle;
            _message = message;
        }

        public void run() {
            JOptionPane.showMessageDialog(null, _windowTitle, _message,
                JOptionPane.INFORMATION_MESSAGE);
        }
    }
}
