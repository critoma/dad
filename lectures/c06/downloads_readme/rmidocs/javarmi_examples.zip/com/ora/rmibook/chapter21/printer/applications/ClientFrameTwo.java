package com.ora.rmibook.chapter21.printer.applications;


import com.ora.rmibook.chapter21.printer.*;
import javax.swing.*;
import java.awt.event.*;
import java.awt.*;
import java.net.*;
import java.io.*;
import java.rmi.*;
import java.rmi.server.*;


public class ClientFrameTwo extends JFrame implements NetworkConstants {
    private JTextArea _messageBox;
    private JButton _chooseFileButton;
    private JButton _printFileButton;
    private JFileChooser _fileChooser;

    public ClientFrameTwo() {
        buildGUI();
        setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);
        addWindowListener(new ExitOnClose());
        setSize(250, 200);
    }

    private void buildGUI() {
        JPanel mainPanel = new JPanel(new BorderLayout());

        _messageBox = new JTextArea();
        mainPanel.add(new JScrollPane(_messageBox), BorderLayout.CENTER);
        createButtons();
        JPanel buttonHolder = new JPanel(new GridLayout(1, 2));

        buttonHolder.add(_chooseFileButton);
        buttonHolder.add(_printFileButton);
        mainPanel.add(buttonHolder, BorderLayout.SOUTH);
        getContentPane().add(mainPanel);
    }

    private void createButtons() {
        _chooseFileButton = new JButton("Choose File");
        _chooseFileButton.addActionListener(new FindFile());
        _printFileButton = new JButton("Print File");
        _printFileButton.addActionListener(new PrintFile());
    }

    private class ExitOnClose extends WindowAdapter {
        public void windowClosed(WindowEvent event) {
            System.exit(0);
        }
    }


    private class FindFile implements ActionListener {
        public void actionPerformed(ActionEvent event) {
            if (null == _fileChooser) {
                _fileChooser = new JFileChooser();
            }
            if (JFileChooser.APPROVE_OPTION == _fileChooser.showOpenDialog(ClientFrameTwo.this)) {
                _messageBox.setText((_fileChooser.getSelectedFile()).getAbsolutePath());
            }
        }
    }


    private class PrintFile implements ActionListener, Runnable {
        public void actionPerformed(ActionEvent event) {
            new Thread(this).start();
        }

        public void run() {
            try {
                FileInputStream documentStream = new FileInputStream(_fileChooser.getSelectedFile());
                DocumentDescription documentDescription = new
                    DocumentDescription(documentStream);
                Printer printer = (Printer) Naming.lookup(DEFAULT_PRINTER_NAME);

                printer.printDocument(documentDescription);
            } catch (PrinterException printerException) {
                SwingUtilities.invokeLater(new PrinterExceptionMessage(printerException));
                return;
            } catch (Exception exception) {
                SwingUtilities.invokeLater(new ExceptionMessage(exception));
                return;
            }
            SwingUtilities.invokeLater(new SuccessMessage());
        }
    }


    private class PrinterExceptionMessage implements Runnable {
        private PrinterException _printerException;
        public PrinterExceptionMessage(PrinterException printerException) {
            _printerException = printerException;
        }

        public void run() {
            String errorMessage = "Print failed after " + _printerException.getNumberOfPagesPrinted() + " pages.";

            JOptionPane.showMessageDialog(ClientFrameTwo.this,
                errorMessage, "Error in printing", JOptionPane.INFORMATION_MESSAGE);
            _messageBox.setText("Exception attempting to print " + (_fileChooser.getSelectedFile()).getAbsolutePath() +
                "\n\t Error was: " + _printerException.getHumanReadableErrorDescription());
        }
    }


    private class ExceptionMessage implements Runnable {
        private Exception _exception;
        public ExceptionMessage(Exception exception) {
            _exception = exception;
        }

        public void run() {
            JOptionPane.showMessageDialog(ClientFrameTwo.this,
                "Print failed", "Error in printing", JOptionPane.INFORMATION_MESSAGE);
            _messageBox.setText("Exception attempting to print " + (_fileChooser.getSelectedFile()).getAbsolutePath() +
                "\n\t Error was: " + _exception.toString());
            _exception.printStackTrace();
        }
    }


    private class SuccessMessage implements Runnable {
        public void run() {
            JOptionPane.showMessageDialog(ClientFrameTwo.this, "Success!", "document has been printed",
                JOptionPane.INFORMATION_MESSAGE);
            _messageBox.setText("Print Request succeeded.");
        }
    }
}
