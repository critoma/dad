package com.ora.rmibook.chapter21.printer.applications;


import java.rmi.*;


public class SimpleClient {
    public static void main(String[] args) {
        System.setSecurityManager(new RMISecurityManager());
        (new SimpleClientFrame()).show();
    }
} 

