package com.ora.rmibook.chapter21.printer.applications;


import com.ora.rmibook.chapter21.printer.printers.*;
import com.ora.rmibook.chapter21.printer.*;
import java.io.*;
import java.rmi.*;
import java.rmi.server.*;


public class SimpleServer implements NetworkConstants {
    public static void main(String args[]) {
        try {
            File logfile = new File("C:\\temp\\serverLogfile");
            OutputStream outputStream = new FileOutputStream(logfile);
            Printer printer = new SynchronizedPrinter(outputStream);

            Naming.rebind(DEFAULT_PRINTER_NAME, printer);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
} 

