package com.ora.rmibook.chapter22;


public class NegativeAmountException extends Exception {
} 
