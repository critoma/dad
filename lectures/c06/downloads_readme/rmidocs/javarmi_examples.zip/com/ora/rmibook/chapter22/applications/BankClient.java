package com.ora.rmibook.chapter22.applications;


import java.rmi.*;
import java.rmi.server.*;
import java.io.*;


public class BankClient {
    public static void main(String[] args) {
        try {
            RMISocketFactory.setSocketFactory(new sun.rmi.transport.proxy.RMIHttpToCGISocketFactory());
        } catch (IOException ignored) {
        }
        (new BankClientFrame()).show();
    }
}
