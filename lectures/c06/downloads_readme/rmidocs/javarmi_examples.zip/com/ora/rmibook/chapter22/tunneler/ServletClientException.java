package com.ora.rmibook.chapter22.tunneler;


public class ServletClientException extends Exception {
    public ServletClientException(String s) {
        super (s);
    }
}
