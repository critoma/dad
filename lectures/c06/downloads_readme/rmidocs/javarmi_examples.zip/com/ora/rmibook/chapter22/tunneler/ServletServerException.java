package com.ora.rmibook.chapter22.tunneler;


public class ServletServerException extends Exception {
    public ServletServerException(String s) {
        super (s);
    }
}

