/*
 *	SimplifiedServletHandler
 *
 *	A gutted version of SUN's ServletHandler.
 * 	Illustrates the basic idea, without any attempts at the fancy stuff.
 */

package com.ora.rmibook.chapter22.tunneler;


import java.io.*;
import java.net.*;
import java.util.*;
import java.rmi.registry.*;
import java.rmi.*;
import java.rmi.server.*;

import javax.servlet.http.*;
import javax.servlet.*;


public class SimplifiedServletHandler extends HttpServlet {

    public void init(ServletConfig config) throws ServletException {
        super.init(config);
        System.out.println("Simplified RMI Servlet Handler loaded sucessfully.");
    }

    /**
     * Execute the command given in the servlet request query string.
     * The string before the first '=' in the queryString is
     * interpreted as the command name, and the string after the first
     * '=' is the parameters to the command.
     *
     * @param req  HTTP servlet request, contains incoming command and
     *             arguments
     * @param res  HTTP servlet response
     * @exception  ServletException and IOException when invoking
     *             methods of <code>req<code> or <code>res<code>.  
     */
    public void doPost(HttpServletRequest req, HttpServletResponse res)
        throws ServletException, IOException {
        try {
            String queryString = req.getQueryString();
            String command, param;
            int delim = queryString.indexOf("=");

            if (delim == -1) {
                command = queryString;
                param = "";
            } else {
                command = queryString.substring(0, delim);
                param = queryString.substring(delim + 1);
            }

            if (command.equalsIgnoreCase("forward")) {
                try {
                    LoggingServletForwardCommand.execute(req, res, param);
                } catch (ServletClientException e) {
                    returnClientError(res, "client error: " + e.getMessage());
                    e.printStackTrace();
                } catch (ServletServerException e) {
                    returnServerError(res, "internal server error: " + e.getMessage());
                    e.printStackTrace();
                }
            } else {
                returnClientError(res, "invalid command: " + command);
            }
        } catch (Exception e) {
            returnServerError(res, "internal error: " + e.getMessage());
            e.printStackTrace();
        }
    }

    public void doGet(HttpServletRequest req, HttpServletResponse res)
        throws ServletException, IOException {
        returnClientError(res, "GET Operation not supported: " + "Can only forward POST requests.");
    }

    public void doPut(HttpServletRequest req, HttpServletResponse res)
        throws ServletException, IOException {
        returnClientError(res, "PUT Operation not supported: " + "Can only forward POST requests.");
    }

    public String getServletInfo() {
        return "RMI Call Forwarding Servlet Servlet.<br>\n";
    }

    private static void returnClientError(HttpServletResponse res, String message)
        throws IOException {
	
        res.sendError(HttpServletResponse.SC_BAD_REQUEST,
            "<HTML><HEAD>" +
            "<TITLE>Java RMI Client Error</TITLE>" +
            "</HEAD>" +
            "<BODY>" +
            "<H1>Java RMI Client Error</H1>" +
            message +
            "</BODY></HTML>");

        System.err.println(HttpServletResponse.SC_BAD_REQUEST +
            "Java RMI Client Error" + message);
    }
    
    private static void returnServerError(HttpServletResponse res, String message)
        throws IOException {
	
        res.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR,
            "<HTML><HEAD>" +
            "<TITLE>Java RMI Server Error</TITLE>" +
            "</HEAD>" +
            "<BODY>" +
            "<H1>Java RMI Server Error</H1>" +
            message +
            "</BODY></HTML>");

        System.err.println(HttpServletResponse.SC_INTERNAL_SERVER_ERROR +
            "Java RMI Server Error: " + message);
    }

}
