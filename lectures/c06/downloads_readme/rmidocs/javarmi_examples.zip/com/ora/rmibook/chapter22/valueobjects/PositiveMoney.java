package com.ora.rmibook.chapter22.valueobjects;


public class PositiveMoney extends Money {
    public PositiveMoney(Integer cents) throws Exception {
        this (cents.intValue());
    }

    public PositiveMoney(int cents) throws Exception {
        super (cents);
        if (_cents <= 0) {
            throw new Exception("Bad Value for Money");
        }
        return;
    }
}
