package com.ora.rmibook.chapter23.corbaaccounts;


public class Account_Impl extends _AccountImplBase {
    private Money _balance;
    public Account_Impl(Money startingBalance) {
        _balance = startingBalance;
    }

    public Money getBalance() {
        return _balance;
    }

    public void makeDeposit(Money amount) throws NegativeAmountException {
        checkForNegativeAmount(amount);
        _balance.cents += amount.cents;
        return;
    }

    public void makeWithdrawal(Money amount) throws NegativeAmountException, OverdraftException {
        checkForNegativeAmount(amount);
        checkForOverdraft(amount);
        _balance.cents -= amount.cents;
        return;
    }

    private void checkForNegativeAmount(Money amount)  throws  NegativeAmountException {
        int cents = amount.cents;

        if (0 > cents) {
            throw new NegativeAmountException();
        }
    }

    private void checkForOverdraft(Money amount) throws OverdraftException {
        if (amount.cents > _balance.cents) {
            throw new OverdraftException();
        }
        return;
    }
}
