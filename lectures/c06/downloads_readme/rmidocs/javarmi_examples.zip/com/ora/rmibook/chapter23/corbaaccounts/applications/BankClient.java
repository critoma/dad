package com.ora.rmibook.chapter23.corbaaccounts.applications;


public class BankClient {
    public static void main(String[] args) {
        (new BankClientFrame()).show();
    }
}
