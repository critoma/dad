package com.ora.rmibook.chapter23.corbaaccounts.applications;


import com.ora.rmibook.chapter23.corbaaccounts.*;
import java.util.*;
import org.omg.CosNaming.NamingContextPackage.*;
import org.omg.CosNaming.*;
import org.omg.CORBA.*;


/*
 This is one way to bootstrap a project.
 */


public class OrbSetup {
    private static Properties _properties;
    private static Properties getProperties() {
        if (null == _properties) {
            _properties = new Properties();
            _properties.put("org.omg.CORBA.ORBInitialPort", "3500");
            _properties.put("org.omg.CORBA.ORBInitialHost", "localhost");
            //			_properties.put("org.omg.CORBA.ORBClass", "com.sun.CORBA.iiop.ORB");
        }
        return _properties;
    }

    public static Account getAccount(String name) {
        try {
            Properties properties = OrbSetup.getProperties();
            ORB orb = ORB.init((String[]) null, properties);
            org.omg.CORBA.Object objRef = orb.resolve_initial_references("NameService");
            NamingContext nameServer = NamingContextHelper.narrow(objRef);
      
            NameComponent ourComponent = new NameComponent(name, "");
            NameComponent path[] = {ourComponent};
            org.omg.CORBA.Object accountRef = nameServer.resolve(path);

            return AccountHelper.narrow(accountRef);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public static void bindAccountServer(String name, Account server) throws Exception {
        Properties properties = OrbSetup.getProperties();
        ORB orb = ORB.init((String[]) null, properties);

        orb.connect(server); // This is pretty much a JavaIDL hack
        // JavaIDL doesn't really support servers well
      
        org.omg.CORBA.Object objRef = orb.resolve_initial_references("NameService");
        NamingContext nameServer = NamingContextHelper.narrow(objRef);
      
        NameComponent ourComponent = new NameComponent(name, "");
        NameComponent path[] = {ourComponent};

        nameServer.rebind(path, server);
    }
}
