package com.ora.rmibook.chapter23.rmiiiopaccounts;


public class NegativeAmountException extends Exception {
} 
