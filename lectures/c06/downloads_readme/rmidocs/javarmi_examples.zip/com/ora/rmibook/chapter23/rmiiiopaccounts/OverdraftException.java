package com.ora.rmibook.chapter23.rmiiiopaccounts;


public class OverdraftException extends Exception {
    public boolean _withdrawalSucceeded;
    public OverdraftException(boolean withdrawalSucceeded) {
        _withdrawalSucceeded = withdrawalSucceeded;
    }

    public boolean isWithdrawalSucceeded() {
        return _withdrawalSucceeded;
    }
}
