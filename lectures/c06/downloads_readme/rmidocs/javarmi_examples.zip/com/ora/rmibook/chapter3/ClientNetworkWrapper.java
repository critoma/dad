package com.ora.rmibook.chapter3;


import java.io.*;
import java.net.*;


public class ClientNetworkWrapper extends NetworkBaseClass implements PrinterConstants {
    private String _serverMachine;
    private int _serverPort;
    public ClientNetworkWrapper() {
        this (DEFAULT_SERVER_NAME, DEFAULT_SERVER_PORT);
    }

    public ClientNetworkWrapper(String serverMachine, int serverPort) {
        _serverMachine = serverMachine;
        _serverPort = serverPort;
    }

    public void sendDocumentToPrinter(InputStream actualDocument)
        throws ConnectionException, PrinterException {
        sendDocumentToPrinter(actualDocument, DEFAULT_DOCUMENT_TYPE,
            DEFAULT_PRINT_TWO_SIDED, DEFAULT_PRINT_QUALITY);
    }

    public void sendDocumentToPrinter(InputStream actualDocument,
        int documentType, boolean printTwoSided, int printQuality)
        throws ConnectionException, PrinterException {
        DocumentDescription documentToSend;

        try {
            documentToSend = new DocumentDescription(actualDocument, documentType, printTwoSided, printQuality);
        } catch (IOException e) {
            throw new ConnectionException();
        }
        sendDocumentToPrinter(documentToSend);
    }

    public void sendDocumentToPrinter(DocumentDescription documentDescription)
        throws ConnectionException, PrinterException {
        Socket connection = null;

        try {
            connection = new Socket(_serverMachine, _serverPort);
            documentDescription.writeToStream(connection.getOutputStream());
            readStatusFromSocket(connection);
        } catch (IOException e) {
            e.printStackTrace();
            throw new ConnectionException();
        }
        closeSocket(connection);
    }

    private void readStatusFromSocket(Socket connection)
        throws PrinterException, IOException {
        InputStream inputStream = connection.getInputStream();
        DataInputStream dataInputStream = new DataInputStream(inputStream);
        BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
        boolean response = dataInputStream.readBoolean();

        if (response) {
            return;
        }
        PrinterException error = new PrinterException(inputStream);

        throw error;
    }
} 

