package com.ora.rmibook.chapter3;


public class ConnectionException extends Exception {
}
