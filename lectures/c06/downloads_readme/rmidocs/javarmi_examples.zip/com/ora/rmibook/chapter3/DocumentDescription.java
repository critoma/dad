package com.ora.rmibook.chapter3;


import java.io.*;	// needed for stream definitions


/*
 The stream methods in this class all use buffers for efficiency.
 There's nothing worse than reading or writing to a device one
 byte at a time.
 */

public class DocumentDescription {
    private DataInputStream _actualDocument;
    private int _documentType;
    private boolean _printTwoSided;
    private int _printQuality;
    private int _length;

    public DocumentDescription(InputStream source)
        throws IOException {
        readFromStream(source);
    }

    public DocumentDescription(InputStream actualDocument,
        int documentType, boolean printTwoSided, int printQuality)
        throws IOException {
        _documentType = documentType;
        _printTwoSided = printTwoSided;
        _printQuality = printQuality;
        BufferedInputStream buffer = new BufferedInputStream(actualDocument);
        DataInputStream dataInputStream = new DataInputStream(buffer);
        ByteArrayOutputStream temporaryBuffer = new ByteArrayOutputStream();

        _length = copy(dataInputStream, new DataOutputStream(temporaryBuffer));
        _actualDocument = new DataInputStream(new ByteArrayInputStream(temporaryBuffer.toByteArray()));
    }

    public DocumentDescription(InputStream actualDocument,
        int documentType, boolean printTwoSided, int printQuality,
        int length) {
        _actualDocument = new DataInputStream(actualDocument);
        _documentType = documentType;
        _printTwoSided = printTwoSided;
        _printQuality = printQuality;
        _length = length;
    }

    public int getLength() {
        return _length;
    }

    public int getDocumentType() {
        return _documentType;
    }

    public boolean isPrintTwoSided() {
        return _printTwoSided;
    }

    public int getPrintQuality() {
        return _printQuality;
    }

    public void writeToStream(OutputStream outputStream)
        throws IOException {
        BufferedOutputStream buffer = new BufferedOutputStream(outputStream);
        DataOutputStream dataOutputStream = new DataOutputStream(buffer);

        writeMetadataToStream(dataOutputStream);
        copy(_actualDocument, dataOutputStream, _length);
    }

    public void readFromStream(InputStream inputStream)
        throws IOException {
        BufferedInputStream buffer = new BufferedInputStream(inputStream);
        DataInputStream dataInputStream = new DataInputStream(buffer);

        readMetadataFromStream(dataInputStream);
        ByteArrayOutputStream temporaryBuffer = new ByteArrayOutputStream();

        copy(dataInputStream, new DataOutputStream(temporaryBuffer), _length);
        _actualDocument = new DataInputStream(new ByteArrayInputStream(temporaryBuffer.toByteArray()));
    }

    private void writeMetadataToStream(DataOutputStream dataOutputStream)
        throws IOException {
        dataOutputStream.writeInt(_documentType);
        dataOutputStream.writeBoolean(_printTwoSided);
        dataOutputStream.writeInt(_printQuality);
        dataOutputStream.writeInt(_length);
    }

    private void readMetadataFromStream(DataInputStream dataInputStream)
        throws IOException {
        _documentType = dataInputStream.readInt();
        _printTwoSided = dataInputStream.readBoolean();
        _printQuality = dataInputStream.readInt();
        _length = dataInputStream.readInt();
    }

    private void copy(InputStream source, OutputStream destination, int length)
        throws IOException {
        int counter;
        int nextByte;

        for (counter = 0; counter < length; counter++) {
            nextByte = source.read();
            destination.write(nextByte);
        }
        destination.flush();
    }

    private int copy(InputStream source, OutputStream destination)
        throws IOException {
        int nextByte;
        int numberOfBytesCopied = 0;

        while (-1 != (nextByte = source.read())) {
            destination.write(nextByte);
            numberOfBytesCopied++;
        }
        destination.flush();
        return numberOfBytesCopied;
    }
}
