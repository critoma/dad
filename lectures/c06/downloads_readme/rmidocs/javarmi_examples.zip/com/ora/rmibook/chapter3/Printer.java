package com.ora.rmibook.chapter3;


public interface Printer extends PrinterConstants {
    public boolean printerAvailable();
    public boolean printDocument(DocumentDescription document)
        throws PrinterException;
}
