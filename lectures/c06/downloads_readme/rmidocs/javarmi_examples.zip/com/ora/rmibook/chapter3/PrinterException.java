package com.ora.rmibook.chapter3;


import java.io.*;


public class PrinterException extends Exception {
    private int _numberOfPagesPrinted;
    private String _humanReadableErrorDescription;

    public PrinterException(InputStream inputStream)
        throws IOException {
        DataInputStream dataInputStream = new DataInputStream(inputStream);

        _humanReadableErrorDescription = dataInputStream.readUTF();
        _numberOfPagesPrinted = dataInputStream.readInt();
    }

    public PrinterException(int numberOfPagesPrinted,
        String humanReadableErrorDescription) {
        _numberOfPagesPrinted = numberOfPagesPrinted;
        _humanReadableErrorDescription = humanReadableErrorDescription;
    }

    public int getNumberOfPagesPrinted() {
        return _numberOfPagesPrinted;
    }

    public String getHumanReadableErrorDescription() {
        return _humanReadableErrorDescription;
    }

    public void writeToStream(OutputStream outputStream)
        throws IOException {
        DataOutputStream dataOutputStream = new DataOutputStream(outputStream);

        writeToStream(dataOutputStream);
    }

    public void writeToStream(DataOutputStream dataOutputStream)
        throws IOException {
        dataOutputStream.writeUTF(_humanReadableErrorDescription);
        dataOutputStream.writeInt(_numberOfPagesPrinted);
    }
} 

