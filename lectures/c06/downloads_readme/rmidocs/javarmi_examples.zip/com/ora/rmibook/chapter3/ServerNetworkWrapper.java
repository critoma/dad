package com.ora.rmibook.chapter3;


import java.net.*;
import java.io.*;


public class ServerNetworkWrapper extends NetworkBaseClass {
    private Printer _printer;
    private int _port;
    private ServerSocket _serverSocket;
    public ServerNetworkWrapper(Printer printer)
        throws IOException {
        this (printer, DEFAULT_SERVER_PORT, DEFAULT_SERVER_BACKLOG);
    }

    public ServerNetworkWrapper(Printer printer, int port, int backlog)
        throws IOException {
        _serverSocket = new ServerSocket(port, backlog);
        _printer = printer;
    }

    public void accept() {
        while (true) {
            Socket clientSocket = null;

            try {
                clientSocket = _serverSocket.accept();	// blocking call
                processPrintRequest(clientSocket);
            } catch (IOException e) {
                e.printStackTrace();
            }
            closeSocket(clientSocket);
        }
    }

    private void processPrintRequest(Socket clientSocket) {
        InputStream clientRequestStream;
        OutputStream clientResponseStream;
        DataOutputStream dataOutputStream;
        DocumentDescription documentToPrint;

        try {
            clientRequestStream = clientSocket.getInputStream();
            clientResponseStream = clientSocket.getOutputStream();
            dataOutputStream = new DataOutputStream(clientResponseStream);
            documentToPrint = new DocumentDescription(clientRequestStream);
        } catch (IOException e) {
            e.printStackTrace();
            return;
        }
        try {
            try {
                _printer.printDocument(documentToPrint);
                dataOutputStream.writeBoolean(true);
            } catch (PrinterException printerError) {
                dataOutputStream.writeBoolean(false);
                printerError.writeToStream(dataOutputStream);
            }
        } catch (IOException ee) {
            ee.printStackTrace();
        }
    }
}
