package com.ora.rmibook.chapter3.applications;


public class SimpleClient {
    public static void main(String[] args) {
        (new SimpleClientFrame()).show();
    }
} 

