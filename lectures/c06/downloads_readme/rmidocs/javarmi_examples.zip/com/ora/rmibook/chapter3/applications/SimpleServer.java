package com.ora.rmibook.chapter3.applications;


import com.ora.rmibook.chapter3.printers.*;
import com.ora.rmibook.chapter3.*;
import java.io.*;


public class SimpleServer {
    public static void main(String args[]) {
        try {
            File logfile = new File("C:\\temp\\serverLogfile");
            OutputStream outputStream = new FileOutputStream(logfile);
            Printer printer = new NullPrinter(outputStream);
            ServerNetworkWrapper serverNetworkWrapper = new ServerNetworkWrapper(printer);

            serverNetworkWrapper.accept();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
} 

