package com.ora.rmibook.chapter4;


public interface NetworkConstants {
    public static final String DEFAULT_PRINTER_NAME = "Default Printer";
}
