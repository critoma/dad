package com.ora.rmibook.chapter4.applications;


import java.rmi.*;


public class SimpleClient {
    public static void main(String[] args) {
        System.setSecurityManager(new RMISecurityManager());
        (new SimpleClientFrame()).show();
    }
} 

