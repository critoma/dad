package com.ora.rmibook.chapter4.applications;


import com.ora.rmibook.chapter4.printers.*;
import com.ora.rmibook.chapter4.*;
import java.io.*;
import java.rmi.*;
import java.rmi.server.*;


public class SimpleServer implements NetworkConstants {
    public static void main(String args[]) {
        try {
            File logfile = new File("C:\\temp\\serverLogfile");
            OutputStream outputStream = new FileOutputStream(logfile);
            Printer printer = new NullPrinter(outputStream);

            Naming.rebind(DEFAULT_PRINTER_NAME, printer);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
} 

