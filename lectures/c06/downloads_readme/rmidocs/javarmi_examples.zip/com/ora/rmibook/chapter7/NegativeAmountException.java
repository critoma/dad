package com.ora.rmibook.chapter7;


public class NegativeAmountException extends Exception {
} 
