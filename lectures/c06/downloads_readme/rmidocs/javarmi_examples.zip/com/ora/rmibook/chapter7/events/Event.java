package com.ora.rmibook.chapter7.events;


import java.io.*;
import java.util.*;


public abstract class Event implements Serializable {
    public int uniqueID;
    public String name;
    public Date occurredOn;
    public Date expirationDate;
}
