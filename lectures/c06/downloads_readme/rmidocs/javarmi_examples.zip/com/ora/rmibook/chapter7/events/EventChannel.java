package com.ora.rmibook.chapter7.events;


import java.rmi.*;


public interface EventChannel extends Remote {
    public static final int MAX_PRIORITY = 100;
    public static final int LEAST_PRIORITY = 0;

    public void addListener(EventListener listener) throws RemoteException;
    public void removeListener(EventListener listener) throws RemoteException;

    public void addListenerForEventType(EventListener eventListener,
        Class EventType) throws RemoteException;
    public void removeListenerForEventType(EventListener eventListener,
        Class EventType) throws RemoteException;

    public void setDefaultPriorityForEventType(Class EventType,
        int defaultPriority) throws RemoteException;
    public void announceEvent(Event event, int priority) throws RemoteException;
    public void announceEvent(Event event) throws RemoteException;

    public void enableLogging(boolean logEvents) throws RemoteException;
    public void automaticallyExpireEvents(boolean checkExpirationsBeforeSending)
        throws RemoteException;

    public void stopAcceptingEvents() throws RemoteException;
    public void resumeAcceptingEvents() throws RemoteException;
    public void clearEventQueue() throws RemoteException;

    public void stopBroadcastingEvents() throws RemoteException;
    public void resumeBroadcastingEvents() throws RemoteException;
}
