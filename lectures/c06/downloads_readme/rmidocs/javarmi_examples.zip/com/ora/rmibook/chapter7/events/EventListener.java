package com.ora.rmibook.chapter7.events;


import java.rmi.*;


public interface EventListener extends Remote {
    public void remoteEventOccured(Event event) throws RemoteException;
}
