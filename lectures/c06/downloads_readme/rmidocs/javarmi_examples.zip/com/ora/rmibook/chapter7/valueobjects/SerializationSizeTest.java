
package com.ora.rmibook.chapter7.valueobjects;


import java.io.*;


public class SerializationSizeTest {
    public static void main(String[] args) {
        (new SerializationSizeTestFrame()).show();
    }
} 

