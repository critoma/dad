/*
 A simple class designed to illustrate the size difference
 between a Money and the two ints that constitute its
 real state. 
 */

package com.ora.rmibook.chapter7.valueobjects;


import com.ora.rmibook.gui.*;
import javax.swing.*;
import java.awt.*;
import java.io.*;


public class SerializationSizeTestFrame extends ExitingFrame {
    public SerializationSizeTestFrame() {
    }

    protected void buildGUI() {
        JPanel contentPane = new JPanel(new BorderLayout());
        JTextArea center = new JTextArea();

        center.setText("The first serialized copy of Money is " + computeSizeOfMoney()
            + " bytes long. \n The second is only " + computeSizeOfSecondMoney()
            + " bytes long. \n Two ints only consume " + +computeSizeOfTwoInts());
        contentPane.add(center, BorderLayout.CENTER);
        setContentPane(contentPane);
        setSize(300, 100);
    }

    private int computeSizeOfMoney() {
        ByteArrayOutputStream resultStream;

        resultStream = new ByteArrayOutputStream();
        try {
            ObjectOutputStream objectOutputStream = new sun.rmi.server.MarshalOutputStream(resultStream);
            Money money = new Money(50);

            objectOutputStream.writeObject(money);
            objectOutputStream.flush();
            return resultStream.size();
        } catch (Exception e) {
        }
        return 0;
    }

    private int computeSizeOfSecondMoney() {
        ByteArrayOutputStream resultStream;

        resultStream = new ByteArrayOutputStream();
        try {
            ObjectOutputStream objectOutputStream = new sun.rmi.server.MarshalOutputStream(resultStream);
            Money money = new Money(50);
            Money money2 = new Money(510);

            objectOutputStream.writeObject(money);
            objectOutputStream.flush();
            int intermediateSize = resultStream.size();

            objectOutputStream.writeObject(money2);
            objectOutputStream.flush();
            return resultStream.size() - intermediateSize;
        } catch (Exception e) {
        }
        return 0;
    }

    private int computeSizeOfTwoInts() {
        ByteArrayOutputStream resultStream;

        resultStream = new ByteArrayOutputStream();
        try {
            ObjectOutputStream objectOutputStream = new sun.rmi.server.MarshalOutputStream(resultStream);

            objectOutputStream.writeInt(50);
            objectOutputStream.writeInt(50);
            objectOutputStream.flush();
            return resultStream.size();
        } catch (Exception e) {
        }
        return 0;
    }
}
