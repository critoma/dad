/*
 The only difference between this and Account_Impl is that
 Account_Impl extends UnicastRemote.
 */
package com.ora.rmibook.chapter8;


import com.ora.rmibook.chapter8.valueobjects.*;
import java.rmi.*;
import java.rmi.server.*;


public class Account_Impl2 implements Account {
    private Money _balance;
    public Account_Impl2(Money startingBalance)
        throws RemoteException {
        _balance = startingBalance;
    }

    public Money getBalance()
        throws RemoteException {
        return _balance;
    }

    public void makeDeposit(Money amount)
        throws RemoteException, NegativeAmountException {
        checkForNegativeAmount(amount);
        _balance.add(amount);
        return;
    }

    public void makeWithdrawal(Money amount)
        throws RemoteException, OverdraftException, NegativeAmountException {
        checkForNegativeAmount(amount);
        checkForOverdraft(amount);
        _balance.subtract(amount);
        return;
    }

    public boolean equals(Object object) {
        // three cases. Either it's us, or it's our stub, or it's
        // not equal.

        if (object instanceof Account_Impl2) {
            return (object == this);
        }
        if (object instanceof RemoteStub) {
            try {
                RemoteStub ourStub = (RemoteStub) RemoteObject.toStub(this);

                return ourStub.equals(object);
            } catch (NoSuchObjectException e) {
                // we're not listening on a port, therefore it's not our
                // stub
            }
        }
        return false;
    }

    public int hashCode() {
        try {
            Remote ourStub = RemoteObject.toStub(this);

            return ourStub.hashCode();
        } catch (NoSuchObjectException e) {
        }
        return super.hashCode();
    }
    
    private void checkForNegativeAmount(Money amount)
        throws NegativeAmountException {
        int cents = amount.getCents();

        if (0 > cents) {
            throw new NegativeAmountException();
        }
    }

    private void checkForOverdraft(Money amount)
        throws OverdraftException {
        if (amount.greaterThan(_balance)) {
            throw new OverdraftException(false);
        }
        return;
    }
} 

