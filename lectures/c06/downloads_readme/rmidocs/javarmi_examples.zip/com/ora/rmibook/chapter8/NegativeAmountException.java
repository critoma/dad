package com.ora.rmibook.chapter8;


public class NegativeAmountException extends Exception {
} 
