package com.ora.rmibook.chapter8.stuckconstructor;


import java.rmi.*;


public interface Ping extends Remote {
    public void ping() throws RemoteException;
}
