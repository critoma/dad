package com.ora.rmibook.chapter8.stuckconstructor;


public class PingClient {
    public static void main(String[] args) {
        (new PingClientFrame()).show();
    }
}
