package com.ora.rmibook.chapter8.stuckconstructor;


import java.rmi.*;
import java.rmi.server.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import com.ora.rmibook.gui.*;
import java.io.*;


public class PingClientFrame extends ExitingFrame {
    protected void buildGUI() {
        JPanel contentPane = new JPanel(new BorderLayout());
        JButton pingButton = new JButton("Ping!");

        pingButton.addActionListener(new PingListener());
        contentPane.add(pingButton, BorderLayout.CENTER);
        setContentPane(contentPane);
        setSize(250, 100);
    }

    private Ping getStub() {
        Ping returnValue = null;

        try {
            FileInputStream file = new FileInputStream("C:\\temp\\ping_stub");
            ObjectInputStream objectInputStream = new ObjectInputStream(file);

            returnValue = (Ping) objectInputStream.readObject();
        } catch (Exception e) {
            System.out.println("Error reading stub from file");
            e.printStackTrace();
        }
        return returnValue;
    }
    
    private class PingListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            try {
                Ping pingServer = getStub();

                pingServer.ping();
            } catch (Exception ee) {
                System.out.println("Error talking to ping server. Error was \n " + ee);
                ee.printStackTrace();
            }
            return;
        }
    }
}
