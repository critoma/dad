package com.ora.rmibook.chapter8.stuckconstructor;


public class PingLauncher {
    public static void main(String[] args) {
        try {
            PingServer pingServer = new PingServer();
        } catch (Exception e) {
        }
    }

}
