package com.ora.rmibook.chapter8.stuckconstructor;


import java.rmi.*;
import java.rmi.server.*;
import java.io.*;


public class PingServer extends UnicastRemoteObject implements Ping {
    public PingServer() throws RemoteException {
        super (10000); 	// our well-known port.
        storeStubInTempDirectory();
        while (true) {
            try {
                Thread.sleep(5000);
            } catch (Exception e) {
            }
        }
    }

    public void ping() throws RemoteException {
        System.out.println("Ping!");
    }

    private void storeStubInTempDirectory() {
        try {
            RemoteStub stub = (RemoteStub) toStub(this);
            FileOutputStream file = new FileOutputStream("C:\\temp\\ping_stub");
            ObjectOutputStream objectOutputStream = new ObjectOutputStream(file);

            objectOutputStream.writeObject(stub);
            objectOutputStream.close();
        } catch (Exception e) {
            System.out.println("Error writing stub to file");
            e.printStackTrace();
        }
    }
} 

