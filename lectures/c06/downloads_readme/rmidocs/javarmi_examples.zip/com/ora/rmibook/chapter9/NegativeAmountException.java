package com.ora.rmibook.chapter9;


public class NegativeAmountException extends Exception {
} 
