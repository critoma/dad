package com.ora.rmibook.chapter9.applications;


import com.ora.rmibook.chapter9.*;
import com.ora.rmibook.chapter9.valueobjects.*;
import java.util.*;
import java.rmi.*;


public class ImplLauncher {
    public static void main(String[] args) {
        Collection nameBalancePairs = getNameBalancePairs(args);
        Iterator i = nameBalancePairs.iterator();

        while (i.hasNext()) {
            NameBalancePair nextNameBalancePair = (NameBalancePair) i.next();

            launchServer(nextNameBalancePair);
        }
    }

    private static void launchServer(NameBalancePair serverDescription) {
        try {
            Account_Impl newAccount = new Account_Impl(serverDescription.balance);

            Naming.rebind(serverDescription.name, newAccount);
            System.out.println("Account " + serverDescription.name + " successfully launched.");
        } catch (Exception e) {
        }
    }

    private static Collection getNameBalancePairs(String[] args) {
        int i;
        ArrayList returnValue = new ArrayList();

        for (i = 0; i < args.length; i += 2) {
            NameBalancePair nextNameBalancePair = new NameBalancePair();

            nextNameBalancePair.name = args[i];
            int cents = (new Integer(args[i + 1])).intValue();

            nextNameBalancePair.balance = new Money(cents);
            returnValue.add(nextNameBalancePair);
        }
        return returnValue;
    }

    private static class NameBalancePair {
        String name;
        Money balance;
    }
}
