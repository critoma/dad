export NODE_HOME=/opt/software/node-v16.14.0-darwin-x64 
export PATH=.:$NODE_HOME/bin:$PATH

node --version
npm --version

npm ls

npm install websocket

node ./websocket/websocket.js &
node serverhttp.js

# wireshark:
# http://127.0.0.1:3000/websocket/websocketHTML5.html
# http://127.0.0.1:3000/jsframeworks/angular/helloAngular1.html
# http://127.0.0.1:3000/jsframeworks/react/react01.html
# http://127.0.0.1:3000/jsframeworks/vuejs/vue03.html