var http=require('http');
var options = { 
    hostname: '127.0.0.1',
    port: '4000',
    path: '/',
    method: 'GET',
    headers: {'Cookie': 'connect.sid=s%3Au17Dho6jWlVkpwUu4UsNl07oN1av9CAo.xghdDlIjZ2mjHMnDq1mTerbSdErBT3JI8ozqg3sI%2BU0', },
};
var results = ''; 
var req = http.request(options, function(res) {
    res.on('data', function (chunk) {
        results = results + chunk;
        console.log(results);
    }); 
    res.on('end', function () {
        console.log('end response result');
    }); 
});

req.on('error', function(e) {
        console.log('error: ' + e);
});

req.end();