package eu.ase.ejb2.sesmdb;

import javax.ejb.*;
import java.rmi.RemoteException;

/**
 * Remote interface for Publisher enterprise bean. Declares one business method.
 */
public interface Publisher extends EJBObject {
    void publishNews() throws RemoteException;
}
