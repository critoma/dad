package eu.ase.ejb2.sesmdb;

import java.rmi.RemoteException; 
import java.util.*;
import javax.ejb.*;
import javax.naming.*;
import javax.jms.*;

/**
 * Bean class for Publisher enterprise bean. Defines publishNews
 * business method as well as required methods for a stateless
 * session bean.
 */
public class PublisherBean implements SessionBean {
    SessionContext      sc = null;
    TopicConnection     topicConnection = null;
    Topic               topic = null;
    final static String messageTypes[] = {"Nation/World", "Metro/Region", "Business", "Sports", "Living/Arts", "Opinion"};

    public PublisherBean() {
        System.out.println("In PublisherBean() (constructor)");
    }

    /**
     * Sets the associated session context. The container calls 
     * this method after the instance creation.
     */
    public void setSessionContext(SessionContext sc) {
        this.sc = sc;
    }

    /**
     * Instantiates the enterprise bean.  Creates the 
     * TopicConnection and looks up the topic.
     */
    public void ejbCreate() {
        Context context = null;
        TopicConnectionFactory topicConnectionFactory = null;

        System.out.println("In PublisherBean.ejbCreate()");
        try {
		//please have jndi.properties file in your classpath
            context = new InitialContext();

            // Create a TopicConnection
            topicConnectionFactory = (TopicConnectionFactory) context.lookup("ConnectionFactory");
            topicConnection = topicConnectionFactory.createTopicConnection();

            topic = (Topic)context.lookup("topic/testTopic");
        } catch (Throwable t) {
            // JMSException or NamingException could be thrown
            System.err.println("PublisherBean.ejbCreate: Exception: " + t.toString());
        }
    }

    /**
     * Chooses a message type by using the random number
     * generator found in java.util.  Called by publishNews().
     *
     * @return   the String representing the message type
     */
    private String chooseType() {
        int    whichMsg;
        Random rgen = new Random();
       
        whichMsg = rgen.nextInt(messageTypes.length);
        return messageTypes[whichMsg];
    }

    /**
     * Creates TopicSession, publisher, and message.  Publishes 
     * messages after setting their NewsType property and using
     * the property value as the message text. Messages are
     * received by MessageBean, a message-driven bean that uses a
     * message selector to retrieve messages whose NewsType
     * property has certain values.
     */
    public void publishNews() throws EJBException {
        TopicSession   topicSession = null;
        TopicPublisher topicPublisher = null;
        TextMessage    message = null;
        int            numMsgs = messageTypes.length * 3;
        String         messageType = null;

        try {
		//pay attention to transactioned publishing
            topicSession = topicConnection.createTopicSession(false, TopicSession.AUTO_ACKNOWLEDGE);
            topicPublisher = topicSession.createPublisher(topic);

            message = topicSession.createTextMessage();
            for (int i = 0; i < numMsgs; i++) {
                messageType = chooseType();
                message.setStringProperty("NewsType", messageType);
                message.setText("Item " + i + ": " + messageType);
                System.out.println("PUBLISHER: Setting " + "message text to: " + message.getText());
                topicPublisher.publish(message);
            }
        } catch (Throwable t) {
            // JMSException could be thrown
            System.err.println("PublisherBean.publishNews: " + "Exception: " + t.toString());
		//container managed transactions
            sc.setRollbackOnly();
        } finally {
            if (topicSession != null) {
                try {
                    topicSession.close();
                } catch (JMSException e) {}
            }
        }
    }

    /**
     * Closes the TopicConnection.
     */
    public void ejbRemove() throws RemoteException {
        System.out.println("In PublisherBean.ejbRemove()");
        if (topicConnection != null) {
            try {
                topicConnection.close();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    public void ejbActivate() {}
    public void ejbPassivate() {}
}
