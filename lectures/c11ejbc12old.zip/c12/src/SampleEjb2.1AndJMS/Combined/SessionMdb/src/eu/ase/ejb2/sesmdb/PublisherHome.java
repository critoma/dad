package eu.ase.ejb2.sesmdb;

import java.rmi.RemoteException;
import javax.ejb.EJBHome;
import javax.ejb.CreateException;

/**
 * Home interface for Publisher enterprise bean.
 */
public interface PublisherHome extends EJBHome {
    Publisher create() throws RemoteException, CreateException;
}
