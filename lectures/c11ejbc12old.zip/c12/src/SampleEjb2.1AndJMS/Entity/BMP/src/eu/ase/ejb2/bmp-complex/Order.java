package eu.ase.ejb2.bmp;

import javax.ejb.EJBObject;
import java.rmi.RemoteException;
import java.util.*;


public interface Order extends EJBObject {
    public ArrayList getLineItems() throws RemoteException;

    public String getCustomerId() throws RemoteException;

    public double getTotalPrice() throws RemoteException;

    public String getStatus() throws RemoteException;
}
