package eu.ase.ejb2.bmp;

import java.util.*;
import java.rmi.RemoteException;
import javax.ejb.*;


public interface OrderHome extends EJBHome {
    public Order create(String orderId, String customerId, String status,
        double totalPrice, ArrayList lineItems)
        throws RemoteException, CreateException;

    public Order findByPrimaryKey(String orderId)
        throws FinderException, RemoteException;

    public Collection findByProductId(String productId)
        throws FinderException, RemoteException;
}
