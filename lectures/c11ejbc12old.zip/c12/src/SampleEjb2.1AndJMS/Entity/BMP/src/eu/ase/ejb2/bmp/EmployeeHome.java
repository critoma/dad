// EmployeeHome.java

package eu.ase.ejb2.bmp;

import java.rmi.*;
import java.util.*;
import javax.ejb.*;

public interface EmployeeHome extends EJBHome
{
   public Employee create(Integer empNo, String empName, Float salary) throws CreateException, RemoteException;

   public Employee findByPrimaryKey(EmployeePK pk) throws FinderException, RemoteException;

   public Collection findByName(String empName) throws FinderException, RemoteException;

   public Collection findAll() throws FinderException, RemoteException;

   //we must put utility methods here for creating and droping table because
   //we can not create bean and then call creating table; the table must be created by the client
   //or db client utility before ejbCreate/create...also pay attention to RemoteException which is not included in implementation
   public void makeDbTable() throws RemoteException;
   public void deleteDbTable() throws RemoteException;

}
