// EmployeePK.java

package eu.ase.ejb2.bmp;

public class EmployeePK implements java.io.Serializable {
public Integer empNo;
public String empName;
public Float salary;

public EmployeePK() {
  this.empNo = null;
  this.empName = null;
  this.salary = null;
}
	
public EmployeePK(Integer empNo) {
  this.empNo = empNo;
  this.empName = null;
  this.salary = null;
}

public EmployeePK(Integer empNo, String empName, Float salary) {
  this.empNo = empNo;
  this.empName = empName;
  this.salary = salary;
}

public int hashCode() {
  return (empName.concat(empNo.toString())).concat(salary.toString()).hashCode();
}

public boolean equals(Object other) {
  if (other instanceof EmployeePK) 
    return ((((EmployeePK)other).empNo.equals(empNo)) &&
	    (((EmployeePK)other).empName.equals(empName)) &&
	    ((EmployeePK)other).salary.equals(salary));
    return false;
}

}
