// EmployeePK.java

package eu.ase.ejb2.cmp;

public class EmployeePK implements java.io.Serializable {

  public Integer empNo;

  public EmployeePK()
  {
    this.empNo = null;
  }
	
  public EmployeePK(Integer empNo)
  {
    this.empNo = empNo;
  }

  public int hashCode() {
    return empNo.hashCode();
  }

  public boolean equals(Object other) {
    if (other instanceof EmployeePK) 
      return ((EmployeePK)other).empNo.equals(empNo);
    return false;
  }

}
