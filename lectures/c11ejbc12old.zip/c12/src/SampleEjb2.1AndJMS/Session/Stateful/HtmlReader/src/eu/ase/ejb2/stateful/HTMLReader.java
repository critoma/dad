package eu.ase.ejb2.stateful;

import javax.ejb.EJBObject;
import java.rmi.RemoteException;


public interface HTMLReader extends EJBObject {
    public StringBuffer getContents(String friendlyName) throws RemoteException, HTTPResponseException;
}
