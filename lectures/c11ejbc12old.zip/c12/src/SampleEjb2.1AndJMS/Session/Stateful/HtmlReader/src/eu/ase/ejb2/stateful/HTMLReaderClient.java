package eu.ase.ejb2.stateful;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.rmi.PortableRemoteObject;

public class HTMLReaderClient {
    public static void main(String[] args) {
        try {
            Context initial = new InitialContext();
            Object objref = initial.lookup("ejb/JNDIHtmlReaderBean");

            HTMLReaderHome home = (HTMLReaderHome) PortableRemoteObject.narrow(objref, HTMLReaderHome.class);

            HTMLReader htmlReader = home.create();

	    StringBuffer contents = null;
	    long before = 0, after = 0;

	    for(int i = 0; i < args.length; i++) {
		before = System.currentTimeMillis();
		contents = htmlReader.getContents(args[i]);
		after = System.currentTimeMillis();

		System.out.println("\n The contents "+i+" of the HTML page in "+(after-before)+" miliseconds is:\n");
            	System.out.print(contents);		
	    }
            System.exit(0);
        } catch (Exception ex) {
            System.err.println("Caught an unexpected exception!");
            ex.printStackTrace();
        }
    }
}
