package eu.ase.clientejb2;

import eu.ase.ejb2.Converter;
import eu.ase.ejb2.ConverterHome;
import javax.naming.Context;
import javax.naming.InitialContext;
import javax.rmi.PortableRemoteObject;
import java.math.BigDecimal;
import java.util.Hashtable;


public class ConverterClient {
    public static void main(String[] args) {
        try {
		Hashtable<String,String> env = new Hashtable<String,String>();
		env.put(Context.INITIAL_CONTEXT_FACTORY,"org.jnp.interfaces.NamingContextFactory");
		///env.put(Context.INITIAL_CONTEXT_FACTORY,"org.jboss.naming.NamingContextFactory");
		env.put(Context.PROVIDER_URL,"jnp://127.0.0.1:1099");
		env.put(Context.URL_PKG_PREFIXES, "org.jboss.naming:org.jnp.interfaces" );

            Context ctx = new InitialContext(env);
		//Context ctx = new InitialContext();
      	//ConverterHome home = (ConverterHome)ctx.lookup("java:comp/env/ejb/SimpleConverter");
		//ConverterHome home = (ConverterHome)ctx.lookup("JNDIConverterBean");
		//ConverterHome home = (ConverterHome)ctx.lookup("java:comp/env/ejb/JNDIConverterBean");
		ConverterHome home = (ConverterHome)ctx.lookup("ejb/JNDIConverterBean");
            Converter currencyConverter = home.create();

            BigDecimal param = new BigDecimal("100.00");
            BigDecimal amount = currencyConverter.dollarToYen(param);

            System.out.println(amount);
            amount = currencyConverter.yenToEuro(param);
            System.out.println(amount);

            System.exit(0);
        } catch (Exception ex) {
            System.err.println("Caught an unexpected exception!");
            ex.printStackTrace();
        }
    }
}
