package eu.ase.ejb3.sesmdb;

import javax.ejb.Local;


@Local
public interface PublisherLocal extends Publisher
{
}
