package eu.ase.ejb3.sesmdb;

import javax.ejb.Remote;

@Remote
public interface PublisherRemote extends Publisher
{

}
