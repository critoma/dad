package eu.ase.ejb3;

import javax.ejb.Local;


@Local
public interface ConverterLocal extends Converter
{
}
