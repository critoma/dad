package eu.ase.ejb3;

import javax.ejb.Remote;

@Remote
public interface ConverterRemote extends Converter
{

}
