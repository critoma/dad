package eu.ase.test;

/*
 * Grade 4: Create the class BasketTeam which extends Team implements Cloneable and Comparable<Team> interfaces.
 * 
 * Besides the fields and methods inherited from the abstract class Team, the class BasketTeam has the following private fields:
 * location : String for the location
 * serialVersionUID : static long
 * 
 * Create the constructor method with 5 parameters: 
 * "idTeam" of type int, "name" of type String, "yearlyCost" of type float, "yearlyIncome" of type float, "location" of type String
 * The constructor should throw an Exception if the yearly cost (yearlyCost field) is less than 0 or the location is null
 * 
 * Implement proper get/set method(s) and override equals method:
 * public method equals(Object o) which returns boolean
 * The setLocation method must throw an exception if the location is a null String.
 * 
 * Implement consistently the clone method for creating deep copy of the current object:
 * public clone() which return Object and may throw CloneNotSupportedException
 * 
 * Override the methods from Comparable (compareTo() -> returns int and it compares teams in terms of location)
 * 
 * Override method getAbstractIdTeam() which returns a String which represents the concatenation of the inherited value
 * for the idTeam and location filed value
 * 
 * Override toString() -> String method in terms of returning the String concatenation of the fields content
 */

/*
 * Nota 4: Creati clasa BasketTeam ce este derivata din Team si implementeaza interfetele Cloneable si Comparable<Team>.
 * 
 * Pe langa campurile si metodele mostenite din clasa abstracta Team, clasa BasketTeam are urmatoarele campuri private aditional:
 * location : String pentru locatie
 * serialVersionUID : static long
 * 
 * Implementati metoda constructor cu 5 parameteri: 
 * "idTeam" de tip int, "name" de tip String, "yearlyCost" de tip float, "yearlyIncome" de tip float, "location" de tip String
 * Constructorul arunca o exceptie din clasa Exception daca costul anual (yearlyCost) este mai mic de 0 sau locatia (location) este null
 * 
 * Implementati corespunsator metodele get/set si supra-screti metoda equals:
 * metoda publica equals(Object o) ce returneaza boolean
 * Metoda setLocation produce o exceptie din clasa Exception daca locatia este null.
 * 
 * Implementati consistent metoda clone pentru a creeea obiecte clona de tip "deep copy" din obiectul curent:
 * public clone() -> return Object si "throw CloneNotSupportedException"
 * 
 * Supra-scrieti metoda compareTo din interfata Comparable (compareTo() -> return int ce compara echipele in functie de campul location)
 * 
 * Supra-scrieti si implementati metoda getAbstractIdTeam() ce returneaza un obiect de tip String 
 * ce reprezinta concatenarea valoarea mostenita pentru idTeam si valoarea capului location
 * 
 * Supra-scrieti metoda toString() -> String astfel incat sirul de caractere returnat sa contina textual reprezentarea tuturor campurilor din clasa
 */

public class BasketTeam /*extends Team implements Cloneable, Comparable<BasketTeam>*/ {
	
}
	
