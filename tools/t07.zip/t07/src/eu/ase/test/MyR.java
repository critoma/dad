package eu.ase.test;

/* 
 *  2 points (Grade 6 must be resolved completely from 3 to 6):
 *  Implement the public class MyR which implements Runnable interface
 *  The class contains the following private fields:
 *  v of type BasketTeam[] // classic array of the basket teams
 *  avg of type float // the average of the elements from the teams array in terms of income
 *  
 *  Implement the public constructor with 2 parameters:
 *  "m" of type Object[][], "line" of type int
 *  each element from the array of the class is reference to an object (column) from the line of the matrix received as parameters
 *  
 *  Override the run() method to be called in multi-threading environment for calculating the average income of the teams
 *  and provide public method getAvg() which is returning the float average income (avg field from the class)
 */

/* 
 *  2 puncte (Nota 6 trebuie implementata cu punctajele incrementale de la 3 la 6):
 *  Dezvoltati clasa publica MyR care implementeaza interfata Runnable
 *  Clasa contine urmatoarele campuri private:
 *  v de tip BasketTeam[] // 
 *  avg de tip float // 
 *  
 *  Implementati constructorul cu 2 parameteri:
 *  "m" de tip Object[][], "line" de tip int
 *  Fiecare element din campul v este referinta catre un obiect din pozitia coresunzatoare (coloana) din linia matricei primite ca parmetru
 *  
 *  Supra-scrieti metoda run() pentru a fi apelata in mod multi-fir pentru calcularea mediei de venit al echipelor
 *  si furnizati metoda publica getAvg() ce returneaza o valoare de tip float ce reprezinta media de venit (campul avg)
 */

public class MyR /*implements Runnable*/ {
	
}
