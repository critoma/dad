package eu.ase.test;

// This is the Java code playground
// Loc pentru testare obiecte si clase utilizand cod sursa Java

public class ProgMain {
/*
	public static void main(String[] args) {
		BasketTeam pv1, pv2, pv3;
		try {
			pv1 = new BasketTeam(11, "T1", 12, 20, "L1");
			pv2 = new BasketTeam(12, "T2", 13, 21, "L2");
			pv3 = new BasketTeam(12, "T3", 13, 21, "L3");
			if (pv1.equals(pv2))
				System.out.println("incorrect true");
			else
				System.out.println("correct false");
			
			if (pv2.equals(pv3))
				System.out.println("correct true");
			else
				System.out.println("incorrect false");
			
			BasketTeam[][] objs = new BasketTeam[][]{{pv1, pv2, null}, {null, pv3, null}};
			System.out.println("lines = " + objs.length + " , columns = " + objs[0].length);
			Utils m = new Utils();
			m.setMatrix(objs);
			m.displayMatrix();
			// ...
		} catch (Exception e) {
			e.printStackTrace();
		}
	    
	}
*/
}
