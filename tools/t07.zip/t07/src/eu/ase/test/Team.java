package eu.ase.test;

import java.io.Serializable;

/*
 * Grade 3: 
 * Create the abstract class Team which implements Cloneable, AutoCloseable and java.io.Serializable interfaces.
 * 
 * The class has the following private fields:
 * idTeam : int which is the id of the Team
 * name : String for the name of the Team
 * yearlyCost : float
 * yearlyIncome : float
 * serialVersionUID : static long
 * 
 * Create the constructor method without parameters and the one with 4 parameters: 
 * "idTeam" of type int, "name" of type String, "yearlyCost" of type float, "yearlyIncome" of type float
 * The constructor with parameters should throw an Exception if the yearly cost (yearlyCost) is less than 0 
 * 
 * Create the private, static and final field className : String with the value "eu.ase.test.Team" 
 * and associated public, static get method (getClassName)
 * Create the private, static field TeamsNo and and associated public, static get method (getTeamsNo -> returns int). 
 * This variable (teamsNo) / field is used for counting how many objects from this class have been created. 
 * Also be sure this variable is incremented into the constructors and clone method and decremented into close method.
 * 
 * Implement proper get/set methods
 * 
 * Implement consistently the clone method for creating deep copy of the current object:
 * public clone() which return Object and may throw CloneNotSupportedException
 * 
 * AutoCloseable (close() -> returns void)
 * 
 * Declare public abstract method getAbstractIdTeam which has no parameter and returns -> String.
 */

/*
 * Nota 3: 
 * implementati clasa abstracta Team ce implementeaza interfetele: Cloneable, AutoCloseable si java.io.Serializable .
 * 
 * Clasa are urmatoarele campuri private:
 * idTeam : int ce contine identifcatorul echipei
 * name : String ce contine numele echipei
 * yearlyCost : float 
 * yearlyIncome : float 
 * serialVersionUID : static long
 * 
 * Trebuie implementata metoda constructor fara parameteri si contructorul cu 4 parameteri: 
 * "idTeam" de tip int, "name" de tip String, "yearlyCost" de tip float, "yearlyIncome" de tip float
 * Constructorul cu parametri trebuie sa dea o exceptie din Exception daca costul anual (yearlyCost) este mai mic decat 0 
 * 
 * Clasa contine campul className : String ce este privat, static si final cu valoarea: "eu.ase.test.Team" 
 * si metoda de tip get asociata - publica si statica (getClassName)
 * 
 * Clasa mai contine un camp private si static "teamsNo" (numar total de pasageri / obiecte create din aceasta clasa)
 * si metoda publica si statica de tip get asociata (getTeamsNo -> returns int). 
 * Campul (teamsNo) este utilizat pentru a contoriza numarul de obiecte create din aceasta clasa. 
 * Acest camp este incrementat in constructori si metoda clone si decrementat in metoda close.
 * 
 * Implementati metodele get/set in mod crespunzator pentru fiecare camp
 * 
 * Implementati consistent metoda clone pentru a creeea obiecte clona de tip "deep copy" din obiectul curent:
 * public clone() -> return Object si "throw CloneNotSupportedException"
 * 
 * Implementati interfata AutoCloseable (close() -> return void)
 * 
 * Declarati metoda publica si abstracta: getAbstractIdTeam ce nu are parametri si returneaza -> String.
 */

public abstract class Team /*implements Cloneable, AutoCloseable, Serializable*/ {
	
}

