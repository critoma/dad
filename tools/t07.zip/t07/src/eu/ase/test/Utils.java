package eu.ase.test;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;

import eu.ase.test.BasketTeam;

/*
 * Grade 5: Create the class Utils.
 * 
 * The class Utils has the following private fields:
 * matrix: Object[][] for the references to the BasketTeam objects stored within the matrix objects
 * 
 * Additionally, there the following private fields used for the intermediary results:
 *  listPassengers of type List<BasketTeam>;
 *  streamPassenger of type Stream<BasketTeam>;
 *  predicate of type Predicate<BasketTeam>;
 *  threadsArrayWorkerTasks of type MyR[];
 * 
 * The class has no constructor - besides the default constructor (without parameters) 
 * automatically added by Java
 * 
 * Implement proper get/set method(s) for all fields:
 * (listTeams, streamTeams, predicate, threadsArrayWorkerTasks)
 * The set method for matrix field (public void setMatrix(Object[][] matrixInstance) throws Exception)
 * is setting the matrix field with a deep clone of matrixInstance by applying clone method
 * for each element of the matrixInstance (and each element from matrixInstance is casted to BasketTeam class).
 * 
 * Create method displayMatrix() -> void which put on the screen the content of the matrix field
 * 
 * Grade 6: Create public methods:
 *  writeBinary(String file) which returns void and serialize the matrix field into a file; 
 *  hint: 
 *  save the lines and columns of the matrix as first 2 integer values in file; 
 *  each object from the matrix is from class BasketTeam
 *  
 *  readBinary(String file) which returns void and restore/de-serialize the objects into matrix field from a file; 
 *  hint: 
 *  read the lines and columns of the matrix as first 2 integer values from file; 
 *  each object from the matrix is from class BasketTeam
 *  
 *  
 * 1 point (Grade 6 must be resolved completely from 2 to 6):
 *  Implement the public method transformMatrix2VectorAndSortPlusFilterWithLamdaPredicate(float parameter) 
 *  which returns List<BasketTeam>
 *  which transform the matrix into an ArrayList<BasketTeam> and then, 
 *  sort the teams and filter them by using lambda function as predicate within filter function
 *  and returns the new sorted list by using functional processing streams.
 *  This method must set consistently the intermediary fields:
 *  this.streamTeams, this.listTeams and this.predicate
 *  and returns the sorted list of the team (yearlyIncome > parameter) which are objects from BasketTeam
 *  
 * 1 point (Grade 6 must to be resolved completely from 2 to 6):
 *  Implement public method calculateAverageIncome() without parameters which is returning the average income of the teams
 *  and public method calculateAverageIncomeMultiThreading() which use multi-threading or Executor-Service mechanism/framework
 *  for creating worker tasks using the field: this.threadsArrayWorkerTasks of type MyR[] 
 *  Class MyR implements Runnable and proper implementation of this class => +2 points 
 *  The method calculateAverageIncomeMultiThreading() calculates the average of the income by using 
 *  the number of worker tasks / threads equals to the number of the lines from the matrix.
 *  This method uses the field this.threadsArrayWorkerTasks
 */


/*
 * Nota 5: Creati clasa Utils.
 * 
 * The clasa are urmatoarele campuri private:
 * matrix: Object[][] pentru containerul ce stocheaza referinte de tip BasketTeam catre obiectele matricei
 * 
 * Aditional, urmatoarele campuri private ale clase sunt utilizate pentru rezultate intermediare:
 *  listTeams de tip List<BasketTeam>;
 *  streamTeams de tip Stream<BasketTeam>;
 *  predicate de tip Predicate<BasketTeam>;
 *  threadsArrayWorkerTasks de tip MyR[];
 * 
 * Clasa nu are constructori
 * 
 * Implementati corespunzator metodele get/set pentru toate campurile:
 * (listTeams, streamTeams, predicate, threadsArrayWorkerTasks)
 * Metoda set pentru campul matrix (public void setMatrix(Object[][] matrixInstance) throws Exception)
 * seteaza campul marix cu o clona profunda (deep clone) a parametrului matrixInstance 
 * prin aplicarea medodei clone fiecarui obiect din matrixInstance 
 * (se aplica cast-ul la clasa BasketTeam pentru fiecare obiect)
 * 
 * Creati metoda displayMatrix() -> void ce afiseaza pe ecran matricea (continutul textual al campului matrix pe ecran)
 * 
 * Nota 6: Creati metodele publice:
 *  writeBinary(String file) -> void ce serializeaza campul matrice in fisier; 
 *  indicii: 
 *  se salveaza numarul de linii si coloane ale campului matrix ca 2 valori intregi in fisier; 
 *  fiecare obiect din matrice este din clasa BasketTeam
 *  
 *  readBinary(String file) -> void ce restaureaza/de-serializeaza obiecte din fisier in matrice (campul matrix); 
 *  indicii: 
 *  se citesc liniile si coloanele matricei ca primele 2 valori intregi din fisier; 
 *  fiecare obiect din matrice este din clasa BasketTeam
 *  
 *  
 * 1 punct (Nota 6 se rezolva complet si incremental de la 2 la 6):
 *  Implementati metoda publica: transformMatrix2VectorAndSortPlusFilterWithLamdaPredicate(float parameter) 
 *  ce returneaza un obiect de tip List<BasketTeam>
 *  Aceasta metoda transforma/liniarizeaza matricea intr-un obiect din ArrayList<BasketTeam> si apoi, 
 *  sorteaza echipele si-i filtreaza utilizand ca predicat functii lambda in cadrul 
 *  fluxurile functionale de procesare (functional processing streams).
 *  Aceasta metoda trebuie sa seteze consistent campurile urmatoare din interiorul clasei:
 *  this.streamTeams, this.listTeams si this.predicate
 *  si returneaza lista sortata a echipelor (yearlyIncome > parameter) ce sunt obiecte din clasa BasketTeam
 *  
 * 1 punct (Nota 6 se rezolva complet si incremental de la 2 la 6):
 *  Implementati metoda calculateAverageIncome() ce returneaza media venitului echipelor
 *  Apoi, implementati calculateAverageIncomeMultiThreading() ce creaza mai multe fire de executie sau
 *  conlucreaza cu mecanismul Executor-Service pentru crearea de task-uri cu ajutorul campului:
 *  this.threadsArrayWorkerTasks de tip MyR[]
 *  Clasa MyR implementeaza interfata Runnable iar implementare corespunzatoare a clasei MyR => +2 points 
 *  Metoda calculateAverageIncomeMultiThreading() calculeaza media veniturilor echipelor prin utilizarea unui numar 
 *  de "worker tasks" / "threads" - fire de executie egal cu numarul de linii ale matricei.
 *  Aceasta metoda utilizeaza campul: this.threadsArrayWorkerTasks
 */

public class Utils {
	
}
