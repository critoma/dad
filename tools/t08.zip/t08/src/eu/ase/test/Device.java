package eu.ase.test;

import java.io.Serializable;

/*
 * Grade 3: 
 * Create the abstract class Device which implements Cloneable, AutoCloseable and java.io.Serializable interfaces.
 * 
 * The class has the following private fields:
 * id : int which is the id of device
 * name : String for the name of the device
 * productionCost : float 
 * price : float for the device price
 * serialVersionUID : static long
 * 
 * Create the constructor method without parameters and the one with 4 parameters: 
 * "id" of type int, "name" of type String, "productionCost" of type float, "price" of type float
 * The constructor with parameters should throw an Exception if the device price is less then or equals 0 
 * 
 * Create the private, static and final field className : String with the value "eu.ase.test.Device" 
 * and associated public, static get method (getClassName)
 * Create the private, static field debiceNo and and associated public, static get method (getDeviceNo -> returns int). 
 * This variable (deviceNo) / field is used for counting how many objects from this class have been created. 
 * Also be sure this variable is incremented into the constructors and clone method and decremented into close method.
 * 
 * Implement proper get/set methods
 * 
 * Implement consistently the clone method for creating deep copy of the current object:
 * public clone() which return Object and may throw CloneNotSupportedException
 * 
 * AutoCloseable (close() -> returns void)
 * 
 * Declare public abstract method getAbstractDeviceId which has no parameter and returns -> String.
 */

/*
 * Nota 3: 
 * implementati clasa abstracta Device ce implementeaza interfetele: Cloneable, AutoCloseable si java.io.Serializable .
 * 
 * Clasa are urmatoarele campuri private:
 * id : int ce contine identifcatorul dispozitivului
 * name : String ce contine numele dispozitivului
 * productionCost : float 
 * price : float pentru pretul dispozitivului
 * serialVersionUID : static long
 * 
 * Trebuie implementata metoda constructor fara parameteri si contructorul cu 3 parameteri: 
 * "deviceId" de tip int, "name" de tip String, "price" de tip float
 * Constructorul cu parametri trebuie sa dea o exceptie din Exception daca pretul (price) este mai mic sau egal cu 0 
 * 
 * Clasa contine campul className : String ce este privat, static si final cu valoarea: "eu.ase.test.Device" 
 * si metoda de tip get asociata - publica si statica (getClassName)
 * 
 * Clasa mai contine un camp private si static "deviceNo" (numar total de dispozitive / obiecte create din aceasta clasa)
 * si metoda publica si statica de tip get asociata (getDeviceNo -> returns int). 
 * Campul (deviceNo) este utilizat pentru a contoriza numarul de obiecte create din aceasta clasa. 
 * Acest camp este incrementat in constructori si metoda clone si decrementat in metoda close.
 * 
 * Implementati metodele get/set in mod corespunzator pentru fiecare camp
 * 
 * Implementati consistent metoda clone pentru a creeea obiecte clona de tip "deep copy" din obiectul curent:
 * public clone() -> return Object si "throw CloneNotSupportedException"
 * 
 * Implementati interfata AutoCloseable (close() -> return void)
 * 
 * Declarati metoda publica si abstracta: getAbstractDeviceId ce nu are parametri si returneaza -> String.
 */


public abstract class Device /*implements Cloneable, AutoCloseable, Serializable*/ {
	
}
