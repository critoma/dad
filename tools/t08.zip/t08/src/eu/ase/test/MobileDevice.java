package eu.ase.test;


/*
 * Grade 4: Create the class MobileDevice which extends Device implements Cloneable and Comparable<Device> interfaces.
 * 
 * Besides the fields and methods inherited from the abstract class Device, the class MobileDevice has the following private fields:
 * IMEI : String for the custom mobile device identifier 
 * serialVersionUID : static long
 * 
 * Create the constructor method with 4 parameters: 
 * "id" of type int, "name" of type String, "price" of type float, "IMEI" of type String
 * The constructor should throw an Exception if the price is less than or equals 0 or the IMEI is null
 * 
 * Implement proper get/set method(s) and override equals method:
 * public method equals(Object o) which returns boolean
 * The setIMEI method must throw an exception if the field is a null String.
 * 
 * Implement consistently the clone method for creating deep copy of the current object:
 * public clone() which return Object and may throw CloneNotSupportedException
 * 
 * Override the methods from Comparable (compareTo() -> returns int and it compares devices in terms of IMEI field)
 * 
 * Override method getAbstractDeviceId() which returns a String which represents the concatenation of the inherited value
 * for the deviceId and IMEI filed value
 * 
 * Override toString() -> String method in terms of returning the String concatenation of the fields content
 */

/*
 * Nota 4: Creati clasa MobileDevice ce este derivata din Device si implementeaza interfetele Cloneable si Comparable<Device>.
 * 
 * Pe langa campurile si metodele mostenite din clasa abstracta Device, clasa MobileDevice are urmatoarele campuri private aditional:
 * IMEI : String cod de identificare specific al dispozitivelor mobile
 * serialVersionUID : static long
 * 
 * Implementati metoda constructor cu 4 parameteri: 
 * "id" de tip int, "name" de tip String, "price" de tip float, "IMEI" de tip String
 * Constructorul arunca o exceptie din clasa Exception daca pretul este mai mic sau egal cu 0 sau IMEI-ul este null
 * 
 * Implementati corespunsator metodele get/set si supra-screti metoda equals:
 * metoda publica equals(Object o) ce returneaza boolean
 * Metoda setIMEI produce o exceptie din clasa Exception daca IMEI-ul este null.
 * 
 * Implementati consistent metoda clone pentru a creeea obiecte clona de tip "deep copy" din obiectul curent:
 * public clone() -> return Object si "throw CloneNotSupportedException"
 * 
 * Supra-scrieti metoda compareTo din interfata Comparable (compareTo() -> return int ce compara dispozitivele in functie de campul IMEI)
 * 
 * Supra-scrieti si implementati metoda getAbstractDeviceId() ce returneaza un obiect de tip String 
 * ce reprezinta concatenarea valoarea mostenita pentru deviceId si valoarea capului IMEI
 * 
 * Supra-scrieti metoda toString() -> String astfel incat sirul de caractere returnat sa contina textual reprezentarea tuturor campurilor din clasa
 */


public class MobileDevice /*extends Device implements Cloneable, Comparable<MobileDevice>*/ {
	
}
