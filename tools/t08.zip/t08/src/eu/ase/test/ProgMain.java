package eu.ase.test;

//This is the Java code playground
//Loc pentru testare obiecte si clase utilizand cod sursa Java

public class ProgMain {
	/*
	public static void main(String[] args) {
		MobileDevice pv1, pv2, pv3;
		try {
			pv1 = new MobileDevice(2, "M 1", 20, 21, "IMEI 1");
			pv2 = new MobileDevice(2, "M 2", 20, 21, "IMEI 2");
			pv3 = new MobileDevice(2, "M3 2", 20, 21, "IMEI 3");
			if (pv1.equals(pv2))
				System.out.println("incorrect true");
			else
				System.out.println("correct false");
			
			if (pv2.equals(pv3))
				System.out.println("correct true");
			else
				System.out.println("incorrect false");
			
			MobileDevice[][] objs = new MobileDevice[][]{{pv1, pv2, null}, {null, pv3, null}};
			System.out.println("lines = " + objs.length + " , columns = " + objs[0].length);
			Utils m = new Utils();
			m.setMatrix(objs);
			m.displayMatrix();
			// ...
		} catch (Exception e) {
			e.printStackTrace();
		}
	    
	}
	*/
}
