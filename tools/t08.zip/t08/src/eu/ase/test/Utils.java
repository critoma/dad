package eu.ase.test;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.function.Predicate;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/*
 * Grade 5: Create the class Utils.
 * 
 * The class Utils has the following private fields:
 * matrixValues: Object[][] for the references to the MobileDevice objects stored within the matrix objects
 * 
 * Additionally, there the following private fields used for the intermediary results:
 *  listDevices of type List<MobileDevice>;
 *  streamDevices of type Stream<MobileDevice>;
 *  predicate of type Predicate<MobileDevice>;
 *  threadsArrayWorkerTasks of type MyR[];
 * 
 * The class has no constructor - besides the default constructor (without parameters) 
 * automatically added by Java
 *  
 * Implement proper get/set method(s) for all fields:
 * (listDevices, streamDevices, predicate, threadsArrayWorkerTasks)
 * The set method for matrix field (public void setMatrix(Object[][] matrixInstance) throws Exception)
 * is setting the matrix field with a deep clone of matrixInstance by applying clone method
 * for each element of the matrixInstance (and each element from matrixInstance is casted to MobileDevice class).
 * 
 * Create method displayMatrix() -> void which put on the screen the content of the matrix field
 * 
 * Grade 6: Create public methods:
 *  writeBinary(String file) which returns void and serialize the matrix field into a file; 
 *  hint: 
 *  save the lines and columns of the matrix as first 2 integer values in file; 
 *  each object from the matrix is from class MobileDevice
 *  
 *  readBinary(String file) which returns void and restore/de-serialize the objects into matrix field from a file; 
 *  hint: 
 *  read the lines and columns of the matrix as first 2 integer values from file; 
 *  each object from the matrix is from class MobileDevice
 *  
 *  
 * 1 point (Grade 6 is mandatory to be resolved completely from 2 to 6):
 *  Implement the public method transformMatrix2VectorAndLambdaSortPriceByName() which returns List<MobileDevice>
 *  which transform the matrix into an ArrayList<Device> and then, 
 *  sort the devices and filter them by using lambda function as predicate within filter function
 *  removes the devices from the list which are lower then 5 (this.price < 5)
 *  and returns the new sorted list by using functional processing streams.
 *  This method must set consistently the intermediary fields:
 *  this.streamDevices, this.listDevices and this.predicate
 *  
 * 1 point (Grade 6 is mandatory to be resolved completely from 2 to 6):
 *  Implement public method calculateAveragePrice() without parameters which is returning the average price of the devices
 *  and public method calculateAveragePriceMultiThreading() which use multi-threading framework Executor-Service 
 *  for creating worker tasks using the field: this.threadsArrayWorkerTasks from class MyR (which implements Runnable + 2 points) and calculate the average of the price by using 
 *  the number of worker tasks (in behind are threads) equals to the number of the lines from the matrix.
 *  This method uses the field this.threadsArrayWorkerTasks
 */

/*
 * Nota 5: Creati clasa Utils.
 * 
 * The clasa are urmatoarele campuri private:
 * matrixValues: Object[][] pentru containerul ce stocheaza referinte de tip MobileDevice catre obiectele matricei
 * 
 * Aditional, urmatoarele campuri private ale clase sunt utilizate pentru rezultate intermediare:
 *  listDevices de tip List<MobileDevice>;
 *  streamDevices de tip Stream<MobileDevice>;
 *  predicate de tip Predicate<MobileDevice>;
 *  threadsArrayWorkerTasks de tip MyR[];
 * 
 * Clasa nu are constructori
 * 
 * Implementati corespunzator metodele get/set pentru toate campurile:
 * (listDevices, streamDevices, predicate, threadsArrayWorkerTasks)
 * Metoda set pentru campul matrix (public void setMatrix(Object[][] matrixInstance) throws Exception)
 * seteaza campul marix cu o clona profunda (deep clone) a parametrului matrixInstance 
 * prin aplicarea medodei clone fiecarui obiect din matrixInstance 
 * (se aplica cast-ul la clasa MobileDevice pentru fiecare obiect).
 * 
 * 
 * Creati metoda displayMatrix() -> void ce afiseaza pe ecran matricea (continutul textual al campului matrix pe ecran)
 * 
 * Nota 6: Creati metodele publice:
 *  writeBinary(String file) -> void ce serializeaza campul matrice in fisier; 
 *  indicii: 
 *  se salveaza numarul de linii si coloane ale campului matrix ca 2 valori intregi in fisier; 
 *  fiecare obiect din matrice este din clasa MobileDevice
 *  
 *  readBinary(String file) -> void ce restaureaza/de-serializeaza obiecte din fisier in matrice (campul matrix); 
 *  indicii: 
 *  se citesc liniile si coloanele matricei ca primele 2 valori intregi din fisier; 
 *  fiecare obiect din matrice este din clasa MobileDevice
 *  
 *  
 * 1 punct (Nota 6 este obligatorie pentru punctajele incrementale de la 2 la 6):
 *  Implementati metoda publica transformMatrix2VectorAndLambdaSortPriceByName() -> List<Device>
 *  care transforma matricea intr-un obiect de tip ArrayList<Device> si apoi, 
 *  sorteaza dispozitivele folosind fluxuri functionale de procesare (functional processing stream),
 *  eliminand dispozitivele care au pretul mai mic decat 5.
 *  Aceasta metoda trebuie sa seteze consistent campurile intermediare ale clasei:
 *  this.streamDevices, this.listDevices si this.predicate
 *  
 * 1 punct (Nota 6 este obligatorie pentru punctajele incrementale de la 2 la 6)::
 *  Implementati metoda publica calculateAveragePrice() ce returneaza pretul mediul al dispozitivelor
 *  si metoda publica calculateAveragePriceMultiThreading() care utilizeaza mecanismul multi-threading Executor-Service 
 *  pentru crearea de sarcini de lucru (worker tasks) utilizand campul: this.threadsArrayWorkerTasks din clasa MyR (ce implementeaza interfata Runnable + 2 puncte)  
 *  si calculeaza media pretului dispozitivelor printr-un numar de fire de execurie egal cu numarul de linii din matrice.
 *  Aceasta metoda utilizeaza campul this.threadsArrayWorkerTasks
 */

public class Utils {
	
}
